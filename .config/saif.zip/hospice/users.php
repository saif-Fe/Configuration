<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
                <h1>User Manager</h1>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table  class="table display w-100 table-hover	table-borderless">
                <thead class="bg-red">
                    <tr>
                        <th colspan="100%">User Names</th>
                    </tr>
                </thead>
                <tbody class="">
                    <tr class="bg-light">
                        <td colspan="100%">Active Users</td>
                    </tr>
                    <tr>
                        <td>1.</td>
                        <td><a href="./edit-user-profile.php">Admin, Admin</a></td>
                        <td><a href="">Reset Password</a></td>
                        <td><a href="">Deactivate Account</a></td>
                    </tr>
                    <tr>
                        <td>1.</td>
                        <td><a href="./edit-user-profile.php">Admin 2, Admin 2</a></td>
                        <td><a href="">Reset Password</a></td>
                        <td><a href="">Deactivate Account</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div>
            <ul class="list-inline d-flex justify-content-between">
                <li class="list-inline-item"><a href="">A</a></li>
                <li class="list-inline-item"><a href="">B</a></li>
                <li class="list-inline-item"><a href="">C</a></li>
                <li class="list-inline-item"><a href="">D</a></li>
                <li class="list-inline-item"><a href="">E</a></li>
                <li class="list-inline-item"><a href="">F</a></li>
                <li class="list-inline-item"><a href="">G</a></li>
                <li class="list-inline-item"><a href="">H</a></li>
                <li class="list-inline-item"><a href="">I</a></li>
                <li class="list-inline-item"><a href="">J</a></li>
                <li class="list-inline-item"><a href="">K</a></li>
                <li class="list-inline-item"><a href="">L</a></li>
                <li class="list-inline-item"><a href="">M</a></li>
                <li class="list-inline-item"><a href="">N</a></li>
                <li class="list-inline-item"><a href="">O</a></li>
                <li class="list-inline-item"><a href="">P</a></li>
                <li class="list-inline-item"><a href="">Q</a></li>
                <li class="list-inline-item"><a href="">R</a></li>
                <li class="list-inline-item"><a href="">S</a></li>
                <li class="list-inline-item"><a href="">T</a></li>
                <li class="list-inline-item"><a href="">U</a></li>
                <li class="list-inline-item"><a href="">V</a></li>
                <li class="list-inline-item"><a href="">W</a></li>
                <li class="list-inline-item"><a href="">X</a></li>
                <li class="list-inline-item"><a href="">Y</a></li>
                <li class="list-inline-item"><a href="">Z</a></li>
            </ul>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>