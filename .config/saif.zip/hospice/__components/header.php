<!doctype html>
<html lang="en">

<head>
    <title>Hospice</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.0-beta1 -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.bootstrap5.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/datetime/1.1.2/css/dataTables.dateTime.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <!-- FontAwesome 6.1.1 CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        
    <link rel="stylesheet" href="./css/style.css">

</head>

<body>
    <header>
        <nav class="navbar navbar-expand-sm navbar-light">
            <div class="container container__custom">
                <a class="navbar-brand" href="#"><img src="./assets/images/logo.png" alt=""></a>
                <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                        <li class="nav-item d-flex">
                            <span class="nav-link">Welcome,</span>
                            <a class="nav-link active" href="#" aria-current="page">Abdalla Elkhalifa </a>
                        </li>
                        <span class="nav-link">|</span>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <nav class="navbar navbar-expand-sm navbar-light bg-blue">
            <div class="container container__custom">
                <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav mt-2 mt-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Go To
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="./hotbox.php">hotbox</a></li>
                                <li><a class="dropdown-item" href="./qa-manager.php">qa manager</a></li>
                                <li><a class="dropdown-item" href="./inbox.php">inbox (1)</a></li>
                                <li><a class="dropdown-item" href="./my-patient.php">my patients</a></li>
                                <li><a class="dropdown-item" href="./user-manager.php">profile</a></li>
                                <li><a class="dropdown-item" href="./patient-manager.php">patient manager</a></li>
                                <li><a class="dropdown-item" href="./order-manager.php">order manager</a></li>
                                <li><a class="dropdown-item" href="./idg-meeting.php">idg meeting</a></li>
                                <li><a class="dropdown-item" href="./smart-qapi.php">smart qapi</a></li>
                                <li><a class="dropdown-item" href="./infection-control.php">infection control</a></li>
                                <li><a class="dropdown-item" href="./patient-fall-tracker.php">patient fall tracker</a></li>
                                <li><a class="dropdown-item" href="./volunteer-services.php">volunteer services</a></li>
                                <li><a class="dropdown-item" href="./patient-decline-report.php">patient decline report</a></li>
                                <li><a class="dropdown-item" href="./reports-admin.php">reports / admin</a></li>
                                <li><a class="dropdown-item" href="./billing-manager.php">billing manager</a></li>
                                <li><a class="dropdown-item" href="./financials.php">financials</a></li>
                                <li><a class="dropdown-item" href="">exit</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbardropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                File
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbardropdown">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        New &raquo;
                                    </a>
                                    <ul class="dropdown-menu dropdown-submenu">
                                        <li>
                                            <a class="dropdown-item" href="./new-messages.php">Message</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-orders.php">Orders</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-infection-log.php">Infection log</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-communication.php">Communication</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-patient.php">Patient</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-benefit-period.php">Benefit Period</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-facility.php">Facility</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-physician.php">Physician</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="./new-insurance.php">Insurance</a>
                                        </li>
                                        <li>

                                            <a class="dropdown-item" href="./new-users.php">Users</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="dropdown-item" href="./new-recipient-group.php">New Recipient Group</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbardropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Edit
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbardropdown">
                                <li><a class="dropdown-item" href="./user-recipient-groups.php">Recipient Groups</a></li>
                                <li><a class="dropdown-item" href="./edit-patient.php">Edit Patient</a></li>
                                <li><a class="dropdown-item" href="./edit-insurance.php">Edit Insurance</a></li>
                                <li><a class="dropdown-item" href="./edit-benefit-period.php">Edit Benefit Period</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                View
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="./inbox.php">Inbox</a></li>
                                <li><a class="dropdown-item" href="./inbox.php">Sent Messages</a></li>
                                <li><a class="dropdown-item" href="./inbox.php">Delete Messages</a></li>
                                <li><a class="dropdown-item" href="./medication-refill.php">Medication Refill</a></li>
                                <li><a class="dropdown-item" href="./benefit-period-list.php">Benefit Period List</a></li>
                                <li><a class="dropdown-item" href="./individual-patient.php">Benefit Period Manager</a></li>
                                <li><a class="dropdown-item" href="./medication-profile.php">Medication Profile</a></li>
                                <li><a class="dropdown-item" href="./allergy-profile.php">Allergy Profile</a></li>
                                <li><a class="dropdown-item" href="./patient-profile.php">Patient Profile</a></li>
                                <li><a class="dropdown-item" href="./patient-messages.php">Messages</a></li>
                                <li><a class="dropdown-item" href="./admission-summary.php">Admission Summary</a></li>
                                <li><a class="dropdown-item" href="./level-of-care.php">Level of Care</a></li>
                                <li><a class="dropdown-item" href="./plan-of-care.php">Plan of Care</a></li>
                                <li><a class="dropdown-item" href="./patient-volunteer-request.php">Volunteer Coordination</a></li>
                                <li><a class="dropdown-item" href="./his-measures.php">HIS Measures</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Search
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <div class="search-box-head">
                                      <form action="">
                                        <input type="text" name="" id="" class="form-control" placeholder="search must contain at least four characters" aria-describedby="helpId">
                                        <button type="submit" class="search-btn"></button>
                                    </form>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                help
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li><a class="dropdown-item" href="#">Something else here</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

    </header>
    <main>