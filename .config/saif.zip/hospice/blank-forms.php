<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Blank Forms</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="bg-white p-3">
                <ul class="list-col-3 list-unstyled">
                    <li><a href="./aide-care-plan.php">Aide Care Plan</a></li>
                    <li><a href="./beravement-assesment.php">Bereavement Assessment</a></li>
                    <li><a href="./continous-care-note.php">Continuous Care Note</a></li>
                    <li><a href="./f2f-certifying.php">F2F - Certifying</a></li>
                    <li><a href="./lvn-supervisory-visit.php">LVN Supervisory Visit</a></li>
                    <li><a href="./msw-phone-call.php">MSW Phone Call</a></li>
                    <li><a href="./plan-of-care-problems.php">Plan of Care Problems</a></li>
                    <li><a href="./rn-recertification.php">RN Re-Certification</a></li>
                    <li><a href="./volunteer-note.php">Volunteer Note</a></li>
                    <li><a href="./aide-supervisory-visit">Aide Supervisory Visit</a></li>
                    <li><a href="./chaplain-counselor-assessment.php">Chaplain/Counselor Assessment</a></li>
                    <li><a href="./discharge-death.php">Discharge Death</a></li>
                    <li><a href="./f2f-encounter.php">F2F Encounter</a></li>
                    <li><a href="./medication-administration-record.php">Medication Admimistration Record</a></li>
                    <li><a href="./msw-visit.php">MSW Visit</a></li>
                    <li><a href="./revocation-statement.php">Revocation Statement</a></li>
                    <li><a href="./skilled-nursing-visit.php">Skilled Nursing Visit</a></li>
                    <li><a href="./written-certification.php">Written Certification</a></li>
                    <li><a href="./aide-visit.php">Aide Visit</a></li>
                    <li><a href="./chaplain-councelor-visit.php">Chaplain/ Counselor Visit</a></li>
                    <li><a href="./discharge-live.php">Discharge Live </a></li>
                    <li><a href="./f2f-non-certifying.php">F2F - Non-certifying</a></li>
                    <li><a href="./msw-assessment.php">MSW Assessment </a></li>
                    <li><a href="./physician-visit.php">Physician Visit</a></li>
                    <li><a href="./rn-initial-assessment.php">RN Initial Assessment</a></li>
                    <li><a href="./volunteer-assessment.php">Volunteer Assessment</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>