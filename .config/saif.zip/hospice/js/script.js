const careCheck = document.querySelectorAll('.first-option input[type="checkbox"]');
const careFirstFeild = document.querySelectorAll('.first-option [type="text"]');
const careSecFeild = document.querySelectorAll('.second-option [type="text"]')
careCheck.forEach(e => {
  e.addEventListener('click', function(){
    console.log(this.parentNode);
  })
})
careFirstFeild.forEach(e => {
  e.setAttribute('disabled', '')
})
careSecFeild.forEach(e => {
  e.setAttribute('disabled', '')
})
const printBtn =  document.querySelector('#printPDF')
if(printBtn){
printBtn.addEventListener('click', function(){
      html2pdf(document.querySelector('.main__section'))
    })
}
const medicBox = document.querySelector('.medication-box');
const medicCont = document.querySelector('.medication-container');
const medicBtn = document.querySelector('#addMedication');
if(medicBox){
medicBox.remove();
}
if(medicBtn){
medicBtn.addEventListener('click', function(){
    medicCont.appendChild(medicBox.cloneNode(true));
})
}
function removeMedicBox(item){
  item.closest('.medication-box').remove()
}
function phoneFormat(e) {
  var x = e.value.replace(/\D/g, '').match(/(\d{3})(\d{3})(\d{4})/);
  e.value = '(' + x[1] + ') ' + x[2] + '-' + x[3];
};    
const emergencyBtn = document.querySelector('#addEmergencyInfo');
if(emergencyBtn){
  emergencyBtn.addEventListener('click', function(e){
    e.preventDefault();
    let beforeBtn = this.previousSibling.previousSibling
    let ele = beforeBtn.querySelector('.row')
    beforeBtn.appendChild(ele.cloneNode(true))
  })
}
// Add Alergy above
  const addAllergyBtn = document.querySelector('#addAllergy')
  if(addAllergyBtn){
    addAllergyBtn.addEventListener('click', function(){
      let substance =  this.closest('tfoot').querySelectorAll('td input.form-control')[0].value
      let reaction =  this.closest('tfoot').querySelectorAll('td input.form-control')[1].value
      if(!substance){
        alert('Add Substance')
        return
      }
      if(!reaction){
        alert('Add a Reaction')
        return
      }
      let tBody = this.closest('table').querySelector('tbody')
      let tR = `<tr scope="row"><td class="px-3">${substance}</td><td class="px-3">${reaction}</td><td class="px-3"><a name="" id="" class="btn btn-blue" href="#" role="button">Delete</a></td></tr>`
      tBody.insertAdjacentHTML('beforeend', tR)
    })
  }
  // Display substance Reaction Container
  function displaySubstanceReaction(ele){
    let substanceCont = ele.closest('.bg-white').querySelector('.substance-reaction__cont')
    if(ele.value != 'AllergiesAndSensitivities'){
      substanceCont.style.display = 'none'
      return
    }
      substanceCont.style.display = 'block'
  }
  // Show new medication
  function addNewMed(ele){
    let medCont = document.querySelector('.new-medication__cont')
   if(ele.value == 'medication'){
      medCont.style.display = 'block'
   }
   else if(ele.value == 'offMarket'){
      medCont.style.display = 'block'
   }
   else{
      medCont.style.display = 'none'
   }
  }