<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>LVN Supervisory Visit</h1>
            <div class="col-3">
                <div class="mb-3 row">
                    <div class="col-3 d-flex align-items-center"><label for="" class="form-label">Clinician:</label>
                    </div>
                    <div class="col-9"><input type="text" name="" id="" class="form-control" placeholder=""></div>
                </div>
            </div>
        </div>
        <div class="bg-grey py-3">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Patient Name (Last Name, First Name) & MRN:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Mileage:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <p>Gender</p>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Male">
                        <label class="form-check-label" for="">M</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Female">
                        <label class="form-check-label" for="">F</label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Agency Name/ Branch:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Date:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Time In:</label>
                        <input type="time" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Time Out:</label>
                        <input type="time" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">DOB:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>