<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Edit User Profile</h1>
            <p>Admin, Admin (Golden Creek, Houston, Admin)</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>User Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Last Name</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">First Name</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Suffix</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">User Type:</label>
                            <select class="form-select w-100" name="" id="">
                                <option value=""></option>
                                <option value=""> Chaplain </option>
                                <option value=""> COTA </option>
                                <option value=""> HHA </option>
                                <option value=""> LPN/LVN </option>
                                <option value=""> MSW </option>
                                <option value=""> Nurse Practitioner </option>
                                <option value=""> OT </option>
                                <option value=""> Other </option>
                                <option value=""> Physician </option>
                                <option value=""> PT </option>
                                <option value=""> PTA </option>
                                <option value=""> RN </option>
                                <option value=""> ST </option>
                            </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Address One</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Address Two</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Zip Code</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">City</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">State</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Email</label>
                          <input type="email" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Phone One</label>
                          <input type="phone" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Phone Two</label>
                          <input type="phone" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Employee ID</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Date of Birth</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">SSN</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <p>Include in Payroll</p>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="checkbox" value="" id="">
                          <label class="form-check-label" for="" hidden>
                            Include in Payroll
                          </label>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Employee Type</label>
                            <select class="form-select w-100" name="" id="">
                                <option value="1" selected="selected">Staff</option>	
                                <option value="2">Contract</option>	
                                <option value="3">Pay Per Visit</option>	
                                <option value="4">Per Diem</option>	
                                <option value="5">Other</option>	
                            </select>
                        </div>
                        <p>Is User Physician?</p>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="checkbox" value="" id="">
                          <label class="form-check-label" for="" hidden>
                            Is User Physicain?
                          </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header pb-3 d-flex justify-content-between mt-3">
                <h2>Weekend / Non-Business Hours Access</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <p>Weekend Access</p>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="checkbox" value="" id="">
                          <label class="form-check-label" for="" hidden>
                            Weekend Access
                          </label>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Earliest Login Time</label>
                          <input type="time" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Latest Login Time</label>
                          <input type="time" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header pb-3 d-flex justify-content-between mt-3">
                <h2>Hire / Termination Dates</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Hire Date</label>
                          <input type="date" class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Termination Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header pb-3 d-flex justify-content-between mt-3">
                <h2>Attachments</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Upload File</label>
                          <input type="file" class="form-control" name="" id="" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Upload Attachments</label>
                          <input type="file" class="form-control" name="" id="" placeholder="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex gap-3">
            <a href="./patient-roster-report.php" class="btn btn-grey ms-auto">Update</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>