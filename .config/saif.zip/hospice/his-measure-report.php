<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>HIS Measures Report</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <ul class="nav nav-tabs" id="pills-tab" role="tablist">
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link w-100 active" id="pills-home-tab" data-bs-toggle="tab" data-bs-target="#abc" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Admission/Discharge</button>
                </li>
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link w-100" id="pills-profile-tab" data-bs-toggle="tab" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Past Exports</button>
                </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="abc" role="tabpanel" aria-labelledby="pills-home-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <div class="bg-grey p-3">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Admission Status</label>
                                        <select class="form-select w-100" name="" id="">
                                            <option selected>All</option>
                                            <option value="admission">Admission</option>
                                            <option value="discharge">Discharge</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 d-flex align-items-end">
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" value="completed"
                                            id="hisAdmissionCompleted">
                                        <label class="form-check-label" for="hisAdmissionCompleted">
                                            Completed
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-4 d-flex align-items-end justify-content-end">
                                    <a name="" id="" class="btn btn-blue mb-3" href="#" role="button">Filter Report</a>
                                </div>
                            </div>
                        </div>
                        <div class="section-table overflow-hidden">
                            <div class="text-end my-3">
                                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
                            </div>
                            <table id="table_id"
                                class="table display w-100 table-striped table-hover	table-borderless align-middle">
                                <thead class="bg-red">
                                    <tr>
                                        <th>Patient</th>
                                        <th>MRN</th>
                                        <th>Type</th>
                                        <th>Admission Date</th>
                                        <th>Discharge Date</th>
                                        <th>Completion Date</th>
                                        <th>Completion Date Due</th>
                                        <th>Submission Date Due</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <div class="bg-grey p-3">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                      <label for="" class="form-label">Completion Start Date*</label>
                                      <input type="date" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                      <label for="" class="form-label">Completion End Date*</label>
                                      <input type="date" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-4 d-flex align-items-end">
                                    <a name="" id="" class="btn btn-blue mb-3" href="#" role="button">Filter Report</a>
                                </div>
                            </div>
                        </div>
                        <div class="section-table overflow-hidden">
                            <div class="text-end my-3">
                                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
                            </div>
                            <table id="table_id" class="table table_id display w-100 table-striped table-hover table-borderless align-middle">
                                <thead class="bg-red">
                                    <tr>
                                        <th>Patient</th>
                                        <th>MRN</th>
                                        <th>Type</th>
                                        <th>Admission Date</th>
                                        <th>Discharge Date</th>
                                        <th>Completion Date</th>
                                        <th>Completion Date</th>
                                        <th>Submission Date</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>