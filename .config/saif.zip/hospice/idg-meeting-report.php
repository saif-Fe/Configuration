<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between align-items-end">
            <div class="">
                <h1>IDG Meeting Report</h1>
            </div>
            <div class="text-end my-3">
                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
            </div>
        </div>
    </div>
    <div class="container container__custom">
            <div class="section-table">
                <table id="table_id" class="table table_id display w-100 table-hover	table-borderless">
                    <thead class="bg-red">
                        <tr>
                            <th></th>
                            <th>Patient Name</th>
                            <th>MRN</th>
                            <th>Admission Date</th>
                            <th>Admission Status</th>
                            <th>Discharge </th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <tr>
                            <td colspan="6" class="bg-grey">10/05/2022</td>
                        </tr>
                        <tr>
                            <td>1.</td>
                            <td><a href="#">Bond, James</a></td>
                            <td>GCE-003</td>
                            <td>06/15/2022</td>
                            <td>Not Discharge</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>1.</td>
                            <td><a href="#">Bond, James</a></td>
                            <td>GCE-003</td>
                            <td>06/15/2022</td>
                            <td>Not Discharge</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="6" class="bg-grey">10/05/2022</td>
                        </tr>
                        <tr>
                            <td>1.</td>
                            <td><a href="#">Bond, James</a></td>
                            <td>GCE-003</td>
                            <td>06/15/2022</td>
                            <td>Not Discharge</td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
    </div>
</div>
<?php include('./__components/footer.php')?>