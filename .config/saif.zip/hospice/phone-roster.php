<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Phone Roster Report</h1>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table bg-grey">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Phone</th>
                        <th>Phone 2</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            User Last Name
                        </td>
                        <td>
                            User First Name
                        </td>
                        <td>
                            (123) 456-7890
                        </td>
                        <td>
                            (123) 456-7890
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Second User Last Name
                        </td>
                        <td>
                            Second User First Name
                        </td>
                        <td>
                            (123) 456-7890
                        </td>
                        <td>
                            (123) 456-7890
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>