<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between align-items-end">
                <h1>Pending Admissions</h1>
        </div>
    </div>
    <div class="container container__custom">
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Physician E-Referrals</h2>
            </div>
        <div class="section-table">
            <table  class="table table_id display w-100 table-hover	table-borderless">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>MRN</th>
                        <th>Medicare Number</th>
                        <th>Branch</th>
                        <th>Create Date</th>
                        <th>Referral Date</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody class="">
                </tbody>
            </table>
        </div>
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Pending Admission</h2>
            </div>
        <div class="section-table">
            <table  class="table table_id display w-100 table-hover	table-borderless">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>MRN</th>
                        <th>Medicare Number</th>
                        <th>Branch</th>
                        <th>Create Date</th>
                        <th>Referral Date</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody class="">
                    <tr>
                        <td>1.</td>
                        <td>Bond, James</td>
                        <td>344</td>
                        <td></td>
                        <td>Golden Creek Enterprises LLC</td>
                        <td>10/11/2022</td>
                        <td>12/12/2020</td>
                        <td>
                            <div class="dropdown open">
                                <a class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                        aria-expanded="false">
                                            Action
                                        </a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="./edit-patient.php">Edit</a>
                                    <a class="dropdown-item disabled" href="./new-patient-additional.php">Admit</a>
                                    <a class="dropdown-item disabled" href="#">Non-Admission</a>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>