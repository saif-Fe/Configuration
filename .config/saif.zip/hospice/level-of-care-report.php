<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Level of Care Report</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="accordion" id="levelOfCareReportAccordian">
              <div class="accordion-item">
                <h2 class="accordion-header" id="levelOfCareReportFilter">
                  <button class="accordion-button btn-grey border-none shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Filter
                  </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="levelOfCareReportFilter" data-bs-parent="#levelOfCareReportAccordian">
                  <div class="accordion-body">
                   <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3">
                          <label for="" class="form-label">From</label>
                          <input type="date"
                            class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                          <label for="" class="form-label">To</label>
                          <input type="date"
                            class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-4 text-end">
                        <p class="mb-2">Branch: <span>Golden Creek Enterprises LLC</span></p>
                        <a name="" id="" class="btn btn-blue mb-3" href="#" role="button">Filter Report</a>
                    </div>
                   </div> 
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion my-3" id="continuousAccordian">
              <div class="accordion-item">
                <h2 class="accordion-header" id="continuousAccordianHeader">
                  <button class="accordion-button btn-grey d-flex gap-3" type="button" data-bs-toggle="collapse" data-bs-target="#continuousAccordianToggle" aria-expanded="true" aria-controls="continuousAccordian">
                    Continuous <span>Total Days:</span> <span></span> <span>Total Patient</span><span></span> 
                  </button>
                </h2>
                <div id="continuousAccordianToggle" class="accordion-collapse collapse" aria-labelledby="continuousAccordianHeader" data-bs-parent="#continuousAccordian">
                  <div class="accordion-body">
                        <div class="section-table overflow-hidden">
                            <div class="text-end my-3">
                                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
                            </div>
                            <table  class="table table_id display w-100 table-striped table-hover	table-borderless align-middle">
                                <thead class="bg-red">
                                    <tr>
                                        <th>Patient</th>
                                        <th>MRN</th>
                                        <th>Admission Date</th>
                                        <th>Total Days</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                </tbody>
                            </table>
                        </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion my-3" id="continuousAccordian">
              <div class="accordion-item">
                <h2 class="accordion-header" id="continuousAccordianHeader">
                  <button class="accordion-button d-flex gap-3" type="button" data-bs-toggle="collapse" data-bs-target="#continuousAccordianToggle" aria-expanded="true" aria-controls="continuousAccordian">
                    GIP <span>Total Days:</span> <span></span> <span>Total Patient</span><span></span> 
                  </button>
                </h2>
                <div id="continuousAccordianToggle" class="accordion-collapse collapse" aria-labelledby="continuousAccordianHeader" data-bs-parent="#continuousAccordian">
                  <div class="accordion-body">
                        <div class="section-table overflow-hidden">
                            <div class="text-end my-3">
                                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
                            </div>
                            <table  class="table table_id display w-100 table-striped table-hover	table-borderless align-middle">
                                <thead class="bg-red">
                                    <tr>
                                        <th>Patient</th>
                                        <th>MRN</th>
                                        <th>Admission Date</th>
                                        <th>Total Days</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                </tbody>
                            </table>
                        </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion my-3" id="continuousAccordian">
              <div class="accordion-item">
                <h2 class="accordion-header" id="continuousAccordianHeader">
                  <button class="accordion-button d-flex gap-3" type="button" data-bs-toggle="collapse" data-bs-target="#continuousAccordianToggle" aria-expanded="true" aria-controls="continuousAccordian">
                    Respite <span>Total Days:</span> <span></span> <span>Total Patient</span><span></span> 
                  </button>
                </h2>
                <div id="continuousAccordianToggle" class="accordion-collapse collapse" aria-labelledby="continuousAccordianHeader" data-bs-parent="#continuousAccordian">
                  <div class="accordion-body">
                        <div class="section-table overflow-hidden">
                            <div class="text-end my-3">
                                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
                            </div>
                            <table  class="table table_id display w-100 table-striped table-hover	table-borderless align-middle">
                                <thead class="bg-red">
                                    <tr>
                                        <th>Patient</th>
                                        <th>MRN</th>
                                        <th>Admission Date</th>
                                        <th>Total Days</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                </tbody>
                            </table>
                        </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion my-3" id="continuousAccordian">
              <div class="accordion-item">
                <h2 class="accordion-header" id="continuousAccordianHeader">
                  <button class="accordion-button d-flex gap-3" type="button" data-bs-toggle="collapse" data-bs-target="#continuousAccordianToggle" aria-expanded="true" aria-controls="continuousAccordian">
                    Routine <span>Total Days:</span> <span></span> <span>Total Patient</span><span></span> 
                  </button>
                </h2>
                <div id="continuousAccordianToggle" class="accordion-collapse collapse" aria-labelledby="continuousAccordianHeader" data-bs-parent="#continuousAccordian">
                  <div class="accordion-body">
                        <div class="section-table overflow-hidden">
                            <div class="text-end my-3">
                                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
                            </div>
                            <table  class="table table_id display w-100 table-striped table-hover	table-borderless align-middle">
                                <thead class="bg-red">
                                    <tr>
                                        <th>Patient</th>
                                        <th>MRN</th>
                                        <th>Admission Date</th>
                                        <th>Total Days</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                </tbody>
                            </table>
                        </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>