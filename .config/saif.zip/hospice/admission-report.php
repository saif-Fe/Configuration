<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Admission Report</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="bg-white p-3">
                <p>
                <button class="btn btn-blue" type="button" data-bs-toggle="collapse" data-bs-target="#admissionFilter" aria-expanded="false" aria-controls="admissionFilter">
                    Filter
                </button>
                </p>
                <div class="collapse" id="admissionFilter">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="">
                              <label for="" class="form-label">Admission date Between</label>
                              <div class="d-flex align-items-center gap-2">
                                  <input type="date" class="form-control m-0" name="" id="">
                                  <span class="text-center">And</span>
                                  <input type="date" class="form-control m-0" name="" id="">
                              </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <p>Branch: <span>Golden Creek Enterprises LCC</span></p>
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Filter Report</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table class="display w-100" id="table_id">
                <thead class="bg-red">
                    <tr>
                        <th>Patient Name</th>
                        <th>MRN</th>
                        <th>Referral Date</th>
                        <th>Start of Care Date</th>
                        <th>Admission Date</th>
                        <th>Benefit Period Date Renge</th>
                        <th>Insurance</th>
                        <th>Branch</th>
                        <th>Referral Source</th>
                        <th>Referring Physician</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>