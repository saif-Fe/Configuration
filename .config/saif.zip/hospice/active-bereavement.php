<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Active Bereavement</h1>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table class="display w-100" id="table_id">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Bereavement Party</th>
                        <th>Bereavement Party House</th>
                        <th>Patient Name</th>
                        <th>MRN</th>
                        <th>Discharge Date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1.</td>
                        <td><span class="tooltip-btn"><i class="fas fa-circle-exclamation me-3"></i></span>Bond, James</td>
                        <td>1234567890</td>
                        <td>Bond, James</td>
                        <td>BND-007</td>
                        <td>06/11/2022</td>
                    </tr>
                    <tr>
                        <td>1.</td>
                        <td><span class="tooltip-btn"><i class="fas fa-circle-exclamation me-3"></i></span>Bond, James</td>
                        <td>1234567890</td>
                        <td>Bond, James</td>
                        <td>BND-007</td>
                        <td>06/11/2022</td>
                    </tr>
                    <tr>
                        <td>1.</td>
                        <td><span class="tooltip-btn"><i class="fas fa-circle-exclamation me-3"></i></span>Bond, James</td>
                        <td>1234567890</td>
                        <td>Bond, James</td>
                        <td>BND-007</td>
                        <td>06/11/2022</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>