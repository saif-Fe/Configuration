<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Worklog Report</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                      <label for="" class="form-label">User*</label>
                      <input type="text" class="form-control" name="" id="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Start Date*</label>
                      <input type="date" class="form-control" name="" id="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">End Date*</label>
                      <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-12 text-end">
                    <a name="" id="" class="btn btn-blue" href="#" role="button">Create Report</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>