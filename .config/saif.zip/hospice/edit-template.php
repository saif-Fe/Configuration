<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
                <h1>Reports</h1>
                <p>Update Call RN Template</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Template</h2>
            </div>
            <div class="bg-white p-3 mb-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Template name</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">form element</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>aide care plan</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Template Text</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                          <label for="" class="form-label" hidden>Template Text</label>
                          <textarea class="form-control" name="" id="" rows="3"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex gap-3">
            <a href="./patient-roster-report.php" class="btn btn-grey ms-auto">Update Template</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>