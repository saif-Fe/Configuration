<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Clinic Settings</h1>
        </div>
    </div>
<div class="container container__custom">
    <div class="section-header pb-3 d-flex justify-content-between">
        <h2>General Settings</h2>
    </div>
    <div class="section-table mb-3">
        <table  class="table table_id display w-100 table-hover	table-borderless align-middle">
            <thead class="bg-red">
                <tr>
                    <th colspan="3">Settings</th>
                </tr>
            </thead>
            <tbody class="">
                <tr>
                    <td class="w-50">Facility ID</td>
                    <td></td>
                    <td class="text-end"><input type="text" name="facility-id" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td class="w-50">Restrict Overlapping Visits</td>
                    <td></td>
                    <td class="text-end"><input type="checkbox" name="restrict-overlapping-visits" id=""></td>
                </tr>
                <tr>
                    <td class="w-50">Use Advanced Wound Care Worksheet</td>
                    <td></td>
                    <td class="text-end"><input type="checkbox" name="use-advanced-wound-care-worksheet" id=""></td>
                </tr>
                <tr>
                    <td class="w-50">Time zone</td>
                    <td>Current Time zone for the clinic</td>
                    <td class="text-end">
                        <input type="checkbox" name="current-time-zone-for-the-clinic" id="" class="mb-3">
                        <select name="timezone" id="" class="form-control w-100">
                            <option value="">Alaska Time Zone</option>
                            <option value="">Aleutian Time Zone</option>
                            <option value="">Atlantic Time Zone</option>
                            <option value="" selected="selected">Central Time Zone</option>
                            <option value="">Eastern Time Zone</option>
                            <option value="">Hawaii Time Zone</option>
                            <option value="">Mountain Time Zone</option>
                            <option value="">Mountain Time Zone - Arizona</option>
                            <option value="">Pacific Time Zone</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Auto-Generate Medical Record Number</td>
                    <td>Auto-Genrate MRN for Patient</td>
                    <td class="text-end"><input type="checkbox" name="auto-generate-medical-record-number" id=""></td>
                </tr>
                <tr>
                    <td>Disable Geolocation Display for VisitVerify Hospice</td>
                    <td>Disable Geolocation Display for VisitVerify in hospice</td>
                    <td class="text-end"><input type="checkbox" name="disable-geolocation-display-for-visitverify-in-hospice" id=""></td>
                </tr>
                <tr>
                    <td>Print UB04 on blank form</td>
                    <td></td>
                    <td class="text-end"><input type="checkbox" name="print-UB04-on-blank-form" id=""></td>
                </tr>
                <tr>
                    <td>Send all Missed Visit forms to QA Manager upon Submit</td>
                    <td>Turn on this setting to send all Missed Visit forms to QA Manager upon Submit</td>
                    <td class="text-end"><input type="checkbox" name="send-all-missed-visit-form-to-qa-manager" id=""></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="section-header pb-3 d-flex justify-content-between">
        <h2>Billing Status</h2>
    </div>
    <div class="section-table mb-3">
        <table  class="table table_id display w-100 table-hover	table-borderless align-middle">
            <thead class="bg-red">
                <tr>
                    <th colspan="3">Settings</th>
                </tr>
            </thead>
            <tbody class="">
                <tr>
                    <td class="w-50">Permit billing after visit status is:</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td class="w-50">Completed</td>
                    <td></td>
                    <td class="text-end"><input type="text" name="completed" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td class="w-50">Returned for Review</td>
                    <td></td>
                    <td class="text-end"><input type="text" name="returned-for-review" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td class="w-50">Sent to physician</td>
                    <td></td>
                    <td class="text-end"><input type="text" name="sent-to-physicain" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td class="w-50">Returned with Signature</td>
                    <td></td>
                    <td class="text-end"><input type="text" name="returned-with-signature" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td class="w-50">Pending Clinician Signature</td>
                    <td></td>
                    <td class="text-end"><input type="text" name="pending-clinician-signature" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td class="w-50">Submitted with Signature</td>
                    <td></td>
                    <td class="text-end"><input type="text" name="submitted-with-signature" id="" class="form-control"></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="section-header pb-3 d-flex justify-content-between">
        <h2>Hospice Direct Messaging</h2>
    </div>
    <div class="section-table mb-3">
        <table  class="table table_id display w-100 table-hover	table-borderless align-middle">
            <thead class="bg-red">
                <tr>
                    <th colspan="3">Settings</th>
                </tr>
            </thead>
            <tbody class="">
                <tr>
                    <td class="w-50">Enable Hospice Direct Messaging</td>
                    <td></td>
                    <td class="text-end"><input type="checkbox" name="enable-direct-messaging" id=""></td>
                </tr>
                <tr>
                    <td class="w-50">Username</td>
                    <td></td>
                    <td class="text-end"><input type="text" class="form-control" name="username" id=""></td>
                </tr>
                <tr>
                    <td class="w-50">Password</td>
                    <td></td>
                    <td class="text-end"><a href="#">Reset Password</a><input type="password" class="form-control" name="password" id=""></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex gap-3">
            <a href="./patient-roster-report.php" class="btn btn-grey ms-auto">Save</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>