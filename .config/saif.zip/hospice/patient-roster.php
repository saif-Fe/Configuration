<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Reports</h1>
            <p>Create Patient Roster</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Include Branch Patient</h2>
            </div>
            <div class="bg-white p-3 mb-3">
                <p class="m-0 d-flex gap-3">Branch Patient <span>Golden Creek Enterprises LLC</span></p>
            </div>
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Include Patients with the following Insurance(s)</h2>
            </div>
            <div class="bg-white p-3 mb-3">
                <div class="mb-3">
                  <label for="" class="form-label">Select Insurance</label>
                  <select multiple class="form-select w-100" name="" id="">
                        <option selected>Select All</option>
                        <option value="-">Palmetto GBA</option>
                        <option value="-">TMHP</option>
                    </select>
                </div>
            </div>
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Choose Specific Case Manager</h2>
            </div>
            <div class="bg-white p-3 mb-3">
                <div class="mb-3">
                    <label for="" class="form-label">Choose Case Manager</label>
                    <select class="form-select w-100" name="" id="">
                        <option value=""></option>
                        <option value="">User 1</option>
                        <option value="">User 2</option>
                    </select>
                </div>
            </div>
            <div class="section-header pb-3 d-flex justify-content-between">
                <h2>Patient Flag</h2>
            </div>
            <div class="bg-white p-3 mb-3">
                <div class="mb-3">
                  <label for="" class="form-label">Patient Flag</label>
                  <select multiple class="form-select w-100" name="" id="">
                        <option selected>None</option>
                    </select>
                </div>
            </div>
            <div class="bg-white p-3 mb-3">
                <div class="form-check mb-3 d-flex align-items-center gap-3">
                  <input class="form-check-input" type="radio" name="" id="">
                  <label class="form-check-label" for="">
                    1. Include only active benefit period by Date <input type="date" name="" id="">
                  </label>
                </div>
                <div class="form-check mb-3 d-flex align-items-center gap-3">
                  <input class="form-check-input" type="radio" name="" id=""  >
                  <label class="form-check-label" for="">
                    2. Include all non-discharge patients <input type="date" name="" id="">
                  </label>
                </div>
                <div class="form-check mb-3 d-flex align-items-center gap-3">
                  <input class="form-check-input" type="radio" name="" id=""  >
                  <label class="form-check-label d-flex align-items-center gap-3" for="">
                    2. Date Range Beginning <input type="date" name="" id=""> Ending <input type="date" name="" id=""> 
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Include bereavement patients
                      </label>
                    </div>
                  </label>
                </div>
            </div>
            <p>Choice 1 will return any patients that have the selected date at some point in their benefit period</p>
            <p>Choice 2 will show all active (non-discharged) patients</p>
            <p>Choice 3 will return all patients with a benefit period during that time frame (Includes active and inactive patients)</p>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex gap-3">
            <a href="./patient-roster-report.php" class="btn btn-grey ms-auto">Create Roster</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>