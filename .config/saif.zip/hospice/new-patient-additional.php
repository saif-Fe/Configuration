<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Create New Admission</h1>
            <p>Patient Name</p>
        </div>
    </div>
    <div class="bg-grey">
        <div class="container container__custom">
            <div class="section-header py-3">
                <h2>Diagnosis Information (ICD-10) </h2>
            </div>
            <div class="bg-white p-3">
                <div class="mb-3">
                    <label for="" class="form-label">terminal diagnosis*</label>
                    <div class="d-flex"><input type="text" name="" id="" class="form-control" placeholder=""><a name=""
                            id="" class="btn btn-blue" href="#" role="button">+</a></div>
                </div>
            </div>
            <div class="section-header py-3 mt-2">
                <h2>Insurance Information </h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Primary Insurance</label>
                            <select class="form-control" name="" id="">
                                <option>Palmetto GBA</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Policy Number/MBI</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Medicaid Number</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Schedule an Instant Elegible Request
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 mt-2">
                <h2>Admission and Benefit Period Information </h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Start of Care Date*</label>
                            <input type="date" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Previous Admission?*</label>
                            <select class="form-control" name="" id="">
                                <option>No</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Admission Date</label>
                            <input type="date" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Benefit Period Beginning Date*</label>
                            <input type="date" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Admission Hour*</label>
                            <select class="form-control" name="" id="">
                                <option>00:00 - 00:59</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Notice of Election (NOE) Date</label>
                            <input type="date" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Notice of Election (NOE) Confirmation from Medicare
                                Date</label>
                            <input type="date" name="" id="" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Admission Status</label>
                            <select class="form-control" name="" id="">
                                <option>Routine</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <p>Initial Place of Service</p>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Same as Residence
                            </label>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label"></label>
                            <select class="form-control" name="" id="">
                                <option>Home (Q5001)</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Facility</label>
                            <select class="form-control" name="" id="" disabled>
                                <option>-</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Case Manager</label>
                            <select class="form-control" name="" id="">
                                <option>All Permission A</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">The Patient is being admitted on their</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                            <small id="helpId" class="text-muted">(n) of benefits Period</small>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Are new assessments needed?</label>
                            <select class="form-control" name="" id="">
                                <option>-</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        <div class="section-header py-3 mt-2">
            <h2>Room and Board </h2>
        </div>
        <div class="bg-white p-3">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" value="" id="'">
                        <label class="form-check-label" for="'">
                            Not Applicable
                        </label>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Room and Board Insurance</label>
                      <select class="form-control" name="" id="">
                        <option>TWHP</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Authorization</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Medicaid Number</label>
                        <input type="text" name="" id="" class="form-control" placeholder="" >
                    </div>
                </div>
                <div class="col-md-12">
                    <a name="" id="" class="btn btn-blue" href="#" role="button">Add Room and Board Dates</a>
                </div>
            </div>
        </div>
        <div class="section-header py-3 mt-2">
            <h2>Interdisciplinary Group Assignment</h2>
        </div>
        <div class="bg-white p-3">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" value="" id="'">
                        <label class="form-check-label" for="'">
                            Not Applicable
                        </label>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Room and Board Insurance</label>
                      <select class="form-control" name="" id="">
                        <option>TWHP</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Authorization</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Medicaid Number</label>
                        <input type="text" name="" id="" class="form-control" placeholder="" >
                    </div>
                </div>
                <div class="col-md-12">
                    <a name="" id="" class="btn btn-blue" href="#" role="button" >Add Room and Board Dates</a>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>
