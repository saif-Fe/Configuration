<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
                <h1>Reports</h1>
                <p>Review Form Templates</p>
        </div>
    </div>
        <div class="container container__custom">
            <div class="section-table">
                <table  class="table display w-100 table-hover	table-borderless">
                    <thead class="bg-red">
                        <tr>
                            <th>Templates</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <tr>
                            <td><a href="./aide-care-plan-template.php">Aide Care Plan</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Aide Supervisory Visit</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Aide Visit</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Bereavement POC Summary/Comments</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Chaplain Assesment</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Chaplain Assesment - Interdisciplinary Communication</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Chaplain Visit</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Chaplain Visit - Interdisciplinary Comunication</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Continious Care Note</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Dietitian SOAP Note</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Dosage And Administration </a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice Custom Base Form </a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice Discharge Death - Comments/Summary</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - ADLs / Fall Risk</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Assesment Instruction Performance</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Care Coordination/ Comments</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Gastrointestinal / Nutrition</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Pain</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Problems</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Psychological / Neutrological</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Respiratory/ Cardiovascular</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Vital Sign</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Hospice SN Visit - Wound Care Worksheet</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">IGS Meeting Summary/ Comments</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Misc. SOAP note</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Missed Visit - Comment</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">MSW Assesment</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">MSW Assesment & Visit - Interdisciplinary Communication</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">MSW Assesment & Visit - Problems</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">MSW Phone Call</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">MSW Visit</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Patient Communication</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Physician Order</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Physician Visit</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Physician Visit - Interdisciplinary Communication</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Plan of Care - Coordination of care - Summary/Comments</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Plan of Care - Problems - Description</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Plan of Care - Problems - Goal</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Plan of Care - Problems - Other Intervention</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Plan of Care - Problems - Resolved Reason</a></td>
                        </tr>
                        <tr>
                            <td><a href="#">Plan of Care IDG Notes</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - ADLs/Supportive Assistance</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Assistive Devices</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Fall Risk</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Gastrointestinal/Nutrition</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Integumentary/Wound</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - LCD</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Medication</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Pain</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Psychological/Neurological/Spiritual</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Respiratory/Cardiovascular</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Summary/Comments</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Initial Assessment - Vital Signs</a></td>
                        </tr>
                        <tr>
                            <td><a href="">RN Physician Order</a></td>
                        </tr>
                        <tr>
                            <td><a href="">Support Group - Mailing - Misc Visit (Bereavement)</a></td>
                        </tr>
                        <tr>
                            <td><a href="">Volunteer Note</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex gap-3">
            <a href="./patient-roster-report.php" class="btn btn-grey ms-auto">Add New Template</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>