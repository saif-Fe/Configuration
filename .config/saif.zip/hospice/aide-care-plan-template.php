<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
                <h1>Reports</h1>
                <p>Review Form Templates</p>
        </div>
    </div>
        <div class="container container__custom">
            <div class="section-table">
                <table  class="table display w-100 table-hover	table-borderless">
                    <thead class="bg-red">
                        <tr>
                            <th>Templates</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <tr>
                            <td><a href="./edit-template.php">Call RN</a></td>
                            <th><a href="#">Delete</a></th>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex gap-3">
            <a href="./patient-roster-report.php" class="btn btn-grey ms-auto">Add New Template</a>
        </div>
    </div>
</div>
