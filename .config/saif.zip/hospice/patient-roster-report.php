<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between align-items-end">
            <div class="">
                <h1>Reports</h1>
                <p>Patient Roster</p>
            </div>
            <div class="text-end my-3">
                <a name="" id="" class="btn btn-blue" href="#" role="button">Export as Excel</a>
            </div>
        </div>
    </div>
        <div class="container container__custom">
            <div class="section-table">
                <table  class="table table_id display w-100 table-hover	table-borderless">
                    <thead class="bg-red">
                        <tr>
                            <th>Patient</th>
                            <th>Admission</th>
                            <th>Attending Physician</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <tr>
                            <td>
                                <p> <span class="patient-no fw-bold">Patient (123)</span> | <span>123123123</span></p>
                                <p>1. <span class="patient-last-name fw-bold">Ali</span>, <span class="patient-first-name fw-bold">Zuhair</span> <span class="patient-gender fw-bold">(M)</span> <span>333333</span> </p>
                                <p>DOB: <span>10/10/1957</span> | Age: <span>65</span></p>
                                <p>Address: <span>7207 Regency Square Blvd</span></p>
                                <p>Houston, TX, 77083</p>
                            </td>
                            <td>
                                <p>Admit Date: <span>10/14/22</span></p>
                                <p>Benefit Period: <span>1</span></p>
                                <p>Terminal Dignosis: <span>Huntington's Disease </span></p>
                            </td>
                            <td>
                                <p>Attending Physician Name: <span>Clyde McMorris</span></p>
                                <p>Attending Physician NPI: <span>1234567890</span></p>
                                <p>Attending Physician Phonne: <span></span></p>
                                <p>Attending Physician Fax: <span></span></p>
                                <p>Case Manager: <span>User First Name</span> <span>User Last Name</span></p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p> <span class="patient-no fw-bold">Patient (123)</span> | <span>123123123</span></p>
                                <p>1. <span class="patient-last-name fw-bold">Ali</span>, <span class="patient-first-name fw-bold">Zuhair</span> <span class="patient-gender fw-bold">(M)</span> <span>333333</span> </p>
                                <p>DOB: <span>10/10/1957</span> | Age: <span>65</span></p>
                                <p>Address: <span>7207 Regency Square Blvd</span></p>
                                <p>Houston, TX, 77083</p>
                            </td>
                            <td>
                                <p>Admit Date: <span>10/14/22</span></p>
                                <p>Benefit Period: <span>1</span></p>
                                <p>Terminal Dignosis: <span>Huntington's Disease </span></p>
                            </td>
                            <td>
                                <p>Attending Physician Name: <span>Clyde McMorris</span></p>
                                <p>Attending Physician NPI: <span>1234567890</span></p>
                                <p>Attending Physician Phonne: <span></span></p>
                                <p>Attending Physician Fax: <span></span></p>
                                <p>Case Manager: <span>User First Name</span> <span>User Last Name</span></p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p> <span class="patient-no fw-bold">Patient (123)</span> | <span>123123123</span></p>
                                <p>1. <span class="patient-last-name fw-bold">Ali</span>, <span class="patient-first-name fw-bold">Zuhair</span> <span class="patient-gender fw-bold">(M)</span> <span>333333</span> </p>
                                <p>DOB: <span>10/10/1957</span> | Age: <span>65</span></p>
                                <p>Address: <span>7207 Regency Square Blvd</span></p>
                                <p>Houston, TX, 77083</p>
                            </td>
                            <td>
                                <p>Admit Date: <span>10/14/22</span></p>
                                <p>Benefit Period: <span>1</span></p>
                                <p>Terminal Dignosis: <span>Huntington's Disease </span></p>
                            </td>
                            <td>
                                <p>Attending Physician Name: <span>Clyde McMorris</span></p>
                                <p>Attending Physician NPI: <span>1234567890</span></p>
                                <p>Attending Physician Phonne: <span></span></p>
                                <p>Attending Physician Fax: <span></span></p>
                                <p>Case Manager: <span>User First Name</span> <span>User Last Name</span></p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
</div>
<?php include('./__components/footer.php')?>