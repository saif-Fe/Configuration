<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Allergy Profile</h1>
            <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span class="patient-name fw-bold ms-1">(864)</span></p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Add Allergy Profile</h2>
            </div>
            <div class="bg-white p-3">
                <div class="form-check mb-3">
                    <input class="form-check-input" type="radio" name="AllergyProfile" id="allergyFromNka" value="nka"
                        onchange="displaySubstanceReaction(this)">
                    <label class="form-check-label" for="allergyFromNka">
                        NKA (Food/ Drug/ Latex/ Enviormental)
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="AllergyProfile" id="allergyFromSensivities"
                        value="AllergiesAndSensitivities" onchange="displaySubstanceReaction(this)">
                    <label class="form-check-label" for="allergyFromSensivities">
                        Allergies and Sensitivities
                    </label>
                </div>
                <div class="substance-reaction__cont mt-3" style="display:none;">
                    <div class="substance-reaction">
                        <div class="table-responsive">
                            <table class="table 
                                table-hover	
                                table-borderless
                                
                                align-middle">
                                <thead>
                                    <tr>
                                        <th>Substance</th>
                                        <th>Reaction</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td scope="row" class="p-1">
                                            <label for="" class="form-label" hidden>Substance</label>
                                            <input type="text" class="form-control" name="substance"
                                                list="substanceList">
                                            <datalist id="substanceList">
                                                <option value="Select One">
                                                <option value="-">
                                            </datalist>
                                        </td>
                                        <td class="p-1">
                                            <div>
                                                <label for="" class="form-label" hidden>Reaction</label>
                                                <input type="text" class="form-control" name="" id="">
                                            </div>
                                        </td>
                                        <td class="p-1">
                                            <input name="" id="addAllergy" class="btn btn-blue" type="button"
                                                value="Add">
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>