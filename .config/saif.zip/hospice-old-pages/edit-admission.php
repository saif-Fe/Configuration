<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Edit Admission</h1>
            <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span class="patient-name fw-bold ms-1">(864)</span></p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Referral Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Referral Date*</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Source*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Transfer Form SNF or ICF</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">External Referral</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Transfer Form SNF or ICF</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Referring Individual</label>
                          <input type="text" class="form-control" name="" id="" >
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Internal Referral</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Alkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Referral Physician Name</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>McMorris, Clyde</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <p>Is the Referring Physician the Attending Physician*</p>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="refPhyEqualAttedingPhy" id="">
                          <label class="form-check-label" for="">
                            Yes
                          </label>
                        </div>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="refPhyEqualAttedingPhy" id=""  >
                          <label class="form-check-label" for="">
                            No
                          </label>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Attending Physician Name</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>McMorris, Clyde</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Diagnosis Information (ICD-10)</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                          <label for="" class="form-label">Terminal Dignosis*</label>
                            <div class="d-flex">
                                <input type="text" class="form-control" name="" id="">
                                <a name="" id="" class="btn btn-blue" href="#" role="button"><i class="fas fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Insurance Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Insurance</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Palmetto GBA</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Policy Number/MBI</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Medical Number</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Admission and Benefit Period Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Start of Care Date*</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Previous Admission?*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>No</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Admission Date*</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Admission Hour*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>01:00 - 01:59</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Notice of Election (NOE) Date*</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Notice of Election (NOE) Confirmation from Medicare Date*</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label" >Benefit Period Admission Date (the Patient is being submitted on their (n)st Benefit Period)</label>
                          <input type="text" class="form-control" name="" id="" >
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Are new assesment Needed?</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Yes</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Case Manager</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>All Permission A</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Room and Board</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="checkbox" value="" id="">
                          <label class="form-check-label" for="">
                            Not Applicable
                          </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Room and Board Insurance</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>TMHP</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Authorization</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Medicaid Number</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <a name="" id="" class="btn btn-blue" href="#" role="button"><i class="fas fa-plus"></i> Add Room and Board Dates</a>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Attachments</h2>
            </div>
            <div class="mb-3">
              <label for="" class="form-label" hidden>Choose file</label>
              <input type="file" class="form-control" name="" id="">
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex">
            <a href="./add-new-insurance.php" class="btn btn-grey ms-auto">Save and Submit</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>