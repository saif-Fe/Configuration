<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Patient Insurance</h1>
            <p>Add new Policy<span class="last-name mx-1">Bond</span>,<span class="first-name me-1">James</span><span class="pat-number me-1">(846) </span></p>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Insurance</th>
                        <th>Insured First Name</th>
                        <th>Insured Last Name</th>
                        <th>Insured Gender</th>
                        <th>Insured SSN</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Insurance Name</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected></option>
                                    <option value="tmhp">TMHP</option>
                                </select>
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured First Name</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured Last Name</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Insured Gender</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected>Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured SSN</label>
                              <input type="text" class="form-control" name="" id="" placeholder="000-00-0000">
                            </div>
                        </td>
                    </tr>
                </tbody>
                <thead class="bg-red">
                    <tr>
                        <th>Insured DOB</th>
                        <th>Insured Phone</th>
                        <th>Insured Employer</th>
                        <th>Position</th>
                        <th>Plan Name</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured Date of Birth</label>
                              <input type="date" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured Phone</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured Employer</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Position</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected></option>
                                    <option value="second">Second</option>
                                    <option value="third">Third</option>
                                    <option value="forth">Forth</option>
                                    <option value="fifth">Fifth</option>
                                </select>
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Plan Name</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Insured Address</th>
                        <th>Insured City</th>
                        <th>Insured State</th>
                        <th>Insured Zip</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured Date of Birth</label>
                              <input type="date" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured Phone</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Insured Employer</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Position</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected></option>
                                    <option value="second">Second</option>
                                    <option value="third">Third</option>
                                    <option value="forth">Forth</option>
                                    <option value="fifth">Fifth</option>
                                </select>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Relation to Insured</th>
                        <th>Group Name</th>
                        <th>Group Number</th>
                        <th>Policy Number</th>
                        <th>Effective Start</th>
                        <th>Effective End</th>
                        <th>AOB</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Relation to Insured</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected>Self</option>
                                    <option value="spouse">Spouse</option>
                                    <option value="child">Child</option>
                                </select>
                            </div>
                        </td>
                        <td> 
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Group Name</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td> 
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Group Number</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td> 
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Policy Number</label>
                              <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td> 
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Effective Start</label>
                              <input type="date" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td> 
                            <div class="mb-3">
                              <label for="" class="form-label" hidden>Effective End</label>
                              <input type="date" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td> 
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>AOB</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected>Yes</option>
                                    <option value="no">No</option>
                                </select>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Deductible</th>
                        <th>Coverage Percent</th>
                        <th>Co-Pay Amount</th>
                        <th>Insured Signature On File</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Deductible</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Coverage Percent</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3">
                                <label for="" class="form-label" hidden>Co-Pay Amount</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </td>
                        <td>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="" id="">
                              <label class="form-check-label" for="" hidden> Insured Signature On File </label>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Insurance Authorization Attachment</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="mb-3">
                              <label for="" class="form-label">Attachment</label>
                              <input type="file" class="form-control" name="" id="">
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex justify-content-end">
            <button type="submit" class="btn btn-grey">Add Insurance</button>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>