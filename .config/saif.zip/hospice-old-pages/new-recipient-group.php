<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>K-mail </h1>
            <p>Add New Recipient Group</p>
        </div>
    </div>
    <form action="">
        <div class="bg-grey py-3">
            <div class="container container__custom">
                <div class="">
                    <label for="" class="form-label">Group Name</label>
                    <input type="text" name="" id="" class="form-control" placeholder="">
                </div>
                <div class="bg-white d-flex flex-wrap gap-3 mt-3 p-3">
                    <p class="w-100">Recipients</p>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Admin Admin
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Abdallah Elkhalifa
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Abdallah Elkhalifa
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Abdallah Elkhalifa
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Abdallah Elkhalifa
                      </label>
                    </div>
                </div>
                <button type="submit" class="btn btn-blue mt-3">Add</button>
            </div>
        </div>
    </form>
</div>

<?php include('./__components/footer.php') ?>