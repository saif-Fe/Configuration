<?php include('./__components/header.php') ?>
<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>User Manager</h1>
            <p>Create New User</p>
        </div>
        <div class="section-header py-3">
            <h2>New User</h2>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                      <label for="" class="form-label">First Name</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">First Name</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Last Name</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Suffix (optional)</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">User Type</label>
                      <select class="form-control" name="" id="">
                        <option>-</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Preferred User Name*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Temporary Password</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Agency Employee ID</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Email Address</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Employee Type</label>
                      <select class="form-control" name="" id="">
                        <option>-</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <p>Is User Physician?</p>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Yes
                      </label>
                    </div>
                </div>
            </div>

        </div>
    </div>
      <div class="bg-blue py-3">
          <div class="container container__custom">
              <button type="submit" class="btn btn-grey" onclick="location.href = './new-user-confirmation.php';">Create User</button>
          </div>
      </div>
    </div>

    <?php include('./__components/footer.php') ?>