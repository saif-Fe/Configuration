<?php include('./__components/header.php') ?>

<div class="main__section">
  <div class="container container__custom">
    <div class="section-header py-3">
      <h1>Edit Patient</h1>
    </div>
  </div>
  <div class="bg-grey py-3">
    <div class="container container__custom">
      <div class="section-header py-3 d-flex justify-content-between">
        <h2>Aide Frequency</h2>
      </div>
      <div class="bg-white p-3">
        <div class="row">
          <div class="col-md-6">
            <div class="mb-3">
              <label for="" class="form-label">First Name:</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Middle Name:</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Last Name:</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Suffix:</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="d-flex gap-3">
              <div class="mb-3 col">
                <label for="" class="form-label">Date of Birth:</label>
                <input type="date" class="form-control" name="" id="">
              </div>
              <div class="mb-3 col">
                <label for="" class="form-label">Age:</label>
                <input type="text" class="form-control" name="" id="" disabled>
              </div>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Gender</label>
              <select class="form-select" name="" id="">
                <option selected>Male</option>
                <option value="">Female</option>
              </select>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Social Security Number:</label>
              <input type="text" inputmode="numeric" pattern="\d*" class="form-control" />
            </div>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                Not Applicable
              </label>
            </div>
          </div>
          <div class="col-md-6">
            <div class="mb-3">
              <label for="" class="form-label">Residence Type*</label>
              <select class="form-select w-100" name="" id="">
                <option value="home">Home</option>
                <option value="-">-</option>
                <option value="-">-</option>
                <option value="-">-</option>
              </select>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Residence Name</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Address 1*</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Address 2*</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Zip Code*</label>
              <div class="d-flex gap-3">
                <input type="text" class="form-control" name="" id="">
                <input type="text" class="form-control" name="" id="">
              </div>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">City*</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">State*</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Phone*</label>
              <div class="d-flex gap-3">
                <input type="text" class="form-control" onblur="phoneFormat(this)" name="" id="">
              </div>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Other Phone*</label>
              <div class="d-flex gap-3">
                <input type="text" class="form-control" onblur="phoneFormat(this)" name="" id="">
              </div>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Email Address*</label>
              <input type="text" class="form-control" name="" id="">
              <div class="form-check mt-3">
                <input class="form-check-input" type="checkbox" value="" id="">
                <label class="form-check-label" for="">
                  Not Applicable
                </label>
              </div>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                Patient Opts out of CAHPS Survey
              </label>
            </div>
          </div>
        </div>
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Aide Frequency</h2>
      </div>
      <div class="bg-white p-3">
        <div class="row">
          <div class="col-md-6">
            <div class="mb-3">
              <label for="" class="form-label">Medical Record Number</label>
              <input type="text" class="form-control" name="" id="">
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Primary Language</label>
              <select class="form-select w-100" name="" id="">
                <option selected>Select one</option>
                <option value="-">-</option>
                <option value="-">-</option>
                <option value="-">-</option>
              </select>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Primary Language</label>
              <select class="form-select w-100" name="" id="">
                <option selected>Select one</option>
                <option value="-">-</option>
                <option value="-">-</option>
                <option value="-">-</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <p><span>Race</span><span> (select all that Apply)</span></p>
            <div class="form-check mb-3 ms-3">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                American Indian or Alaskan Native
              </label>
            </div>
            <div class="form-check mb-3 ms-3">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                Asian
              </label>
            </div>
            <div class="form-check mb-3 ms-3">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                Black or African American
              </label>
            </div>
            <div class="form-check mb-3 ms-3">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                Hispanic or Latino
              </label>
            </div>
            <div class="form-check mb-3 ms-3">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                Native Hawaiian or Pacific Islander
              </label>
            </div>
            <div class="form-check mb-3 ms-3">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                White
              </label>
            </div>
          </div>
        </div>
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Emergency Contact Information</h2>
      </div>
      <div class="bg-white p-3">
            <div class="form-check mb-3">
              <input class="form-check-input" type="checkbox" value="" id="">
              <label class="form-check-label" for="">
                No emergency contact
              </label>
            </div>
        <div class="emergency-info-cont">
          <div class="row">
            <div class="col-md-6">
              <div class="mb-3">
                <label for="" class="form-label">First Name</label>
                <input type="text" class="form-control" name="" id="">
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Last Name</label>
                <input type="text" class="form-control" name="" id="">
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Relationship</label>
                <select class="form-select w-100" name="" id="">
                  <option selected>Select one</option>
                  <option value="-">-</option>
                  <option value="-">-</option>
                  <option value="-">-</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Address One*</label>
                <input type="text" class="form-control" name="" id="">
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Address Two</label>
                <input type="text" class="form-control" name="" id="">
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Zip Code*</label>
                <div class="d-flex gap-3">
                  <input type="text" class="form-control" name="" id="">
                  <input type="text" class="form-control" name="" id="">
                </div>
              </div>
              <div class="mb-3">
                <label for="" class="form-label">City*</label>
                <input type="text" class="form-control" name="" id="">
              </div>
              <div class="mb-3">
                <label for="" class="form-label">State*</label>
                <input type="text" class="form-control" name="" id="">
              </div>
            </div>
            <div class="col-md-6">
              <div class="mb-3">
                <label for="" class="form-label">Phone*</label>
                <input type="text" class="form-control" onblur="phoneFormat(this)" name="" id="">
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Other Phone</label>
                <input type="text" class="form-control" onblur="phoneFormat(this)" name="" id="">
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Email Address</label>
                <input type="text" class="form-control"  name="" id="">
              </div>
              <p>Power of Attorney</p>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="" value="financial">
                <label class="form-check-label" for="">Financial</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="" value="medical">
                <label class="form-check-label" for="">Medical</label>
              </div>
            </div>
          </div>
        </div>
        <a name="" id="addEmergencyInfo" class="btn btn-blue" href="#" role="button"><i class="fas fa-plus"></i></a>
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Advance Directive Information</h2>
      </div>
      <div class="bg-white p-3">
          <div class="row">
            <div class="col-md-6">
              <p>Signed Advance Directive on File</p>
              <div class="form-check mb-3">
                <input class="form-check-input" type="radio" name="signedAdvanceDirective" id="">
                <label class="form-check-label" for="">
                  Yes - Full Code / Advanced Cardiac Life Support (ACLS)
                </label>
              </div>
              <div class="form-check mb-3">
                <input class="form-check-input" type="radio" name="signedAdvanceDirective" id=""  >
                <label class="form-check-label" for="">
                  Yes - Do not Resusilate (DNR)
                </label>
              </div>
              <div class="form-check mb-3">
                <input class="form-check-input" type="radio" name="signedAdvanceDirective" id="">
                <label class="form-check-label" for="">
                  Living Will
                </label>
              </div>
              <div class="form-check mb-3">
                <input class="form-check-input" type="radio" name="signedAdvanceDirective" id=""  >
                <label class="form-check-label" for="">
                  No
                </label>
              </div>
              <div class="mb-3">
                <label for="" class="form-label">Advance Directive Date Issued</label>
                <input type="text" class="form-control" name="" id="">
              </div>
            </div>
            <div class="col-md-6">
              <p>Signed POLST on File</p>
              <div class="form-check mb-3">
                <input class="form-check-input" type="radio" name="signedPolstOnFile" id="">
                <label class="form-check-label" for="">
                  Yes
                </label>
              </div>
              <div class="form-check mb-3">
                <input class="form-check-input" type="radio" name="signedPolstOnFile" id=""  >
                <label class="form-check-label" for="">
                  No
                </label>
              </div>
              <div class="mb-3">
                <label for="" class="form-label">POLST Date Issued</label>
                <input type="text" class="form-control" name="" id="">
              </div>
            </div>
          </div>
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Funeral Home Information</h2>
      </div>
      <div class="bg-white p-3">
          <div class="row">
            <div class="col-md-6">
            <div class="mb-3">
              <label for="" class="form-label">Name</label>
              <select class="form-select w-100" name="" id="">
                <option selected>Select one</option>
                <option value="-">-</option>
                <option value="-">-</option>
                <option value="-">-</option>
              </select>
            </div>
            </div>
          </div>
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Pharmacy Information</h2>
      </div>
      <div class="bg-white p-3">
          <div class="row">
            <div class="col-md-6">
            <div class="mb-3">
              <label for="" class="form-label">Name</label>
              <select class="form-select w-100" name="" id="">
                <option selected>Select one</option>
                <option value="-">-</option>
                <option value="-">-</option>
                <option value="-">-</option>
              </select>
            </div>
            </div>
            <div class="col-md-6">
            <div class="mb-3">
              <label for="" class="form-label">Name</label>
              <select class="form-select w-100" name="" id="">
                <option selected>Select one</option>
                <option value="-">-</option>
                <option value="-">-</option>
                <option value="-">-</option>
              </select>
            </div>
            </div>
          </div>
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Patient Flags</h2>
      </div>
      <div class="bg-white p-3">
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Comments</h2>
      </div>
      <div class="bg-white p-3">
        <div class="mb-3">
          <label for="" class="form-label" hidden>Comments</label>
          <textarea class="form-control" name="" id="" rows="3"></textarea>
        </div>
      </div>
      <div class="section-header py-3 d-flex justify-content-between mt-3">
        <h2>Attachments</h2>
      </div>
      <div class="bg-white p-3">
      <div class="mb-3">
        <label for="" class="form-label">Choose file</label>
        <input type="file" class="form-control" name="" id="">
      </div>
      </div>
      <button type="submit" class="btn btn-blue mt-3">Save</button>
    </div>
  </div>
</div>

<?php include('./__components/footer.php') ?>