<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>K-mail</h1>
            <p>Send Messages</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <form action="">
            <div class="container container__custom">
                <div class="d-flex gap-3">
                    <a href="#" class="btn-blue">Show/hide Group</a>
                    <a href="#" class="btn-blue">Show/hide Address Book</a>
                </div>
                <div>
                    <h5 class="mt-3"> Groups </h3>
                </div>
                <div class="">
                    <h5 class="mt-3">Address Book</h5>
                    <div class="bg-white p-3">
                        <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="sel-all">
                        <label class="form-check-label" for="sel-all">
                            Select All
                        </label>
                        </div>
                        <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="sel-admin" >
                        <label class="form-check-label" for="sel-admin">
                            Admin, Admin
                        </label>
                        </div>  
                        <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="sel-user">
                        <label class="form-check-label" for="sel-user">
                            Elkhalifa, Abdalla
                        </label>
                        </div>
                        <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="sel-user" >
                        <label class="form-check-label" for="sel-user">
                            Holmes, Kenyatta
                        </label>
                        </div>
                    </div>
                </div>
                    <div class="col">
                        <div class="my-3">
                            <label for="" class="form-label">Subject</label>
                            <input type="text" name="" id="" class="form-control" placeholder="" aria-describedby="helpId">
                        </div>
                        <div class="mb-3">
                          <label for="messages-new-file" class="form-label">Attach a file</label>
                          <input type="file" class="form-control" name="messages-new-file" id="messages-new-file" placeholder="" aria-describedby="fileHelpId">
                        </div>
                        <div class="mb-3">
                          <label for="messages-new-sel" class="form-label">Regarading Patient</label>
                          <select class="form-control" name="messages-new-sel" id="messages-new-sel">
                            <option>-</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label for="message-textarea" class="form-label">Message</label>
                          <textarea class="form-control" name="message-textarea" id="message-textarea" rows="3"></textarea>
                        </div>
                    <button type="submit" class="btn btn-blue">Submit</button>
                    </div>
            </div>
        </form>
    </div>
</div>
<?php include('./__components/footer.php') ?>