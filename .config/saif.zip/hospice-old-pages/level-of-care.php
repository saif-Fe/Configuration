<?php include('./__components/header.php')?>
   <div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Level of Care</h1>
            <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span class="patient-name fw-bold ms-1">(864)</span></p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3">
                <p class="text-center">06/15/2022 - 09/12/2022</p>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">June 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">July 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">August 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">Sep 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="calender__footer py-4">
                <div class="row">
                    <div class="col-md-3">
                        <span class="benefit-period indicator">

                        </span>
                        <span>
                            Routine
                        </span>
                    </div>
                    <div class="col-md-3">

                        <span class="scheduled-tasks indicator">

                        </span>
                        <span>
                            inpatient (GIP)
                        </span>
                    </div>
                    <div class="col-md-3">
                        <span class="completed-tasks indicator">

                        </span>
                        <span>
                            Continious (CHC)
                        </span>
                    </div>
                    <div class="col-md-3">
                        <span class="missed-visit indicator">

                        </span>
                        <span>
                            Respite
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Level of Care</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Days</th>
                        <th>Hours</th>
                        <th>Minutes</th>
                        <th>Submitter</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Routine </td>
                        <td>10/14/2022</td>
                        <td>01/12/2023</td>
                        <td>91</td>
                        <td></td>
                        <td></td>
                        <td>Abdalla Alkhalifa</td>
                        <td>
                            <a name="" id="" class="btn btn-blue" href="#" role="button" data-bs-toggle="modal" data-bs-target="#modalId">Edit</a>
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Delete</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex justify-content-end">
            <button type="submit" class="btn btn-grey" data-bs-toggle="modal" data-bs-target="#modalId">Add Level of Care</button>
        </div>
    </div>
   </div> 
   <!-- Modal trigger button -->
   
   <!-- Modal Body -->
   <!-- if you want to close by clicking outside the modal, delete the last endpoint:data-bs-backdrop and data-bs-keyboard -->
   <div class="modal fade" id="modalId" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitleId">Level of Care</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="levelOfCareType" id="">
                          <label class="form-check-label" for="">
                            Routine*
                          </label>
                        </div>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="levelOfCareType" id=""  >
                          <label class="form-check-label" for="">
                            Inpatient (GIP)
                          </label>
                        </div>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="levelOfCareType" id="">
                          <label class="form-check-label" for="">
                            Continuous (CHC)*
                          </label>
                        </div>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="levelOfCareType" id=""  >
                          <label class="form-check-label" for="">
                            Respite*
                          </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Start Date*</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Place of Service*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Facility*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="mb-3">
                          <label for="" class="form-label">Reason*</label>
                          <textarea class="form-control" name="" id="" rows="3"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-blue">Submit</button>
            </div>
        </div>
    </div>
   </div>
   
   
   <!-- Optional: Place to the bottom of scripts -->
<?php include('./__components/footer.php')?>