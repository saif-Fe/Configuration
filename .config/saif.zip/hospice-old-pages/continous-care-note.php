<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Continuous Care Note</h1>
            <div class="col-3">
                <div class="mb-3 row">
                    <div class="col-3 d-flex align-items-center"><label for="" class="form-label">Clinician:</label>
                    </div>
                    <div class="col-9"><input type="text" name="" id="" class="form-control" placeholder=""></div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Patient Name (Last Name, First Name) & MRN:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" value="" id="">
                        <label class="form-check-label" for="">
                            Patient Identity Confirmed
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Mileage:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <p>Gender</p>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Male">
                        <label class="form-check-label" for="">M</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Female">
                        <label class="form-check-label" for="">F</label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Agency Name/ Branch:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Date:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Time In:</label>
                        <input type="time" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Time Out:</label>
                        <input type="time" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">DOB:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
            </div>
            <div class="bg-white p-3">
                <div class="section-header py-3">
                    <h2>Section 1</h2>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Discipline</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Start time</label>
                          <input type="time" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">End Time</label>
                          <input type="time" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white p-3">
                <div class="section-header py-3">
                    <h2>Vital Signs</h2>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>BP</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Position</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Side</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Heart Rate</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Respiration</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>O<sub>2</sub> Stat</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Temprature</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">Taken</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                        <div class="d-flex gap-3">
                            <div class="col">
                                <div class="mb-3">
                                  <label for="" class="form-label">Room Air Rate</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col">
                                <div class="mb-3">
                                  <label for="" class="form-label">Via Route</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="mb-3">
                          <label for="" class="form-label">Comments</label>
                          <input type="text"
                            class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white mt-3 p-3">
                <div class="section-header py-3">
                    <h2>Comments</h2>
                </div>
                <div class="mb-3">
                  <label for="" class="form-label" hidden>Comments</label>
                  <textarea class="form-control" name="" id="" rows="3"></textarea>
                </div>
            </div>
            <div class="bg-white p-3 mt-3">
                <div class="section-header py-3">
                    <h2>Section 2</h2>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Discipline</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Start time</label>
                          <input type="time" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">End Time</label>
                          <input type="time" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white p-3 mt-3">
                <div class="section-header py-3">
                    <h2>Vital Signs</h2>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>BP</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Position</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Side</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Heart Rate</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Respiration</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>O<sub>2</sub> Stat</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">/</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Temprature</strong></p>
                        <div class="mb-3">
                          <label for="" class="form-label">During</label>
                          <div class="d-flex">
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">Taken</span></div>
                            <div class="col"><input type="text" class="form-control" name="" id=""></div>
                        </div>
                        </div>
                        <div class="d-flex gap-3">
                            <div class="col">
                                <div class="mb-3">
                                  <label for="" class="form-label">Room Air Rate</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col">
                                <div class="mb-3">
                                  <label for="" class="form-label">Via Route</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="mb-3">
                          <label for="" class="form-label">Comments</label>
                          <input type="text"
                            class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white mt-3 p-3">
                <div class="section-header py-3">
                    <h2>Comments</h2>
                </div>
                <div class="mb-3">
                  <label for="" class="form-label" hidden>Comments</label>
                  <textarea class="form-control" name="" id="" rows="3"></textarea>
                </div>
            </div>
            <div class="bg-white p-3 mt-3">
                <div class="section-header py-3">
                    <h2>Plan of Care - Problems</h2>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Date Identified</th>
                                <th scope="col">Problem Description and Notes</th>
                                <th scope="col">Date Resolved</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="">
                                <td scope="row">-</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                            <tr class="">
                                <td scope="row">-</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>