<?php include('./__components/header.php') ?>

<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Smart QAPI</h1>
        </div>
        <div class="section-header my-3 mt-5 d-flex gap-2">
            <a href="" class="btn btn-blue">Smart QAPI Goals</a>
            <a href="" class="btn btn-blue">Patient Decline Report</a>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="section-header py-3">
                            <h2>
                                Golden Creek Enterprise
                            </h2>
                            <p>HIS Admission Measures Completion</p>
                        </div>
                    </div>
                    <div class="col-md-6">

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h2>Create And Monitor Your Custom QAPI Goals</h2>
        </div>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Current</th>
                        <th>Goal</th>
                        <th>Difference</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Goal Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php include('./__components/footer.php') ?>