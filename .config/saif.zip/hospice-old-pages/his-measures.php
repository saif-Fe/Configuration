<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between align-items-end">
            <div class="">
                <h1>HIS Measures</h1>
                <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span
                        class="patient-name fw-bold ms-1">(864)</span></p>
            </div>
            <div class="">
                <a name="" id="" class="btn btn-blue" href="#" role="button">Refresh Date</a>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" id="hisMeasuresTab" role="tablist">
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link active w-100" id="his-addmission-tab" data-bs-toggle="tab"
                        data-bs-target="#his-addmission" type="button" role="tab" aria-controls="his-addmission"
                        aria-selected="true">HIS Admission</button>
                </li>
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link w-100" id="his-discharge-tab" data-bs-toggle="tab"
                        data-bs-target="#his-discharge" type="button" role="tab" aria-controls="his-discharge"
                        aria-selected="false">HIS Discharge</button>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active" id="his-addmission" role="tabpanel" aria-labelledby="his-addmission-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <div class="section-header py-3 d-flex justify-content-between">
                            <h2>Administrative Information <span class="text-muted">/ Section A</span></h2>
                        </div>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="serviceOfAdmission" class="form-label">Site of Service at
                                        Admission</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="" class=""></option>
                                        <option value="0">Hospice in patient's home/residence</option>
                                        <option value="1">Hospice in Assisted Living facility</option>
                                        <option value="2">Hospice provided in Nursing Long Term Care (LTC) or
                                            Non-Skilled Nursing Facility (NF)</option>
                                        <option value="3">Hospice provided in a Skilled Nursing Facility (SNF)</option>
                                        <option value="4">Hospice provided in Inpatient Hospital</option>
                                        <option value="5">Hospice provided in Inpatient Hospice Facility</option>
                                        <option value="6">Hospice provided in Long Term Care Hospital (LTCH)</option>
                                        <option value="7">Hospice in Inpatient Psychiatric Facility</option>
                                        <option value="8">Hospice provided in a place not otherwise specified (NOS)
                                        </option>
                                        <option value="9" selected="selected">Hospice home care provided in a hospice
                                            facility</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Admission Date</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Initial Nursing Assessment Initiated</label>
                                    <input type="date" class="form-control" name="" id="">
                                    <small class="form-text text-muted"><input type="checkbox" name="" id=""
                                            class="me-2">Patient discharge prior to the start of the initial nursing
                                        assesment</small>
                                </div>
                                <p>Reason For Record</p>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="reasonForRecord" id="">
                                    <label class="form-check-label" for="">
                                        Admission
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="reasonForRecord" id="">
                                    <label class="form-check-label" for="">
                                        Discharge
                                    </label>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient First Name</label>
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient Middle Initial</label>
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient Last Name</label>
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient Name Suffix</label>
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Social Security Number</label>
                                    <input type="text" class="form-control" name="" id="" placeholder="000-00-0000">
                                    <small class="form-text text-muted"><input type="checkbox" name="" id=""
                                            class="me-2">Not Applicable</small>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient ZIP code</label>
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient Medicare/ Railroad Insurance Number</label>
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient Medicaid Number</label>
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                                <p>Gender</p>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="">
                                    <label class="form-check-label" for="">
                                        Male
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="gender" id="">
                                    <label class="form-check-label" for="">
                                        Female
                                    </label>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Birthdate</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <p>Payor Information</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Medicare (traditional fee-for-service)
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Medicare (managed care/Part C/Medicare Advantage)
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Medicaid (managed care)
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Other government (e.g., TRICARE, VA, etc.)
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Private Insurance/Medigap
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Private managed care
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Self-pay
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        No payor source
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        No payor source
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Unknown
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Other
                                    </label>
                                </div>
                                <p>Ethnicity</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        American Indian or Alaska Native
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Asian
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Black or African American
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Hispanic or Latino
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Native Hawaiian/Pacific Islander
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        White
                                    </label>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Admitted Form</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="" class=""></option>
                                        <option value="0">Community residential setting (e.g., private home/apt.,
                                            board/care, assisted living, group home, adult foster care)</option>
                                        <option value="1">Long-term care facility</option>
                                        <option value="2">Skilled Nursing Facility (SNF)</option>
                                        <option value="3">Hospital emergency department</option>
                                        <option value="4">Short-stay acute hospital (IPPS)</option>
                                        <option value="5">Long-term care hospital (LTCH)</option>
                                        <option value="6">Inpatient rehabilitation hospital or unit (IRF)</option>
                                        <option value="7">Psychiatric hospital or unit</option>
                                        <option value="8">ID/DD Facility</option>
                                        <option value="9">Hospice</option>
                                        <option value="10">None of the Above</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="section-header py-3 d-flex justify-content-between">
                            <h2>Preferences <span class="text-muted">/ Section F</span></h2>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Was Patient Asked About CPR?</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="0">No</option>
                                        <option value="1">Yes, and discussion occurred</option>
                                        <option value="2">Yes, but the patient/responsible party refused to discuss
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Asked About CPR</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Was Patient Asked About Treatments Other Than
                                        CPR?</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="0">No</option>
                                        <option value="1">Yes, and discussion occurred</option>
                                        <option value="2">Yes, but the patient/responsible party refused to discuss
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Asked about Treatment Other than the
                                        CPR?</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Was Patient Asked about Hospitalization?</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="0">No</option>
                                        <option value="1">Yes, and discussion occurred</option>
                                        <option value="2">Yes, but the patient/responsible party refused to discuss
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Asked About Hospitalization</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Was Patient Asked Spritual/Existent
                                        Concerns?</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="0">No</option>
                                        <option value="1">Yes, and discussion occurred</option>
                                        <option value="2">Yes, but the patient/responsible party refused to discuss
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Asked About Spritual/Existent Concerns</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                        <div class="section-header py-3 d-flex justify-content-between">
                            <h2>Health Conditions <span class="text-muted">/ Section J</span></h2>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-header py-3 d-flex justify-content-between">
                                    <h4>Pain Screening</h4>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <p>Was Patient Screened for Pain?</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="screenedForPain" id="">
                                    <label class="form-check-label" for="">
                                        No
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="screenedForPain" id="">
                                    <label class="form-check-label" for="">
                                        Yes
                                    </label>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date of First Screening for Pain</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Patient's Pain Severity Was</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="" class=""></option>
                                        <option value="0">None</option>
                                        <option value="1">Mild</option>
                                        <option value="2">Moderate</option>
                                        <option value="3">Severe</option>
                                        <option value="4">Pain not rated</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Type of Standardized Pain Screening tool
                                        used</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="" class=""></option>
                                        <option value="0">Numeric</option>
                                        <option value="1">Verbal descriptor</option>
                                        <option value="2">Patient visual</option>
                                        <option value="3">Staff observation</option>
                                        <option value="4">No standardized tool used</option>
                                    </select>
                                </div>
                                <p>Is Pain an active problem for the Patient?</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="painAProblem" id="">
                                    <label class="form-check-label" for="">
                                        No
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="painAProblem" id="">
                                    <label class="form-check-label" for="">
                                        Yes
                                    </label>
                                </div>
                                <p>Was Comprehensive Pain Assessment Done?</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="painAProblem" id="">
                                    <label class="form-check-label" for="">
                                        No
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="painAProblem" id="">
                                    <label class="form-check-label" for="">
                                        Yes
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Date of Comprehensive Pain Assessment</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                                <p>Pain Assessment Included</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Location
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Severity
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Duration
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Frequency
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        What relieves/worsens pain
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Effect of function or quality of life
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        None of the above
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="section-header py-3 d-flex justify-content-between">
                                    <h4>Shortness of Breath Screening</h4>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <p>Was Patient Screened for Shortness of Breath</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="screenedForShortnessOfBreath"
                                        id="">
                                    <label class="form-check-label" for="">
                                        No
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="screenedForShortnessOfBreath"
                                        id="">
                                    <label class="form-check-label" for="">
                                        Yes
                                    </label>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date of First Screening for Shortness of
                                        Breath</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Was Treatment for Shortness of Breath
                                        Initiated</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option value="0">No</option>
                                        <option value="1">No, patient declined treatments offered</option>
                                        <option value="2">Yes</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Treatment of Shortness of Breath
                                        Initiated</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <p>Treatments for Shortness of Breath</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Opioids
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Other Med
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Oxygen
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        Non-Med
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="section-header py-3 d-flex justify-content-between">
                            <h2>Medication <span class="text-muted">/ Section N</span></h2>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <p>Was Scheduled Opioid Initiated or Continued?</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="isScheduledOpioidInitiated"
                                        id="">
                                    <label class="form-check-label" for="">
                                        No
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="isScheduledOpioidInitiated"
                                        id="">
                                    <label class="form-check-label" for="">
                                        Yes
                                    </label>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Scheduled Opioid Initiated or
                                        Continued?</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                                <p>Was PRN Opioid Initiated or Continued?</p>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="isPRNOpioidInitiated" id="">
                                    <label class="form-check-label" for="">
                                        No
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" name="isPRNOpioidInitiated" id="">
                                    <label class="form-check-label" for="">
                                        Yes
                                    </label>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Opioid Initiated or Continued</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Was Bowel Regimen Initiated or Continued></label>
                                    <select class="form-select w-100" name="" id="">
                                        <option selected></option>
                                        <option value="1">No</option>
                                        <option value="2">No, but there is documentation of why a bowel regimen was not
                                            initiated or continued</option>
                                        <option value="3">Yes</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Date Bowel Regimen Initiated or Continued</label>
                                    <input type="date" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="his-discharge" role="tabpanel" aria-labelledby="his-discharge-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <div class="section-header py-3 d-flex justify-content-between">
                            <h2>Administrative Information <span class="text-muted">/ Section A</span></h2>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                  <label for="" class="form-label">Admission Date</label>
                                  <input type="date" class="form-control" name="" id="">
                                </div>
                                <p>Reason for Record</p>
                                <div class="form-check">
                                  <input class="form-check-input" type="radio" name="reasonToRecord" id="">
                                  <label class="form-check-label" for="">
                                    Admission
                                  </label>
                                </div>
                                <div class="form-check">
                                  <input class="form-check-input" type="radio" name="reasonToRecord" id=""  >
                                  <label class="form-check-label" for="">
                                    Discharge
                                  </label>
                                </div>
                                <div class="mb-3">
                                  <label for="" class="form-label">Discharge Date</label>
                                  <input type="date" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                  <label for="" class="form-label">Patient First Name</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                  <label for="" class="form-label">Patient Last Name</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                  <label for="" class="form-label">Patient Name Suffix</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                  <label for="" class="form-label">Social Security Number</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" value="" id="notApplicable">
                                  <label class="form-check-label" for="notApplicable">
                                    Not Applicable
                                  </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                  <label for="" class="form-label">Patient Medicare/Railroad Insurance Number</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                  <label for="" class="form-label">Patient Medicaid Number</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                                <p>Gender</p>
                                <div class="form-check mb-3">
                                  <input class="form-check-input" type="radio" name="gender" id="">
                                  <label class="form-check-label" for="">
                                    Male
                                  </label>
                                </div>
                                <div class="form-check mb-3">
                                  <input class="form-check-input" type="radio" name="gender" id=""  >
                                  <label class="form-check-label" for="">
                                    Female
                                  </label>
                                </div>
                                <div class="mb-3">
                                  <label for="" class="form-label">Birthdate</label>
                                  <input type="date" class="form-control" name="" id="">
                                </div>
                                <div class="mb-3">
                                    <label for="" class="form-label">Reason for Discharge</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option selected></option>
                                        <option value="0">Expired</option>
                                        <option value="1">Revoked</option>
                                        <option value="2">No longer terminally ill</option>
                                        <option value="3">Moved out of hospice service area</option>
                                        <option value="4">Transferred to another hospice</option>
                                        <option value="5">Discharged for cause</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                        <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5 mt-3">
                            <div class="section-header py-3 d-flex justify-content-between">
                                <h2>Record Administration <span class="text-muted">/ Section Z</span></h2>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="section-header py-3 d-flex justify-content-between">
                                        <h4>Signature(s) of Person Completing the Record</h4>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Signature</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                    <div class="mb-3">
                                        <label for="" class="form-label">Title</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                    <p>Section(s)</p>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="A">
                                        <label class="form-check-label" for="">A</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="B">
                                        <label class="form-check-label" for="">F</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="I">
                                        <label class="form-check-label" for="">I</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="J">
                                        <label class="form-check-label" for="">J</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="N">
                                        <label class="form-check-label" for="">N</label>
                                    </div>
                                    <div class="mb-3">
                                        <label for="" class="form-label">Date Sectio(s) Completed</label>
                                        <input type="date" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="section-header py-3 d-flex justify-content-between">
                                        <h4>Signature(s) of Person Verifying Record Completion</h4>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Signature</label>
                                        <div class="d-flex gap-3">
                                            <input type="text" class="form-control" name="" id="">
                                            <input type="date" class="form-control" name="" id="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex gap-3">
            <a href="#" class="btn btn-grey ms-auto">Save</a>
            <a href="#" class="btn btn-grey">Complete</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>