<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Medication Profile</h1>
            <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span class="patient-name fw-bold ms-1">(864)</span></p>
            <p>DOB<span class="dob ms-1 fw-bold">10/10/1957</span></p>
            <p>Phone<span class="patient-phone ms-1 fw-bold">1234567890</span></p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header">
                <h5 class="text-center">
                    <span class="start-date fw-bold">10/15/2022</span>
                    -
                    <span class="end-date fw-bold">01/12/2023</span>
                </h5>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Pharmacy</h2>
            </div>
            <div class="bg-white p-3">
                <a href="#" data-bs-toggle="modal" data-bs-target="#UpdatePharmacy">Update Preferred Pharmacy</a>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Allergy Profile</h2>
            </div>
            <div class="bg-white p-3">
                <div class="form-check mb-3">
                    <input class="form-check-input" type="radio" name="AllergyProfile" id="allergyFromNka" value="nka"
                        onchange="displaySubstanceReaction(this)">
                    <label class="form-check-label" for="allergyFromNka">
                        NKA (Food/ Drug/ Latex/ Enviormental)
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="AllergyProfile" id="allergyFromSensivities"
                        value="AllergiesAndSensitivities" onchange="displaySubstanceReaction(this)">
                    <label class="form-check-label" for="allergyFromSensivities">
                        Allergies and Sensitivities
                    </label>
                </div>
                <div class="substance-reaction__cont mt-3" style="display:none;">
                    <div class="substance-reaction">
                        <div class="table-responsive">
                            <table class="table 
                                table-hover	
                                table-borderless
                                
                                align-middle">
                                <thead>
                                    <tr>
                                        <th>Substance</th>
                                        <th>Reaction</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td scope="row" class="p-1">
                                            <label for="" class="form-label" hidden>Substance</label>
                                            <input type="text" class="form-control" name="substance"
                                                list="substanceList">
                                            <datalist id="substanceList">
                                                <option value="Select One">
                                                <option value="-">
                                            </datalist>
                                        </td>
                                        <td class="p-1">
                                            <div>
                                                <label for="" class="form-label" hidden>Reaction</label>
                                                <input type="text" class="form-control" name="" id="">
                                            </div>
                                        </td>
                                        <td class="p-1">
                                            <input name="" id="addAllergy" class="btn btn-blue" type="button"
                                                value="Add">
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Add new Medication</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div>
                            <label for="" class="form-label">Select Medication Type</label>
                            <select class="form-select w-100" name="" id="" onchange="addNewMed(this)">
                                <option selected>Select one</option>
                                <option value="medication">Medication</option>
                                <option value="offMarket">Off Market/ Unlisted</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-end justify-content-end">
                        <a name="" id="" class="btn btn-blue me-1" href="#" role="button">Generate Order</a>
                        <a name="" id="" class="btn btn-blue me-1" href="#" role="button">Medication Reconcilation/ Snapshot</a>
                    </div>
                </div>
            </div>
            <div class="new-medication__cont" style="display:none;">
                <div class="bg-white p-3 my-3">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-check form-check-inline mb-3">
                                <input class="form-check-input" type="checkbox" id="newMedLongstanding"
                                    value="longstanding">
                                <label class="form-check-label" for="newMedLongstanding">Longstanding</label>
                            </div>
                            <div class="form-check form-check-inline mb-3">
                                <input class="form-check-input" type="checkbox" id="newMedChange" value="change">
                                <label class="form-check-label" for="newMedChange">second</label>
                            </div>
                            <div class="form-check form-check-inline mb-3">
                                <input class="form-check-input" type="checkbox" id="newMedNew" value="new">
                                <label class="form-check-label" for="newMedNew">disabled</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="" class="form-label">Search By NDC</label>
                                <div class="d-flex">
                                    <input type="text" class="form-control" name="" id="">
                                    <input type="button" class="btn btn-blue" value="Search">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Medication name</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Form</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Route</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Strenght</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Start Date</label>
                                <input type="date" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Quantity Dispensed</label>
                                <div class="d-flex">
                                    <input type="text" class="form-control" name="" id="">
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Frequency</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="">
                                <label class="form-check-label" for="">
                                    Compound
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="">
                                <label class="form-check-label" for="">
                                    OTC
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="">
                                <label class="form-check-label" for="">
                                    PRN
                                </label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">End Date</label>
                                <input type="date" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Unit Per Dose</label>
                                <div class="d-flex">
                                    <input type="text" class="form-control" name="" id="">
                                    <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Medication Instruction</label>
                                <textarea class="form-control" name="" id="" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Indication</label>
                                <input type="date" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="">
                                <label class="form-check-label" for="">
                                    Dispense as written
                                </label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="" class="form-label">Dosage and Administration</label>
                                <textarea class="form-control" name="" id="" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <p>Is Medication Covered?</p>
                            <div class="form-check form-check-inline mb-3">
                                <input class="form-check-input" type="radio" name="isMedCovered" id="medCovered"
                                    value="yes">
                                <label class="form-check-label" for="medCovered">Yes</label>
                            </div>
                            <div class="form-check form-check-inline mb-3">
                                <input class="form-check-input" type="radio" name="isMedCovered" id="medNotCovered"
                                    value="no">
                                <label class="form-check-label" for="medNotCovered">No</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="" class="form-label">NDC</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected>00067004419</option>
                                    <option value="-">-</option>
                                    <option value="-">-</option>
                                    <option value="-">-</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="" class="form-label">Related Dignosis</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected>G10 - Huntington's Disease</option>
                                    <option value="-">-</option>
                                    <option value="-">-</option>
                                    <option value="-">-</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="" class="form-label">HCPCS</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <p>Is Medication For Infusion Pump?</p>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="isInfusionPumpIncluded"
                                    id="infusionPumpIncluded">
                                <label class="form-check-label" for="infusionPumpIncluded">
                                    Yes
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="isInfusionPumpIncluded"
                                    id="infusionPumpNotIncluded">
                                <label class="form-check-label" for="infusionPumpNotIncluded">
                                    No
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <p>Is Medication Injectable?</p>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio" name="isMedicationInjectable"
                                    id="medicationInjectable">
                                <label class="form-check-label" for="infusionPumpIncluded">
                                    Injectable
                                </label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio" name="isMedicationInjectable"
                                    id="medicationNotInjectable">
                                <label class="form-check-label" for="infusionPumpNotIncluded">
                                    Not-injectable
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="" class="form-label">PT/GF taught to safely administer Medication?</label>
                                <select class="form-select w-100" name="" id="">
                                    <option selected>Yes</option>
                                    <option value="-">No</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                              <label for="" class="form-label">Patient Instruction</label>
                              <textarea class="form-control" name="" id="" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 d-flex justify-content-end gap-3">
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Save</a>
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Save and Add Additional</a>
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Future Medication</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th class="align-top w-auto"><input type="checkbox" name="" id=""></th>
                        <th>
                            <p>Start: 11/03/2022</p>
                            <p><a href="#" data-bs-toggle="modal" data-bs-target="#editMedModal">Benefiber Oral Tablet Chewable</a></p>
                            <p>Dose:</p>
                            <p>Frequency: </p>
                            <p>Indication: </p>
                            <p>Instruction:</p>
                            <p>Classification:</p>
                            <p class="fw-bold">Covered</p>
                        </th>
                        <th class="align-top">
                            Discontinue: 11/11/2022
                        </th>
                        <th class="align-top">
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Delete</a>
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Current Medication</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th class="align-top w-auto"><input type="checkbox" name="" id=""></th>
                        <th>
                            <p>Start: 11/03/2022</p>
                            <p><a href="#" data-bs-toggle="modal" data-bs-target="#editMedModal">Benefiber Oral Tablet Chewable</a></p>
                            <p>Dose:</p>
                            <p>Frequency: </p>
                            <p>Indication: </p>
                            <p>Instruction:</p>
                            <p>Classification:</p>
                            <p class="fw-bold">Covered</p>
                        </th>
                        <th class="align-top">
                            Discontinue: 11/11/2022
                        </th>
                        <th class="align-top">
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Delete</a>
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Discontinued Medications</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th class="align-top w-auto"><input type="checkbox" name="" id=""></th>
                        <th>
                            <p>Start: 11/03/2022</p>
                            <p><a href="#" data-bs-toggle="modal" data-bs-target="#editMedModal">Benefiber Oral Tablet Chewable</a></p>
                            <p>Dose:</p>
                            <p>Frequency: </p>
                            <p>Indication: </p>
                            <p>Instruction:</p>
                            <p>Classification:</p>
                            <p class="fw-bold">Covered</p>
                        </th>
                        <th class="align-top">
                            Discontinue: 11/11/2022
                        </th>
                        <th class="align-top">
                            <a name="" id="" class="btn btn-blue" href="#" role="button">Delete</a>
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Body -->
<!-- if you want to close by clicking outside the modal, delete the last endpoint:data-bs-backdrop and data-bs-keyboard -->
<div class="modal fade" id="UpdatePharmacy" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
    role="dialog" aria-labelledby="preferredPharmacy" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable  " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="preferredPharmacy">Update Preferred Pharmacy</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="" class="form-label">Pharmacy</label>
                    <select class="form-select w-100" name="" id="">
                        <option selected>Select one</option>
                        <option value="-">-</option>
                        <option value="-">-</option>
                        <option value="">-</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-blue">Update Pharmacy</button>
                <button type="button" class="btn btn-grey" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="editMedModal" tabindex="-1" role="dialog" aria-labelledby="EditMedicine" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-fullscreen" role="document">
        <div class="modal-content">
                <div class="modal-header">
                        <h5 class="modal-title" id="EditMedicine">Edit Medicine</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="new-medication__cont">
                        <div class="bg-white p-3 my-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-check form-check-inline mb-3">
                                        <input class="form-check-input" type="checkbox" id="newMedLongstanding"
                                            value="longstanding">
                                        <label class="form-check-label" for="newMedLongstanding">Longstanding</label>
                                    </div>
                                    <div class="form-check form-check-inline mb-3">
                                        <input class="form-check-input" type="checkbox" id="newMedChange" value="change">
                                        <label class="form-check-label" for="newMedChange">second</label>
                                    </div>
                                    <div class="form-check form-check-inline mb-3">
                                        <input class="form-check-input" type="checkbox" id="newMedNew" value="new">
                                        <label class="form-check-label" for="newMedNew">disabled</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Search By NDC</label>
                                        <div class="d-flex">
                                            <input type="text" class="form-control" name="" id="">
                                            <input type="button" class="btn btn-blue" value="Search">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Medication name</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Form</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Route</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Strenght</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Start Date</label>
                                        <input type="date" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Quantity Dispensed</label>
                                        <div class="d-flex">
                                            <input type="text" class="form-control" name="" id="">
                                            <input type="text" class="form-control" name="" id="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Frequency</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="">
                                        <label class="form-check-label" for="">
                                            Compound
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="">
                                        <label class="form-check-label" for="">
                                            OTC
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="">
                                        <label class="form-check-label" for="">
                                            PRN
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">End Date</label>
                                        <input type="date" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Unit Per Dose</label>
                                        <div class="d-flex">
                                            <input type="text" class="form-control" name="" id="">
                                            <input type="text" class="form-control" name="" id="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Medication Instruction</label>
                                        <textarea class="form-control" name="" id="" rows="2"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Indication</label>
                                        <input type="date" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="">
                                        <label class="form-check-label" for="">
                                            Dispense as written
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Dosage and Administration</label>
                                        <textarea class="form-control" name="" id="" rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <p>Is Medication Covered?</p>
                                    <div class="form-check form-check-inline mb-3">
                                        <input class="form-check-input" type="radio" name="isMedCovered" id="medCovered"
                                            value="yes">
                                        <label class="form-check-label" for="medCovered">Yes</label>
                                    </div>
                                    <div class="form-check form-check-inline mb-3">
                                        <input class="form-check-input" type="radio" name="isMedCovered" id="medNotCovered"
                                            value="no">
                                        <label class="form-check-label" for="medNotCovered">No</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="" class="form-label">NDC</label>
                                        <select class="form-select w-100" name="" id="">
                                            <option selected>00067004419</option>
                                            <option value="-">-</option>
                                            <option value="-">-</option>
                                            <option value="-">-</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Related Dignosis</label>
                                        <select class="form-select w-100" name="" id="">
                                            <option selected>G10 - Huntington's Disease</option>
                                            <option value="-">-</option>
                                            <option value="-">-</option>
                                            <option value="-">-</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="" class="form-label">HCPCS</label>
                                        <input type="text" class="form-control" name="" id="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <p>Is Medication For Infusion Pump?</p>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="isInfusionPumpIncluded"
                                            id="infusionPumpIncluded">
                                        <label class="form-check-label" for="infusionPumpIncluded">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="isInfusionPumpIncluded"
                                            id="infusionPumpNotIncluded">
                                        <label class="form-check-label" for="infusionPumpNotIncluded">
                                            No
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <p>Is Medication Injectable?</p>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="radio" name="isMedicationInjectable"
                                            id="medicationInjectable">
                                        <label class="form-check-label" for="infusionPumpIncluded">
                                            Injectable
                                        </label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="radio" name="isMedicationInjectable"
                                            id="medicationNotInjectable">
                                        <label class="form-check-label" for="infusionPumpNotIncluded">
                                            Not-injectable
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="" class="form-label">PT/GF taught to safely administer Medication?</label>
                                        <select class="form-select w-100" name="" id="">
                                            <option selected>Yes</option>
                                            <option value="-">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                    <label for="" class="form-label">Patient Instruction</label>
                                    <textarea class="form-control" name="" id="" rows="3"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-blue">Save</button>
                <button type="button" class="btn btn-blue">Save and Add Additional</button>
                <button type="button" class="btn btn-grey" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>

</div>
<!-- Button trigger modal -->
<?php include('./__components/footer.php')?>