<?php include('./__components/header.php') ?>

<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Volunteer Services</h1>
            <button type="button" class="btn btn-blue" data-bs-toggle="modal"
                data-bs-target="#volunteerServices">
                add administrative hours
            </button>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <form>
                <div class="mb-3 row">
                    <div class="mb-3 col-md-6">
                        <label for="branch" class="form-label">Branch</label>
                        <select class="form-control" name="branch" id="branch">
                            <option>Golden Creek Enterprises LLC</option>
                            <option>Golden Creek Enterprises LLC</option>
                            <option>Jakarta</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <div class="mb-3 col-md-3">
                        <label for="" class="form-label">Start Date</label>
                        <input type="date" name="" id="" class="w-100">
                    </div>
                    <span class="col-auto d-flex align-items-center">to</span>
                    <div class="mb-3 col-md-3">
                        <label for="" class="form-label">End Date</label>
                        <input type="date" name="" id="" class="w-100">
                    </div>
                    <div class="col-auto d-flex"><button type="submit" class="btn-blue mt-auto mb-3">Filter</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Date</th>
                        <th>Volunteer Name</th>
                        <th>Activity Type</th>
                        <th>Hours</th>
                        <th>Details</th>
                        <th>Edit</th>
                        <th>Deactivate</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td> - </td>
                        <td> - </td>
                        <td> - </td>
                        <td> - </td>
                        <td> - </td>
                        <td> - </td>
                        <td> - </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    </div>
    <!-- Button trigger modal -->

    <!-- Modal -->
    <div class="modal fade" id="volunteerServices" tabindex="-1" role="dialog" aria-labelledby="administratorAddHours"
        aria-hidden="true">
        <div class="modal-dialog modal-lg " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="administratorAddHours">Add new Hours</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="" class="form-label">Branch</label>
                                <select class="form-control" name="" id="">
                                    <option>Golden Creek Enterprises LCC</option>
                                    <option>-</option>
                                    <option>-</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="" class="form-label">Volunteer</label>
                                <select class="form-control" name="" id="">
                                    <option>Name</option>
                                    <option>-</option>
                                    <option>-</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Time In*</label>
                                <input type="time" name="" id="" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Time Out*</label>
                                <input type="time" name="" id="" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="col-md-3 me-5 me-sm-0">
                            <div class="mb-3">
                                <label for="" class="form-label">Total Hours</label>
                                <input type="text" name="" id="" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="" class="form-label">Activity Type</label>
                                <select class="form-control" name="" id="">
                                    <option>-</option>
                                    <option>-</option>
                                    <option>-</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="" class="form-label">Activity Date*</label>
                                <input type="date" name="" id="" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Comments*</label>
                            <textarea class="form-control" name="" id="" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-grey" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-blue">Save and Add Another</button>
                    <button type="button" class="btn btn-blue">Save</button>
                </div>
            </div>
        </div>
    </div>




    <?php include('./__components/footer.php') ?>