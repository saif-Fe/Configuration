<?php include('./__components/header.php') ?>

<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Patient Communication</h1>
        </div>
    </div>
    <form action="">
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-6">
                    <div class="my-3">
                      <label for="new-com-patient-date" class="w-100 form-label">Date</label>
                      <input type="date" name="" id="new-com-patient-date">
                    </div>
                    <div class="mb-3">
                      <label for="new-com-physician" class="form-label">Physician:</label>
                      <select class="form-control" name="new-com-physician" id="new-com-physician">
                        <option>Select</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="my-3">
                      <label for="new-com-patient-name" class="form-label">Patient Name:</label>
                      <select class="form-control" name="new-com-patient-name" id="new-com-patient-name">
                        <option>Select</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label for="new-con-patient-phone" class="form-label">Phone</label>
                      <input type="phone" name="new-con-patient-phone" id="new-con-patient-phone" class="form-control" placeholder="" disabled>
                    </div>
                    <div class="mb-3">
                      <label for="new-con-terminal-dig" class="form-label">Terminal Dignosis</label>
                      <input type="text" name="new-con-terminal-dig" id="new-con-terminal-dig" class="form-control" placeholder="" disabled>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Communication Text</h2>
            </div>
            <div class="mb-3">
              <label for="new-con-use-temp" class="form-label">Use Template:</label>
              <select class="form-control w-50" name="new-con-use-temp" id="new-con-use-temp">
                <option>Select</option>
                <option>-</option>
                <option>-</option>
              </select>
            </div>
            <div class="mb-3">
              <textarea class="form-control" name="" id="" rows="10"></textarea>
            </div>
            <input type="submit" value="Add Communication" class="btn btn-blue">
        </div>
    </div>
</form>
</section>

<?php include('./__components/footer.php') ?>
