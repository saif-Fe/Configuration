<?php include('./__components/header.php') ?>
<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>QA Manager</h1>
            <a href="" class="btn-red text-center d-flex align-items-center justify-content-center">Reset filter</a>
        </div>
        <div class="bg-grey py-3">
            <div class="row">
                <div class="col-md-6">
                    <form class="d-flex flex-wrap">
                        <div class="col-md-12 d-flex">
                            <div class="col-auto"><label for="visitType" class="form-label me-5">Visit Type</label>
                            </div>
                            <div class="col-auto">
                                <div class="mb-3">
                                    <select id="" class="form-select">
                                        <option>All</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 d-flex">
                            <div class="col-auto"><label for="visitType" class="form-label me-5">Case Manager</label>
                            </div>
                            <div class="col-auto">
                                <div class="mb-3">
                                    <select id="" class="form-select">
                                        <option>All</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 d-flex">
                            <div class="col-auto"><label for="visitType" class="form-label me-5">Date Range</label>
                            </div>
                            <div class="col-auto">
                                <div class="mb-3">
                                    <input type="date" name="" id="">
                                    <span>
                                        to
                                    </span>
                                    <input type="date" name="" id="">
                                </div>
                            </div>
                            <div class="col-auto">
                                <input type="submit" class="btn-blue" value="Apply Filter">
                            </div>
                        </div>

                    </form>
                    <div class="col-md-6"></div>
                </div>
                <div class="col-md-6">
                    <p class="text-end"><strong>Visits In Italics</strong> have been added or edited within the past 48 hours.</p>
                    <p class="text-end"><strong>Visits In red</strong> occurred in benefit periods that have already ended.</p>
                </div>
            </div>
        </div>
        <div class="section-header my-3 mt-5">
            <h2>Golden Creek Enterprises LLC, all visit types, all Case Managers, from 07/19/2022 to 08/19/2022</h2>
        </div>
        <div class="bg-grey d-flex justify-content-between pt-3 align-items-center">
                <p>No items selected, <a href="">Select all items across all pages.</a></p>
                <p><a href="">Export all data</a></p>
        </div>
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Form</th>
                        <th>Subject</th>
                        <th>Patient</th>
                        <th>Date</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="checkbox" name="" id=""></td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="" id=""></td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="" id=""></td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="" id=""></td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
</section>

<?php include('./__components/footer.php') ?>