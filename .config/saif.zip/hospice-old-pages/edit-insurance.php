<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
        <h1>Patient Insurance</h1>
        <p><span class="last-name me-1">Bond</span>,<span class="first-name me-1">James</span><span class="pat-number me-1">(846) </span></p>
        </div>
    </div>
    <div class="bg-grey">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Insurance</h2>
            </div>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th colspan="2">Fill Date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><a href="add-new-insurance.php">Palmetto GBA</a></td>
                        <td class="text-end"><a href="./add-new-insurance.php">Delete</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex">
            <a href="./add-new-insurance.php" class="btn btn-grey ms-auto">Add Patient Insurance</a>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>