<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>User Manager</h1>
            <p>New User Confirmation</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <p><strong>September 26, 2022</strong></p>
<p>Name: <strong>Bell TESTFrye</strong></p>
<p>User Name: <strong>zosiqyryqa</strong></p>
<p>temporary password: <strong>nam officiis quo sed</strong></p>
<p> You will be prompted to change this password on your first login attempt.  If applicable, you will create an Electronic Signature the first time you attempt to sign a document online.  </p>
 
<h4>InBox</h4>
<p>Your K-mail InBox is an intra-agency messaging system. Like a typical e-mail program, you can compose and reply to messages, as well as create address groups. Unlike your regular e-mail, however, the K-mail InBox is HIPAA-compliant to allow you to communicate specific patient information with other members of your agency. Messages cannot be forwarded to anyone outside of the agency to protect patient privacy.</p>
 
<h4>HotBox</h4>
<p>The HotBox contains a list of tasks that have been assigned to you. If you have incomplete or new tasks, the HotBox page will be displayed immediately after you log in. The HotBox list may include, for example, scheduled evaluations, nursing progress notes, assessments, or supervisory visits. To view and complete the task, click the patient's name next to the assigned task.</p>
 
<h4>Missed Visit</h4>
<p>If you are unable to complete a task within the assigned timeframe, click Missed Visit next to the HotBox task that was missed. For visits completed a day or two later than assigned within Agency Manager, however, simply insert the correct date on the task form.  Print this page to give to the user.</p>

<p>After printing, click Complete User Setup to assign roles and permissions for this user.</p>
        </div>
    </div>
      <div class="bg-blue py-3">
          <div class="container container__custom">
              <button type="submit" class="btn btn-grey" onclick="location.href = './edit-roles.php';">Complete User Setup</button>
          </div>
      </div>
</div>
<?php include('./__components/footer.php') ?>
