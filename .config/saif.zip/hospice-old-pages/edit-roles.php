<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Edit Roles</h1>
            <p>Username</p>
        </div>
        <div class="section-header my-3 mt-5">
            <h2>Golden Creek Enterprises LLC</h2>
        </div>
        <div class="bg-grey">
            <div class="container container__custom p-0">
                <div class="section-table">
                    <table id="table_id" class="display w-100">
                        <thead class="bg-red">
                            <tr>
                                <th colspan="2"><h5>Billing Manager</h5></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Claims Manager
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user to access Claims Manager and bill claims</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Billing Reports
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user to see billing reports</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Hard Close
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user to perform Hard Close</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Hard Close Read-Only
                                      </label>
                                    </div>
                                </td>
                                <td>Allows read-only access to Hard Close</td>
                            </tr>
                        </tbody>
                        <thead class="bg-red">
                            <tr>
                                <th colspan="2"><h5>Distribution Lists</h5></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access InBox
                                      </label>
                                    </div>
                                </td>
                                <td>Access K-mail InBox (default)</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Receive Billing Summary
                                      </label>
                                    </div>
                                </td>
                                <td>Receive a message when a claim file is generated</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Receive Eligibility Report
                                      </label>
                                    </div>
                                </td>
                                <td>Receive summary of eligibility inquiry</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Receive Faxes
                                      </label>
                                    </div>
                                </td>
                                <td>Receive faxes in K-mail InBox when E-Fax is configured</td>
                            </tr>
                        </tbody>
                        <thead class="bg-red">
                            <tr>
                                <th colspan="2"><h5>Job Functions</h5></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Bereavement Coordinator
                                      </label>
                                    </div>
                                </td>
                                <td>Complete Bereavement Coordinator tasks</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Case Manager
                                      </label>
                                    </div>
                                </td>
                                <td>Review and approve submitted documentation</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Chaplain/Counselor
                                      </label>
                                    </div>
                                </td>
                                <td>Complete chaplain / counselor tasks and write notes</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Clinical Review
                                      </label>
                                    </div>
                                </td>
                                <td>Review, but not approve, submitted documentation</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Clinician
                                      </label>
                                    </div>
                                </td>
                                <td>Complete nursing visits, evaluations, and other documentation</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         HHA
                                      </label>
                                    </div>
                                </td>
                                <td>Complete home health aide tasks, and write notes</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        MSW
                                      </label>
                                    </div>
                                </td>
                                <td>Complete social work tasks, and write notes</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Physician
                                      </label>
                                    </div>
                                </td>
                                <td>Physician</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Therapist
                                      </label>
                                    </div>
                                </td>
                                <td>Complete therapy visits, and write evaluations and documentation</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Volunteer
                                      </label>
                                    </div>
                                </td>
                                <td>Complete volunteer work tasks, and write notes</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Volunteer Coordinator
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user to access Volunteer Services</td>
                            </tr>
                        </tbody>
                        <thead class="bg-red">
                            <tr>
                                <th colspan="2"><h5>Specific Rights</h5></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access IDG Meeting
                                      </label>
                                    </div>
                                </td>
                                <td>	Access IDG Meeting</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Insurance Admin
                                      </label>
                                    </div>
                                </td>
                                <td>Allows access to insurance functionality</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Level of Care Manager
                                      </label>
                                    </div>
                                </td>
                                <td>Access Level of Care Manager services</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Patient Fall Tracker
                                      </label>
                                    </div>
                                </td>
                                <td>Allows access to the Patient Fall Tracker dashboard</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Patient Manager
                                      </label>
                                    </div>
                                </td>
                                <td>Access Patient Manager services</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Access Patient Roster
                                      </label>
                                    </div>
                                </td>
                                <td>Generate and print a patient roster</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Access Patient Schedules
                                      </label>
                                    </div>
                                </td>
                                <td>Manage patient scheduling, including task creation and deletion</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Payroll Manager
                                      </label>
                                    </div>
                                </td>
                                <td>Access payroll functions</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Phone Roster
                                      </label>
                                    </div>
                                </td>
                                <td>Access Phone Roster</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Reports/Admin
                                      </label>
                                    </div>
                                </td>
                                <td>Access Reports / Admin services</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Access Volunteer Manager
                                      </label>
                                    </div>
                                </td>
                                <td>Access Volunteer Manager services</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Add & Edit Patient Information
                                      </label>
                                    </div>
                                </td>
                                <td>Add patients and edit current patient information</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Administrator
                                      </label>
                                    </div>
                                </td>
                                <td>Reopen previously approved documents</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Approve assessment 
                                      </label>
                                    </div>
                                </td>
                                <td>Approve assessment forms</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                               Approve Plan of Care
                                      </label>
                                    </div>
                                </td>
                                <td>Approve Plan of Care</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Bypass Case Management
                                      </label>
                                    </div>
                                </td>
                                <td>	Bypass case management to sign and complete a document</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Filter QA Manager and Hotbox
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user to select filters in the QA Manager and Hotbox before the data is loaded</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Generate Telephone Orders
                                      </label>
                                    </div>
                                </td>
                                <td>Generate a telephone order</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        HIS Administrator
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user to reopen previously exported documents as well as final signature and submission of HIS Measures</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Import Pharmacy Refill Data
                                      </label>
                                    </div>
                                </td>
                                <td>Access to import pharmacy refill data</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Infection Control Administrator
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user full access rights to the Infection Control Dashboard</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Kinnser DM
                                      </label>
                                    </div>
                                </td>
                                <td>Access to Kinnser Direct Messaging section on Pending Admissions</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Kinnser DM Administration
                                      </label>
                                    </div>
                                </td>
                                <td>Ability to access Kinnser DM settings</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Manage Tasks and Settings
                                      </label>
                                    </div>
                                </td>
                                <td>Allows access to visit types and task details links so user can manage visit types</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Orders Management
                                      </label>
                                    </div>
                                </td>
                                <td>Document orders sent to, and returned from, physicians</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Patient Medication Refill Data
                                      </label>
                                    </div>
                                </td>
                                <td>Access to view and edit medications uploaded via pharmacy import tool</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Patient Referral Source
                                      </label>
                                    </div>
                                </td>
                                <td>Be listed as a referral source for new patients</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                          Prefill Documents
                                      </label>
                                    </div>
                                </td>
                                <td>Prefill clinical content from most recent document into current document</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                          PRN Access
                                      </label>
                                    </div>
                                </td>
                                <td>Manage patient scheduling including task creation</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Reschedule Clinician Tasks
                                      </label>
                                    </div>
                                </td>
                                <td>Allows clinician to change visit date within Medicare week for tasks assigned to that clinician in the HotBox</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Search
                                      </label>
                                    </div>
                                </td>
                                <td>Search the application for specific names or tasks</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Update Only: Claim Comments
                                      </label>
                                    </div>
                                </td>
                                <td>Allows user to only update claim comments by adding a individual comments & follow-ups or in bulk</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         Use Electronic Signature
                                      </label>
                                    </div>
                                </td>
                                <td>Create a signature passcode and sign documents electronically</td>
                            </tr>
                        </tbody>
                        <thead class="bg-red">
                            <tr>
                                <th colspan="2"><h5>User Manager</h5></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Account Management
                                      </label>
                                    </div>
                                </td>
                                <td>Allows access to reset user passwords and control the deactivation/reactivation of user accounts</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Add & Edit User Roles
                                      </label>
                                    </div>
                                </td>
                                <td>Assign role permissions for users (requires Create & Manage Users role)</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        Create & Manage Users
                                      </label>
                                    </div>
                                </td>
                                <td>Create, manage, and delete users, including rate information</td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                         User Licenses
                                      </label>
                                    </div>
                                </td>
                                <td>Create, manage and delete user licenses</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="form-check mt-3">
          <input class="form-check-input" type="checkbox" value="" id="">
          <label class="form-check-label" for="">
            Send K-mail:
          </label>
        </div>
        <a href="#" class="d-block my-3">View Role Work Log</a>

    </div>
</div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <button type="submit" class="btn btn-grey">Update Roles</button>
        </div>
    </div>
<?php include('./__components/footer.php') ?>