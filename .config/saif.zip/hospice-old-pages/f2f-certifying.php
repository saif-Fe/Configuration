<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>F2F Certifying</h1>
            <div class="col-3">
                <div class="mb-3 row">
                    <div class="col-3 d-flex align-items-center"><label for="" class="form-label">Clinician:</label>
                    </div>
                    <div class="col-9"><input type="text" name="" id="" class="form-control" placeholder=""></div>
                </div>
            </div>
        </div>
        <div class="bg-grey py-3">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Patient Name (Last Name, First Name) & MRN:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Mileage:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <p>Gender</p>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Male">
                        <label class="form-check-label" for="">M</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Female">
                        <label class="form-check-label" for="">F</label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Agency Name/ Branch:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Date:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Time In:</label>
                        <input type="time" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Time Out:</label>
                        <input type="time" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">DOB:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Certification Period</label>
                        <div class="d-flex">
                            <div class="col"><input type="date" class="form-control" name="" id=""></div>
                            <div class="col-1 text-center"><span class="align-middle">-</span></div>
                            <div class="col"><input type="date" class="form-control" name="" id=""></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white p-3">
                <div class="section-header py-3">
                    <h2>Narrative Statement</h2>
                    <p>Review the individual's clinical circumstances and synthesize the medical information to provide
                        the clinical justification for admission to hospice services.</p>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label" hidden>Narrative Statement</label>
                    <textarea class="form-control" name="" id="" rows="3"></textarea>
                </div>
                <p><strong>Attestation:</strong> I confirm that I had a face-to face encounter with the patient on
                    <input type="date" name="attestationDate" id=""> that encounter in determining continued eligibility
                    for hospice care. and that I used the clinical findings from</p>
            </div>
            <div class="bg-white p-3 mt-3">
                <div class="row">
                    <div class="col-md-8">
                        <p>Signature & Title</p>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="" class="form-label">Date</label>
                            <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>