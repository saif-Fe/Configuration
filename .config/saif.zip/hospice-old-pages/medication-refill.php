<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Medication Refill</h1>
            <p>Bond, James</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="btn-div d-flex justify-content-end">
                <button type="button" id="addMedication" class="btn btn-blue">Add Medication</button>
            </div>
            <div class="medication-container">
                <div class="medication-box mt-3">
                    <div class="bg-white p-3">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Date</label>
                                  <input type="date" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Prescription Number</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="" class="form-label">Medicaiton Name</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option selected>Select one</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                    <label for="" class="form-label">NDC</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option selected>Select one</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                    </select>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Quantity</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Price</label>
                                  <input type="text" class="form-control" name="" id="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                    <label for="" class="form-label">Type</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option selected>Select one</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                    </select>
                            </div>
                            <div class="col-md-4">
                                    <label for="" class="form-label">HCPCS</label>
                                    <select class="form-select w-100" name="" id="">
                                        <option selected>Select one</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                        <option value="">-</option>
                                    </select>
                            </div>
                            <div class="col-md-4 d-flex align-items-end gap-3 justify-content-end">
                                <a name="" onclick="removeMedicBox(this)"class="btn btn-grey" href="#" role="button"> <i class="fas fa-xmark"></i> </a>
                                <button type="submit" class="btn btn-blue"><i class="fas fa-check"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <div class="container container__custom">
            <div class="section-table">
                <table id="table_id" class="display w-100">
                    <thead class="bg-red">
                        <tr>
                            <th>Fill Date</th>
                            <th>Prescription Number</th>
                            <th>Medication Name</th>
                            <th>NOC</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Type</th>
                            <th>Type</th>
                            <th>HCPCS</th>
                            <th>Entered By</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
</div>
<?php include('./__components/footer.php') ?>