<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>New Facility</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Facility Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="new-facility-type" class="form-label">facility Type</label>
                          <select class="form-control" name="new-facility-type" id="new-facility-type">
                            <option>Select</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-name" class="form-label">Facility Name:</label>
                          <input type="text" name="new-facility-name" id="new-facility-name" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">Address 1*</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">Address 2*</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">Zip code</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">City*</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">State*</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="mb-3">
                          <label for="new-facility-name" class="form-label">Facility NPI:</label>
                          <input type="text" name="new-facility-name" id="new-facility-name" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-name" class="form-label">Phone:</label>
                          <input type="text" name="new-facility-name" id="new-facility-name" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">other Phone*</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">Fax*</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">Primary Contact</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="new-facility-address" class="form-label">Email Address*</label>
                          <input type="text" name="new-facility-address" id="new-facility-address" class="form-control" placeholder="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Comments</h2>
            </div>
            <div class="bg-white p-3">
                <div class="mb-3">
                  <textarea class="form-control" name="" id="" rows="3"></textarea>
                </div>
            </div>
            <input type="submit" value="Save and Create New Facility" class="btn btn-blue mt-3">
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>
