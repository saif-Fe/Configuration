<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Billing Manager</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3">
                <h2>Medicare Claims Processing</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="dropdown open">
                            <button class="btn btn-blue dropdown-toggle" type="button" id="triggerId" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                        Claims Manager
                                    </button>
                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                <button class="dropdown-item" href="#">Action</button>
                                <button class="dropdown-item disabled" href="#">Disabled action</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <a name="" id="" class="btn btn-blue" href="#" role="button">Generate NOE</a>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Managed Care Claims Processing</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="dropdown open">
                            <button class="btn btn-blue dropdown-toggle" type="button" id="triggerId" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                        Claims Manager
                                    </button>
                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                <button class="dropdown-item" href="#">Action</button>
                                <button class="dropdown-item disabled" href="#">Disabled action</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Room and Board Claims Processing</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="dropdown open">
                            <button class="btn btn-blue dropdown-toggle" type="button" id="triggerId" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                        Claims Manager
                                    </button>
                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                <button class="dropdown-item" href="#">Action</button>
                                <button class="dropdown-item disabled" href="#">Disabled action</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Remittance Manager</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <ul class="list-unstyled d-flex gap-3 flex-column">
                            <li><a href="#">Remittance Manager</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Reports</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <ul class="list-unstyled d-flex gap-3 flex-column">
                            <li><a href="#">Adjustments Report</a></li>
                            <li><a href="">Claim Item Exception Report</a></li>
                            <li><a href="">Follow-Up Report</a></li>
                            <li><a href="">Patient Balances Report</a></li>
                            <li><a href="">Room and Board Report</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-unstyled d-flex gap-3 flex-column">
                            <li><a href="#">Benefit Period Report</a></li>
                            <li><a href="">Claim Status Report</a></li>
                            <li><a href="">Orphan Authorization Report</a></li>
                            <li><a href="">Payment Posting Report</a></li>
                            <li><a href="">SIA Report</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-unstyled d-flex gap-3 flex-column">
                            <li><a href="#">Billed Aging Report</a></li>
                            <li><a href="">Cost Per Visit Report</a></li>
                            <li><a href="">Patient Balance Detail Report</a></li>
                            <li><a href="">Provider Adjustment Report</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Hard Close</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <ul class="list-unstyled d-flex gap-3 flex-column">
                            <li><a href="#">Dashboard</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-unstyled d-flex gap-3 flex-column">
                            <li><a href="">Hard Close Worklog</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-unstyled d-flex gap-3 flex-column">
                            <li><a href="">Unbilled Prior Period Adjustment Report</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>