<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Admission Summary</h1>
            <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span class="patient-name fw-bold ms-1">(864)</span></p>
        </div>
        <div class="section-table">
            <table class="display w-100" id="table_id">
                <thead class="bg-red">
                    <tr>
                        <th>Start of Care Date</th>
                        <th>Admission Date</th>
                        <th>Discharge Date</th>
                        <th>End Date</th>
                        <th>Total Days</th>
                        <th>Readmission</th>
                        <th>Latest Level of Care</th>
                        <th>Latest Benefit Period</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>10/13/2022</td>
                        <td><a href="./edit-admission.php">10/14/2022</a></td>
                        <td></td>
                        <td>01/12/2023</td>
                        <td>92</td>
                        <td>N</td>
                        <td><a href="./level-of-care.php">routine</a></td>
                        <td><a href="./hotbox.php">10/15/2022 - 01/12/2023</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>