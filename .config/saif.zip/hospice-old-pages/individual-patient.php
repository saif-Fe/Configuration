<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Benefit Period Manager : View : Nursing</h1>
            <p>Bond, James (BND-007)</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3">
                <p class="text-center">06/15/2022 - 09/12/2022</p>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">June 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">July 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">August 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="calender__header">
                        <p class="text-center">Sep 2022</p>
                    </div>
                    <div class="calender">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sun</th>
                                        <th scope="col">Mon</th>
                                        <th scope="col">Tue</th>
                                        <th scope="col">Wed</th>
                                        <th scope="col">Thu</th>
                                        <th scope="col">Fri</th>
                                        <th scope="col">Sat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">1</td>
                                        <td>2</td>
                                        <td>3</td>
                                        <td>4</td>
                                        <td>5</td>
                                        <td>6</td>
                                        <td>7</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">8</td>
                                        <td>9</td>
                                        <td>10</td>
                                        <td>11</td>
                                        <td>12</td>
                                        <td>13</td>
                                        <td>14</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">15</td>
                                        <td>16</td>
                                        <td>17</td>
                                        <td>18</td>
                                        <td>19</td>
                                        <td>20</td>
                                        <td>21</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">22</td>
                                        <td>23</td>
                                        <td>24</td>
                                        <td>25</td>
                                        <td>26</td>
                                        <td>27</td>
                                        <td>28</td>
                                    </tr>
                                    <tr class="">
                                        <td scope="row">29</td>
                                        <td>30</td>
                                        <td>31</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="calender__footer py-4">
                <div class="row">
                    <div class="col-md-3">
                        <span class="benefit-period indicator">

                        </span>
                        <span>
                            Benefit Period Day
                        </span>
                    </div>
                    <div class="col-md-3">

                        <span class="scheduled-tasks indicator">

                        </span>
                        <span>
                            Scheduled Tasks
                        </span>
                    </div>
                    <div class="col-md-3">
                        <span class="completed-tasks indicator">

                        </span>
                        <span>
                            Completed Tasks
                        </span>
                    </div>
                    <div class="col-md-3">
                        <span class="missed-visit indicator">

                        </span>
                        <span>
                            Missed Visits
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <ul class="list-unstyled d-flex gap-3 justify-content-between align-items-center m-0">
                <li> <a href="./individual-patient.php">Nursing</a> </li> <li> <a href="./individual-patient-physician.php">Physician</a> </li> <li> <a href="./individual-patient-MSW.php">MSW</a> </li> <li> <a href="./individual-patient-chaplain-counselor.php">Chaplain/ Counselor</a> </li> <li> <a href="./individual-patient-volunteer.php">Volunteer</a> </li> <li> <a href="./individual-patient-aide.php">Aide</a> <li> <a href="./individual-patient-idg-poc.php">IDG/POC</a> </li> <li> <a href="./individual-patient-orders.php">Orders</a> </li> <li> <a href="./individual-patient-claims.php">Claims</a> </li> <li> <a href="./individual-patient-comm.php">Comm</a> </li> <li> <a href="./individual-patient-misc.php">Misc</a> </li>
            </ul>
        </div>
    </div>
    <div class="container container__custom mb-3">
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th colspan="2">Tasks</th>
                        <th>Assigned</th>
                        <th>Target Date</th>
                        <th>Visit Date</th>
                        <th colspan="3">Status</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                   <tr>
                        <td><span class="prn-visit">PRN</span></td>
                        <td>	1.  RN Initial Assessment</td>
                        <td>K. Holmes</td>
                        <td>06/12/2022</td>
                        <td>06/15/2022</td>
                        <td>Completed</td>
                        <td><a href="">Print View</a></td>
                        <td><a href="">Details</a></td>
                        <td><input type="checkbox" name="" id=""></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="task-table">
        <div class="container container__custom">
            <div class="section-header py-3">
                <h2>Schedule Tasks</h2>
            </div>
            <div class="section-table">
                <table class="display w-100">
                    <thead class="bg-red">
                        <tr>
                            <th>Task</th>
                            <th>Assign To</th>
                            <th>Date</th>
                            <th>PRN?</th>
                            <th><a href="#" class="text-light">Clear All</a></th>
                        </tr>
                    </thead>
                    <tbody>
                       <tr>
                        <td>
                              <select class="form-control" name="" id="">
                                <option>Bereavement Assessment</option>
                                <option>-</option>
                                <option>-</option>
                              </select>
                        </td>
                        <td>
        
                              <select class="form-control" name="" id="">
                                <option>Holmes, Kenyetta (RN)</option>
                                <option>-</option>
                                <option>-</option>
                              </select>
                        </td>
                        <td>
                            <input type="date" name="" id="">
                        </td>
                        <td>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="" id="">
                              <label class="form-check-label" for="">
                                PRN Visit
                              </label>
                            </div>
                        </td>
                        <td>
                            <a href="#">Clear</a>
                        </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <button type="submit" class="btn btn-grey">Insert/Update Tasks</button>
        </div>
    </div>
</div>
<script>
    const tasks = document.querySelector('.task-table tbody tr');
    const taskTable = document.querySelector('.task-table tbody');
    document.querySelectorAll(".calender tbody td").forEach(e => {
        e.setAttribute('data-status', '0')
        e.addEventListener('click', function () {
           taskTable.appendChild(tasks.cloneNode(true)); 
           
        })
    })
</script>
<?php include('./__components/footer.php') ?>