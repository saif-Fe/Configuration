<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Aide Care Plan</h1>
            <div class="col-3">
                <div class="mb-3 row">
                    <div class="col-3 d-flex align-items-center"><label for="" class="form-label">Clinician:</label>
                    </div>
                    <div class="col-9"><input type="text" name="" id="" class="form-control" placeholder=""></div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Patient Name (Last Name, First Name) & MRN:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" value="" id="">
                        <label class="form-check-label" for="">
                            Patient Identity Confirmed
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Mileage:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-2">
                    <p>Gender</p>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Male">
                        <label class="form-check-label" for="">M</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="" value="Female">
                        <label class="form-check-label" for="">F</label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="" class="form-label">Agency Name/ Branch:</label>
                        <input type="text" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Date:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">Documentation Time:</label>
                        <input type="time" class="form-control" name="" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="" class="form-label">DOB:</label>
                        <input type="date" class="form-control" name="" id="">
                    </div>
                </div>
            </div>
            <div class="bg-white p-3">
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>Aide Frequency</h2>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Aide Frequency:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Frequency End Date Effective:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>Vital Sign Notification</h2>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <label for="" class="form-label w-100">BP Systalic</label>
                            <span class="input-group-text" id="prefixId">
                                <</span> <input type="text" name="name" id="name" class="form-control" placeholder="">
                                    <span class="input-group-text" id="prefixId">></span>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <label for="" class="form-label w-100">Pulse</label>
                            <span class="input-group-text" id="prefixId">
                                <</span> <input type="text" name="name" id="name" class="form-control" placeholder="">
                                    <span class="input-group-text" id="prefixId">></span>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <label for="" class="form-label w-100">Temp</label>
                            <span class="input-group-text" id="prefixId">
                                <</span> <input type="text" name="name" id="name" class="form-control" placeholder="">
                                    <span class="input-group-text" id="prefixId">></span>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <label for="" class="form-label w-100">Weight</label>
                            <span class="input-group-text" id="prefixId">
                                <</span> <input type="text" name="name" id="name" class="form-control" placeholder="">
                                    <span class="input-group-text" id="prefixId">></span>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <label for="" class="form-label w-100">BP Diastolic</label>
                            <span class="input-group-text" id="prefixId">
                                <</span> <input type="text" name="name" id="name" class="form-control" placeholder="">
                                    <span class="input-group-text" id="prefixId">></span>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <label for="" class="form-label w-100">Resp</label>
                            <span class="input-group-text" id="prefixId">
                                <</span> <input type="text" name="name" id="name" class="form-control" placeholder="">
                                    <span class="input-group-text" id="prefixId">></span>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <label for="" class="form-label w-100">O<sub>2</sub> Sat</label>
                            <span class="input-group-text" id="prefixId">
                                <</span> <input type="text" name="name" id="name" class="form-control" placeholder="">
                                    <span class="input-group-text" id="prefixId">></span>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Foley:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-end">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                No bovel movement in 3+ days
                            </label>
                        </div>
                    </div>
                </div>
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>Advanced Directive Information</h2>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <p>Signed Advance Directive on file?</p>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="" value="Yes">
                            <label class="form-check-label" for="">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="" value="No">
                            <label class="form-check-label" for="">No</label>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <p>Signed POLST on file?</p>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="" value="Yes">
                            <label class="form-check-label" for="">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="" value="No">
                            <label class="form-check-label" for="">No</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Advance Directive Issue Date:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">POLST Issue Date:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>Functional Limitation</h2>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Amputation
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="" checked>
                            <label class="form-check-label" for="">
                                Paralysis
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Legally Blind
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Bowel/Bladder Incontinence
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Hearing
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Endurance
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Dyspnea
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Contracture
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Ambutation
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Speech
                            </label>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label for="" class="form-label">Other:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>DME</h2>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Bedside Commmode
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Cane
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Elevated Toilet Seat
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Grab bars
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Hospital Beds
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Nebuliser
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Oxygen
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Tub/ Shower bench
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Walker
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Wheelchair
                            </label>
                        </div>
                    </div>
                </div>
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>Supplies</h2>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                ABDs
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Ace Wrap
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Alcohol Pads
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Breifs
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Chux/ Underpads
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Diabetic Supplies
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Drainage Bag
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Dressing Supplies
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Douderm
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Exam Gloves
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Foley Catheter
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Gauze Pads
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Insertion Kits
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Irrigation Set
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Irrigation Solution
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Kelix Rolls
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Leg Bags
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Needles
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                NG Tube
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Probe Covers
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Sharps Container
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Sterile Gloves
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Syringe
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Tape
                            </label>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label for="" class="form-label">Other</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>Activities Permitted</h2>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Complete Bed Rest
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Up as Tolerated
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Exercise Prescribed
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Independent at home
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Cane
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Bed Rest with BRP
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Transfer Bed-Chair
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Partial Weight Bearing
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Cructches
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Wheelchair
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Walker
                            </label>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label for="" class="form-label">Other</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
                <div class="section-header py-3 d-flex justify-content-between">
                    <h2>Interventions</h2>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h5>Personal Care</h5>
                        <div class="mb-3">
                            <label for="" class="form-label">Assit to Dress</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Complete Bed Bath</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Comb Hair</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Foot Care</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Pericare</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Shampoo Hair</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Skin Care</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Back Rub/Massage</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Oral Hygeine Denture Care</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Check Preasure Area</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Nail Care</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Partial Bath Shower</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Shave</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Complete Shower</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5>Household</h5>
                        <div class="mb-3">
                            <label for="" class="form-label">Change Linen</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Light Housekeeping</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Make Bed</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <h5>Activity</h5>
                        <div class="mb-3">
                            <label for="" class="form-label">Assit in Ambulation</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Assit in Transfer</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Turn or position</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Range of motion</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <h5>Elimination</h5>
                        <div class="mb-3">
                            <label for="" class="form-label">Assit w/ Bed Pan</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Catheter Care</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Incontinent Care</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Assist w/ Bedside Commode</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Empty Ostomy Bag</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Last Bowel Movemen</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label for="" class="form-label">Additional Comment</label>
                            <textarea class="form-control" name="" id="" rows="3"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-3">
                <input type="submit" value="Print to PDF" id="printPDF" class="btn-blue btn">
            </div>
        </div>
    </div>
</div>


<?php include('./__components/footer.php') ?>