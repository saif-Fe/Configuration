<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Patient Profile</h1>
        </div>
        <div class="patient-details d-flex justify-content-between">
            <div class="">
                <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span class="patient-name fw-bold ms-1">(864)</span></p>
                <button type="button" class="btn btn-blue"><i class="fas fa-print me-2"></i> Print</button>
            </div>
            <div class="">
                <p class="company-name">Golden Creek Enterprises LLC</p>
                <p class="company-phone">(032) 722-7051</p>
                <p class="company-address">315 W, Alabama St, Houston TX 77021</p>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-6">
                    <div class="bg-white p-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Patient Information </caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">First Name</th>
                                    <td>James</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Middle Name</th>
                                    <td>Johnathan</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Last Name</th>
                                    <td>Bond</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">MRN</th>
                                    <td>864</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">SSN</th>
                                    <td>N/A</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Date of Birth</th>
                                    <td>10/10/1957</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Gender</th>
                                    <td>Male</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Address</th>
                                    <td>xyz , BAINBRIDGE OH 45612</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Apt/Room</th>
                                    <td>asdfghjkl</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Phone</th>
                                    <td>(123)456-7890</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Email</th>
                                    <td>JBond@uk.gov</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Branch</th>
                                    <td>Golden Creek Enterprises</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Primary Language</th>
                                    <td>Russian </td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Primary Religion</th>
                                    <td>Pentecostal</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Race</th>
                                    <td>
                                        <p>American Indian or Alaskan Native</p>
                                        <p>Black or African American</p>
                                        <p>Hispanic or Latino</p>
                                        <p>Native Hawaiian or Pacific Islander</p>
                                    </td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Residence Type</th>
                                    <td>Home</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Residence Name</th>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Allergies </caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">Allergies</th>
                                    <td>NKA (Food/ Drug/ Latex/ Enviromental)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Patient Flags </caption>
                            </thead>
                            <tbody class="table-group-divider">
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Pharmacy Information</caption>
                            </thead>
                            <tbody class="table-group-divider">
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Patient Flags </caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row" class="p-2">1</th>
                                    <td>
                                       <table class="table table-hover table-borderless m-0 border-0">
                                            <tbody class="">
                                                <tr class="">
                                                    <th scope="row">First Name</th>
                                                    <td>James</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">Middle Name</th>
                                                    <td>Johnathan</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">Last Name</th>
                                                    <td>Bond</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">MRN</th>
                                                    <td>864</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">SSN</th>
                                                    <td>N/A</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">Date of Birth</th>
                                                    <td>10/10/1957</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">Gender</th>
                                                    <td>Male</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">Address</th>
                                                    <td>xyz , BAINBRIDGE OH 45612</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">Relationship</th>
                                                    <td>Spouse</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">POA financial</th>
                                                    <td>Yes</td>
                                                </tr>
                                                <tr class="">
                                                    <th scope="row">POA Medical</th>
                                                    <td>Yes</td>
                                                </tr>
                                            </tbody>
                                       </table> 
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Comments</caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">Comment</th>
                                    <td><p>Quos praesentium nesciunt at nihil deserunt commodi quia ab non cumque ullamco optioQuos praesentium nesciunt at nihil deserunt commodi quia ab non cumque ullamco optio</p></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Physician Information</caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">Referring Physician</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row"> Name</th>
                                    <td>Clyde McMorris</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">NPI</th>
                                    <td>1234567890</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Phone</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Fax</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Attending Physician</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Name</th>
                                    <td>Clyde McMorris</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">NPI</th>
                                    <td>1234567890</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Phone</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Fax</th>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bg-white p-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Current Benefit Period (1)</caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">Begin Date</th>
                                    <td>10/15/2022</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">End Date</th>
                                    <td>10/12/2023</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">IDG - Team</th>
                                    <td>Team J</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">IDG - Physician</th>
                                    <td>All Permission All Permission</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">IDG - RN</th>
                                    <td>All All</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">IDG - Aide</th>
                                    <td>All All</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">IDG - Chaplain/Councelor</th>
                                    <td>All All</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">IDG - Volunteer</th>
                                    <td>All All</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Case Manager</th>
                                    <td>All Permission All Permission</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Triage/Risk Code</th>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Advanced Directive</caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">Signed on File</th>
                                    <td>Living Will</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Date Issued</th>
                                    <td>10/09/2022</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Funeral Home Information </caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">Name</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Phone</th>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-white p-3 mt-3">
                        <table class="table table-hover	table-borderless m-0">
                            <thead>
                                <caption class="bg-red px-3 rounded-2">Admission Information</caption>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr class="">
                                    <th scope="row">Referral Date</th>
                                    <td>10/10/2022</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Source</th>
                                    <td>Transfer form SNF or ICF</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">External Referral</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Referring Individual</th>
                                    <td>Rerum placeat est in dolore sit dolor eos et et pariatur Possimus fuga Su </td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Internal Referral</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Insurance</th>
                                    <td>Palmetto GBA</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Insurance ID No</th>
                                    <td>1234567890</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Terminal Dignosis (ICD-10)</th>
                                    <td>G10 Huntington's Disease</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Notice of Election (NOE)</th>
                                    <td>10/17/2022</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Notice of Election (NOE)</th>
                                    <td>10/18/2022</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Admission Date</th>
                                    <td>10/14/2022</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Discharge Date</th>
                                    <td></td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Admitted Day</th>
                                    <td>2</td>
                                </tr>
                                <tr class="">
                                    <th scope="row">Admitted Benefit Period</th>
                                    <td>10/13/2022</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>