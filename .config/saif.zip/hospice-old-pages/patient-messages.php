<?php include('./__components/header.php')?>
<div class="main__include">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Patient Notes/Messages</h1>
            <p><span class="last-name me-1">Bond</span>,<span class="first-name ms-1">James</span><span class="patient-name fw-bold ms-1">(864)</span></p>
        </div>
        <div class="section-table">
            <table class="display w-100" id="messagesRowChild">
                <thead class="bg-red">
                    <tr>
                        <th>From</th>
                        <th>Subject</th>
                        <th>Received</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr data-child-value="Follow up on infection">
                        <td>Abdalla Alkhalifa</td>
                        <td>Infection Follow-Up Due</td>
                        <td>10/26/2022</td>
                        <td>
                            <a href="" class="btn-blue">Remove from Patient</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>