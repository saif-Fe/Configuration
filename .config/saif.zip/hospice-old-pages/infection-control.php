<?php include('./__components/header.php') ?>

<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Infection Control</h1>
        </div>
        <div class="section-header my-3 mt-5 d-flex justify-content-between align-items-center">
            <a href="" class="btn btn-blue">Open</a>
            <a href="" class="btn btn-grey me-auto ms-3">Closed</a>
            <a href="./new-infection-log.php" class="btn btn-grey">New infection Log</a>
        </div>
        <div class="bg-grey py-3">
            <div class="row">
                <div class="col-md-12">
                    <form>
                        <div class="mb-3 row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="" class="form-label">Branch</label>
                                    <select class="form-control" name="" id="">
                                        <option>Golden Creek Enter</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="" class="form-label">Case Manager</label>
                                    <select class="form-control" name="" id="">
                                        <option>All Case Manager</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Date Range:</label>
                                  <input type="date" name="" id="" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="" class="form-label">Type</label>
                                    <select class="form-control" name="" id="">
                                        <option>All Types</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="" class="form-label">Status</label>
                                    <select class="form-control" name="" id="">
                                        <option>All Statuses</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">To:</label>
                                  <input type="date" name="" id="" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" value="" id="">
                                  <label class="form-check-label" for="">
                                    My Follow
                                  </label>
                                </div>
                            </div>
                        </div>

                        <div class="section-table">
                            <table id="table_id" class="display w-100">
                                <thead class="bg-red">
                                    <tr>
                                        <th></th>
                                        <th>Order#</th>
                                        <th>Patient</th>
                                        <th>Orders</th>
                                        <th>Physician</th>
                                        <th>Ordered</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><input type="checkbox" name="" id=""></td>
                                        <td>043317007</td>
                                        <td>Cannon, Jimmy</td>
                                        <td>Physician Order</td>
                                        <td>-</td>
                                        <td>06/07/2022</td>
                                        <td>
                                            <a href="#">Delete</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><input type="checkbox" name="" id=""></td>
                                        <td>043317007</td>
                                        <td>Cannon, Jimmy</td>
                                        <td>Physician Order</td>
                                        <td>-</td>
                                        <td>06/07/2022</td>
                                        <td>
                                            <a href="#">Delete</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><input type="checkbox" name="" id=""></td>
                                        <td>043317007</td>
                                        <td>Cannon, Jimmy</td>
                                        <td>Physician Order</td>
                                        <td>-</td>
                                        <td>06/07/2022</td>
                                        <td>
                                            <a href="#">Delete</a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
</section>
<?php include('./__components/footer.php') ?>