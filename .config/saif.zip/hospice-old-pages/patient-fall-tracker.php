<?php include('./__components/header.php') ?>
    <div class="main__section">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between align-items-center">
                <h1>Patient Fall Tracker</h1>
                <form action="">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="">
                      <label class="form-check-label" for="">
                        Metrics
                      </label>
                    </div>
                </form>
            </div>
            <div class="py-3 d-flex gap-3">
                <a href="#" class="btn-blue text-center">Filter</a>
                <a href="#" class="btn-blue text-center">Date Range: 08/13/2022 - 09/12/2022</a>
                <a href="#" class="btn-blue text-center">Log Status: Saved, Submitted</a>
                <a href="#" class="ms-auto btn-blue text-center">Add Log</a>
            </div>
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th><input type="checkbox" name="" id=""></th>
                        <th>Patient Name</th>
                        <th>MRN</th>
                        <th>Branch</th>
                        <th>Date of Fall</th>
                        <th>Injury</th>
                        <th>Nature of Fall</th>
                        <th>Log Created By</th>
                        <th>Log Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="checkbox" name="" id=""></td>
                        <td>Patient Name</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                </tbody>
            </table>
        </div>
        </div>

    </div>
<?php include('./__components/footer.php') ?>