<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Display Schedule Report</h1>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th><a href="#" class="text-light">Last Week</a></th>
                        <th><a href="#" class="text-light">This Week</a></th>
                        <th><a href="#" class="text-light">Next Week</a></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="">
                              <label for="" class="form-label">From:</label>
                              <input type="date" name="" id="" class="form-control" placeholder="">
                            </div>
                        </td>
                        <td>
                            <div class="">
                              <label for="" class="form-label">To:</label>
                              <input type="date" name="" id="" class="form-control" placeholder="">
                            </div>
                        </td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <button type="submit" class="btn btn-grey">Display Report</button>
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>