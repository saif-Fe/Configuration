<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex flex-wrap align-items-center justify-content-between">
            <h1>Initial & Ongoing Plan of Care</h1>
            <p>Bereavement Period: 06/12/2022 - 07/12/2023</p>
            <a href="#" class="w-100 ">Patient Name</a>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="./idg-meeting.php">Return to IDG Meeting</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Initial & Ongoing Plan of Care</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs justify-content-between" id="initial-ongoing-care" role="tablist">
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link active w-100" id="coordination-care-tab" data-bs-toggle="tab"
                        data-bs-target="#coordination-care" type="button" role="tab" aria-controls="coordination-care"
                        aria-selected="true">Coordination of Care</button>
                </li>
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link w-100" id="frequency-tab" data-bs-toggle="tab" data-bs-target="#frequency"
                        type="button" role="tab" aria-controls="frequency" aria-selected="false">Frequency</button>
                </li>
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link w-100" id="problems-tab" data-bs-toggle="tab" data-bs-target="#problems"
                        type="button" role="tab" aria-controls="problems" aria-selected="false">Problems</button>
                </li>
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link w-100" id="idg-comm-tab" data-bs-toggle="tab" data-bs-target="#idg-comm"
                        type="button" role="tab" aria-controls="idg-comm" aria-selected="false">IDG
                        Communication</button>
                </li>
                <li class="nav-item flex-grow-1" role="presentation">
                    <button class="nav-link w-100" id="work-log-tab" data-bs-toggle="tab" data-bs-target="#work-log"
                        type="button" role="tab" aria-controls="work-log" aria-selected="false">Work Log</button>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active" id="coordination-care" role="tabpanel"
                    aria-labelledby="coordination-care-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <div class="coord-care">
                            <div class="first-option">
                                <p class="mb-3">Care and Services Provided:</p>
                            </div>
                            <div class="second-option">
                                <p class="mb-3">Description of Care and Services Provided:</p>
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="RN/CM">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id=""
                                    value="Admission, Skilled Nursing Assessments and Symptom Management">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="LPN/LVN">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="" value="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="MSW">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="" value="Psychosocial support and management">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Chaplain">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="" value="offered, family declined">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Hospice Aide">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="" value="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Medical Director">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Medical Director">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Patient">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Family">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Caregiver">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Facility Representative">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Other">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Medication Record Update">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Medication Record Updated">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Referrals Made">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Volunteer Services Offered">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Physician Contacted">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Medical Director Contacted">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Order Received">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                </div>
                                <input type="text" name="" id="" value="Awaiting Response">
                            </div>
                            <div class="second-option">
                                <input type="text" name="" id="">
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        The Patient agrees with the plan of care.
                                    </label>
                                </div>
                            </div>
                            <div class="second-option">
                                <div class="mb-3">
                                    <label for="" class="form-label">Representative Name</label>
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                </div>
                            </div>
                        </div>
                        <div class="coord-care">
                            <div class="first-option">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="">
                                    <label class="form-check-label" for="">
                                        The Patient's representative agrees with the plan of care
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="my-3">
                            <label for="" class="form-label">Summary/ Comments:</label>
                            <select class="form-control" name="" id="">
                                <option>Choose Template</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <textarea class="form-control" name="" id="" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="frequency" role="tabpanel" aria-labelledby="frequency-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <div class="row">
                            <div class="col-md-12">
                                <p>Enter Ferquencies Necessary to meet Patient Needs:</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-2">
                                <p>Services</p>
                            </div>
                            <div class="col-4">
                                <p>Frequency</p>
                            </div>
                            <div class="col-2">
                                <p>Duration</p>
                            </div>
                            <div class="col-2">
                                <p>PRN</p>
                            </div>
                            <div class="col-2">
                                <p>PRN Reason</p>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder=""
                                        value="Physician">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder=""
                                        value="Skilled Nursing">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder=""
                                        value="Medical Social Worker">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder=""
                                        value="Hospice Aide">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder=""
                                        value="Chaplain">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder=""
                                        value="Volunteer">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder=""
                                        value="Dietian">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="" value="Other">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="" value="Other">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="" value="Other">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="" value="Other">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="" value="Other">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="" value="Other">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>-</span>
                                    <input type="text" name="" id="" class="w-auto">
                                    <span>per</span>
                                    <select class="form-control" name="" id="">
                                        <option>Wk</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1">
                                    <input type="text" name="" id="" class="form-control" placeholder="">
                                    <select class="form-control" name="" id="">
                                        <option>qtr</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                    <input type="checkbox" name="" id="">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                            <div class="col-2">
                                <div class="d-flex align-items-center gap-1"><input type="text" name="" id=""></div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="tab-pane" id="problems" role="tabpanel" aria-labelledby="problems-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <p>
                            <button class="btn btn-blue" type="button" data-bs-toggle="collapse"
                                data-bs-target="#newProblem" aria-expanded="false" aria-controls="newProblem">
                                Add new Problem
                            </button>
                        </p>
                        <div class="collapse bg-grey p-5 mb-3" id="newProblem">
                            <div class="row">
                                <h4 class="mb-3">Problem Information</h4>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="" class="form-label">Name*</label>
                                                <input type="text" name="" id="" class="form-control" placeholder="">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="" class="form-label">Identified Date*</label>
                                                <input type="date" name="" id="" class="form-control" placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-5">
                                        <h6 class="mb-3">Goal Information</h6>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="" class="form-label">Managment Regime*</label>
                                                <select class="form-control" name="" id="">
                                                    <option>Choose Template</option>
                                                    <option>-</option>
                                                    <option>-</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <textarea class="form-control" name="" id="" rows="3"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="problemModal" class="me-3">Intervention</label>
                                            <button id="problemModal " type="button" class="btn btn-blue"
                                                data-bs-toggle="modal" data-bs-target="#interventionModal">
                                                Add/Edit
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="" class="form-label">Description</label>
                                                <select class="form-control" name="" id="">
                                                    <option>Choose Template</option>
                                                    <option>-</option>
                                                    <option>-</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="" class="form-label">Type</label>
                                                <select class="form-control" name="" id="">
                                                    <option>Pain</option>
                                                    <option>-</option>
                                                    <option>-</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <textarea class="form-control" name="" id="" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="" class="form-label">Outcome Timeframe</label>
                                                <select class="form-control" name="" id="">
                                                    <option>Within 0-24 hrs</option>
                                                    <option>-</option>
                                                    <option>-</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="" class="form-label">Progress*</label>
                                                <select class="form-control" name="" id="">
                                                    <option>0%</option>
                                                    <option>-</option>
                                                    <option>-</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <textarea class="form-control" name="" id="" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex gap-3 mt-3 justify-content-end">
                                    <button type="button" class="btn btn-grey">Cancel</button>
                                    <button type="button" class="btn btn-blue">Save & Close</button>
                                    <button type="button" class="btn btn-blue">Save & Add Another</button>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col"></th>
                                        <th scope="col">Problem Name</th>
                                        <th scope="col">Problem Type</th>
                                        <th scope="col">Identified Date</th>
                                        <th scope="col">Progress</th>
                                        <th scope="col">Goal Resolved</th>
                                        <th scope="col">Last Activity</th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="">
                                            </div>
                                        </td>
                                        <td>
                                            <button type="button" class="btn" data-bs-toggle="modal"
                                                data-bs-target="#problemDetails">
                                                <i class="fa-solid fa-plus"></i>
                                            </button>
                                            Pain</td>
                                        <td>Pain</td>
                                        <td>06/07/2022</td>
                                        <td>
                                            <div class="">
                                                <select class="form-control" name="" id="">
                                                    <option>20%</option>
                                                    <option>-</option>
                                                    <option>-</option>
                                                </select>
                                            </div>
                                        </td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                            <a name="" id="" class="btn" href="#" role="button"> <i
                                                    class="fa-solid fa-pen-to-square"></i> </a>
                                            <a name="" id="" class="btn" href="#" role="button"> <i
                                                    class="fa-solid fa-trash"></i> </a>
                                            <a name="" id="" class="btn" href="#" role="button"> <i
                                                    class="fa-solid fa-check"></i> </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <button type="button" class="btn btn-blue">Resolve All Problems</button>

                    </div>
                </div>
                <div class="tab-pane" id="idg-comm" role="tabpanel" aria-labelledby="idg-comm-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <h4>New Note</h4>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Subject</label>
                                  <input type="text" name="" id="" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Date</label>
                                  <input type="date" name="" id="" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                  <label for="" class="form-label">Use Template</label>
                                  <select class="form-control" name="" id="">
                                    <option>Choose template</option>
                                    <option>-</option>
                                    <option>-</option>
                                  </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                  <textarea class="form-control" name="" id="" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                        <p>
                            <button class="btn btn-blue" type="button" data-bs-toggle="collapse" data-bs-target="#interdisplinaryCommHis" aria-expanded="false"
                                    aria-controls="interdisplinaryCommHis">
                                Interdisciplinary Communication History
                            </button>
                        </p>
                        <div class="collapse bg-grey p-5 mb-3" id="interdisplinaryCommHis">
                           <div class="table-responsive ">
                            <table id="table_id" class="table w-100">
                                <thead>
                                    <tr>
                                        <th scope="col">Date</th>
                                        <th scope="col">Discipline</th>
                                        <th scope="col">Subject</th>
                                        <th scope="col">Details</th>
                                        <th scope="col">Submitter</th>
                                        <th scope="col">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row"></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                           </div>
                            
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="work-log" role="tabpanel" aria-labelledby="work-log-tab">
                    <div class="bg-white rounded-0 rounded-bottom border-end border-start border-bottom p-5">
                        <div class="table-responsive">
                            <table id="table_id" class="table w-100">
                                <thead>
                                    <tr>
                                        <th scope="col">User</th>
                                        <th scope="col">Change Date</th>
                                        <th scope="col">Description</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="row">user</td>
                                        <td>date</td>
                                        <td>Plan of care</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        

                    </div>
                </div>
            </div>
            <div class="form-check my-3">
                <input class="form-check-input" type="checkbox" value="" id="">
                <label class="form-check-label" for="">
                    Generate Plan of Care
                </label>
            </div>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" value="" id="">
                <label class="form-check-label" for="">
                    Create Snapshot
                </label>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Electronic Signature</label>
                        <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Signature Date</label>
                        <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <button type="submit" class="btn btn-grey">Submit</button>
        </div>
    </div>
</div>
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="interventionModal" tabindex="-1" role="dialog" aria-labelledby="intervention"
    aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="intervention">Add/Edit Intervention </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

            </div>
            <div class="modal-body">
                <h4>Choose one or more Intervention</h4>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="">
                    <label class="form-check-label" for="">
                        Administer pain Medication as ordered
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="">
                    <label class="form-check-label" for="">
                        Asses and Monitor patient's pain level and related vital signs
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="">
                    <label class="form-check-label" for="">
                        Educate and/or implement nonphormacological measures to reduce pain (eg. ice, heat, massage,
                        relaxation, meditation)
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="">
                    <label class="form-check-label" for="">
                        Educate Patient and/or caregiver(s) on pain reduction and prevention techniques
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="">
                    <label class="form-check-label" for="">
                        Evalute effectiveness of pain medication(s)
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="">
                    <label class="form-check-label" for="">
                        Review risk and benefits of pain medication(s) offered for symptom management
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="">
                    <label class="form-check-label" for="">
                        Tirate pain medication as ordered
                    </label>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Other</label>
                    <select class="form-control" name="" id="">
                        <option>Choose template</option>
                        <option>-</option>
                        <option>-</option>
                    </select>
                </div>
                <div class="mb-3">
                    <textarea class="form-control" name="" id="" rows="3"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-grey" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-blue">Add</button>
            </div>
        </div>
    </div>
</div>
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade modal-xl" id="problemDetails" tabindex="-1" role="dialog" aria-labelledby="problemDetails"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="problemDetails">Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="table-responsive">
                        <table class="table ">
                            <thead>
                                <tr>
                                    <th scope="col" colspan="2">Intervention</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Last Performed</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="">
                                    <td scope="row" colspan="3">Educated and/or implement</td>
                                    <td>
                                        <a name="" id="" class="btn" href="#" role="button">Perform</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-grey" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<?php include('./__components/footer.php') ?>