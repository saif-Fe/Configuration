<?php include('./__components/header.php') ?>

<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>My Patient</h1>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <ul class="d-flex gap-4 list-unstyled m-0">
                <li>Tools:</li>
                <li><a href="./blank-forms.php" class="text-dark">Blank Forms</a></li>
                <li><a href="./display-schedule.php" class="text-dark">Display Schedule</a></li>
                <li><a href="./phone-roster.php" class="text-dark">Phone Roster</a></li>
            </ul>
        </div>
    </div>
    <div class="container container__custom">
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Patient</th>
                        <th>MRN</th>
                        <th>Latest Benefit Period</th>
                        <th>QA Manager</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>WellSky</td>
                        <td>GCE-003</td>
                        <td>06/15/22-09/12/22</td>
                        <td>
                            Holmes, Kenyatta
                        </td>
                    </tr>
                    <tr>
                        <td>WellSky</td>
                        <td>GCE-003</td>
                        <td>06/15/22-09/12/22</td>
                        <td>
                            Holmes, Kenyatta
                        </td>

                    </tr>
                    <tr>
                        <td>WellSky</td>
                        <td>GCE-003</td>
                        <td>06/15/22-09/12/22</td>
                        <td>
                            Holmes, Kenyatta
                        </td>
                    </tr>
                    <tr>
                        <td>WellSky</td>
                        <td>GCE-003</td>
                        <td>06/15/22-09/12/22</td>
                        <td>
                            Holmes, Kenyatta
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php include('./__components/footer.php') ?>