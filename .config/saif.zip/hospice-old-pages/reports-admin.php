<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Report and Administrator</h1>
        </div>
        <div class="bg-grey py-3 pb-5">
            <div class="section-header my-3 mt-5">
                <h2>Clinical Tasks</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <ul class="list-unstyled list-col-3">
                        <li><a href="./blank-forms.php">Blank Forms</a></li>
                        <li><a href="./missed-visit-verify.php">Missed Visit Reports</a></li>
                        <li><a href="">Phone Roster</a></li>
                        <li><a href="">Working Report</a></li>
                        <li><a href="./visit-verify.php">Kinnser VisitVerify Report</a></li>
                        <li><a href="./orphan-document.php">Orphan Document</a></li>
                        <li><a href="">Schedule Deviation</a></li>
                        <li><a href="./past-visit.php">Past Due Visit</a></li>
                        <li><a href="">Schedule Report</a></li>
                    </ul>
                </div>
            </div>
            <div class="section-header my-3 mt-5">
                <h2>Reports</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <ul class="list-unstyled list-col-3">
                        <li><a href="">Active Bereavement</a></li>
                        <li><a href="">Admissions</a></li>
                        <li><a href="">Average Daily Census</a></li>
                        <li><a href="">CAHPS Export</a></li>
                        <li><a href="">CAP Report</a></li>
                        <li><a href="">Discharge Report</a></li>
                        <li><a href="">HIS Measures Report</a></li>
                        <li><a href="">IDG Meeting Report</a></li>
                        <li><a href="">Length of Stay (LOS)</a></li>
                        <li><a href="">Level of Care</a></li>
                        <li><a href="">Marketing Report</a></li>
                        <li><a href="">Non-Admitted Patients</a></li>
                        <li><a href="">Pending Admissions</a></li>
                        <li><a href="">Patient Decline</a></li>
                        <li><a href="">Patient Roster</a></li>
                        <li><a href="">Pending (Re)Certifications / F2F Encounters</a></li>
                        <li><a href="">Smart QAPI</a></li>
                        <li><a href="">Utilization Report</a></li>
                        <li><a href="">Volunteer Hour Report</a></li>
                    </ul>
                </div>
            </div>
            <div class="section-header my-3 mt-5">
                <h2>Administrator</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <ul class="list-unstyled list-col-3">
                        <li><a href="">Clinic Settings</a></li>
                        <li><a href="">Custom Non-Admit Reasons</a></li>
                        <li><a href="">DME</a></li>
                        <li><a href="">Facilities</a></li>
                        <li><a href="">Flags</a></li>
                        <li><a href="">Insurance</a></li>
                        <li><a href="">Licenses</a></li>
                        <li><a href="">Pharmacy Refill Import</a></li>
                        <li><a href="">Payroll Manager</a></li>
                        <li><a href="">Physicians</a></li>
                        <li><a href="">Quality Assurance</a></li>
                        <li><a href="">Restricted Clinic Settings</a></li>
                        <li><a href="">Supplies</a></li>
                        <li><a href="">Task Details</a></li>
                        <li><a href="">Templates</a></li>
                        <li><a href="">Users</a></li>
                        <li><a href="">Visit Types</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>