<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Benefit Periods: <span class="last-name mx-1">Bond</span>,<span class="first-name ms-1">James</span></h1>
        </div>
    </div>
        <div class="container container__custom">
            <div class="section-table">
                <table id="table_id" class="display w-100">
                    <thead class="bg-red">
                        <tr>
                            <th>MRN</th>
                            <th>Branch</th>
                            <th>Beginning Date</th>
                            <th>Ending Date</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>864</td>
                            <td>Golden Creek Enterprises LLC</td>
                            <td>10/15/2022</td>
                            <td>01/12/2023</td>
                            <td>Active</td>
                            <td><a href="edit-benefit-period.php">Edit</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
</div>
<?php include('./__components/footer.php')?>