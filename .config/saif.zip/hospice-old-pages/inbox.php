<?php include('./__components/header.php') ?>

<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Inbox</h1>
            <a href="" class="btn-red text-center d-flex align-items-center justify-content-center">Reset filter</a>
        </div>
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>From</th>
                        <th>Subject</th>
                        <th>Patient</th>
                        <th>Date</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <input type="checkbox" name="" id="">
                        </td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input type="checkbox" name="" id="">
                        </td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>

                    </tr>
                    <tr>
                        <td>
                            <input type="checkbox" name="" id="">
                        </td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input type="checkbox" name="" id="">
                        </td>
                        <td>WellSky</td>
                        <td>Roles have been added/Removed from your account</td>
                        <td></td>
                        <td>Date</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
</section>


<?php include('./__components/footer.php') ?>
