<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Patient decline Report</h1>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>
