<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Volunteer Request Assesment:</h1>
            <p><span class="last-name mx-1">Bond</span>,<span class="first-name me-1">James</span><span
                    class="pat-number me-1">(846) </span></p>
        </div>
        <div class="bg-grey py-3">
            <div class="section-header py-3">
                <h2>Frequency</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <p>Monthly Frequency</p>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                1x Monthly
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                2x Monthly
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                3-7x Monthly
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Other <input type="text" name="" id="">
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <p>Day of the Week Preference</p>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Monday
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Tuesday
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Wednesday
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Thursday
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Friday
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Saturday
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Sunday
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <p>Time of the day Preference</p>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Morning
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Lunch
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Evenings
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Emotional Support</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Home Visit
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Reading
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Comversation
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Phone Calls
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Card/Games
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Music
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Letter Writing
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Other <input type="text" name="" id="">
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Physical Care</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Back Rub
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Help With Feeding 
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Transfer
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Comb Hair
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Transport
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Urinal/ Bedpan
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Other <input type="text" name="" id="">
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Household Chores</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Errands
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Cleaning 
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Cooking
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Laundry
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Other <input type="text" name="" id="">
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Bereavement</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Phone Call
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="monthlyFrequency" id="">
                            <label class="form-check-label" for="">
                                Letter Writing 
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Other <input type="text" name="" id="">
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Additional Patient Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="levelOfAbility" id="">
                            <label class="form-check-label" for="">
                                Ambulatory
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="levelOfAbility" id="">
                            <label class="form-check-label" for="">
                                Bedbound 
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Other <input type="text" name="" id="">
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3">
                <h2>Signature</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                          <label for="" class="form-label">Signature</label>
                          <input type="password" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                          <label for="" class="form-label">Title</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                          <label for="" class="form-label">Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <a name="" id="" class="btn btn-blue mb-3" href="#" role="button">Add Signature</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex justify-content-end gap-3">
            <button type="button" class="btn btn-grey">Print View</button>
            <button type="submit" class="btn btn-grey">Save</button>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>