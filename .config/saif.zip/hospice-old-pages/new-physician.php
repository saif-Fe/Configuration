
<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Physician profile</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Add Physician</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">First Name*</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Last Name*</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Suffix</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Physician UPIN</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Physician NPI</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Physician DEA#</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Physician License #</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">License Expiration</label>
                          <input type="date" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Community Care #</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Contact Person</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Address</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Zip code</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">City</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">State</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Phone</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Fax</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Physician Contact Email</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Order Delivery Preference</label>
                          <select class="form-control" name="" id="">
                            <option>None</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="form-check mb-3">
                          <label class="form-check-label" for="">
                            External Referrence
                          </label>
                          <input class="form-check-input" type="checkbox" value="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Alternate Address</label>
                          <textarea class="form-control" name="" id="" rows="3"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Attachment</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                          <label for="" class="form-label">Upload File</label>
                          <input type="file" class="form-control" name="" id="" placeholder="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Comments</h2>
            </div>
            <div class="bg-white p-3">
                <div class="mb-3">
                  <textarea class="form-control" name="" id="" rows="3"></textarea>
                </div>
            </div>
            <input type="submit" value="Add" class="btn btn-blue mt-3">
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>
