<?php include('./__components/header.php') ?>
<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Order Manager</h1>
            <a href="" class="btn-red text-center d-flex align-items-center justify-content-center">Reset filter</a>
        </div>
        <!-- Nav tabs -->
        <ul class="nav nav-pills py-3 bg-grey" id="orderTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="toBeSent-tab" data-bs-toggle="tab" data-bs-target="#toBeSent"
                    type="button" role="tab" aria-controls="toBeSent" aria-selected="true">To be sent</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pendingPhySign-tab" data-bs-toggle="tab" data-bs-target="#pendingPhySign"
                    type="button" role="tab" aria-controls="pendingPhySign" aria-selected="false">Pending Physician
                    Signature</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="orderReceived-tab" data-bs-toggle="tab" data-bs-target="#orderReceived"
                    type="button" role="tab" aria-controls="orderReceived" aria-selected="false">Received</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="orderToolsReports-tab" data-bs-toggle="tab"
                    data-bs-target="#orderToolsReports" type="button" role="tab" aria-controls="orderToolsReports"
                    aria-selected="false">Order Tools/ Reports</button>
            </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <div class="tab-pane active" id="toBeSent" role="tabpanel" aria-labelledby="toBeSent-tab">

                <div class="section-header my-3 mt-5">
                    <h2>Golden Creek Enterprises LLC</h2>
                </div>
                <div class="bg-grey d-flex justify-content-between pt-3 align-items-center">
                    <p>No items selected, <a href="">Select all items across all pages.</a></p>
                    <p><a href="">Export all data</a></p>
                </div>
                <div class="section-table">
                    <table id="table_id" class="display w-100">
                        <thead class="bg-red">
                            <tr>
                                <th></th>
                                <th>Order#</th>
                                <th>Patient</th>
                                <th>Orders</th>
                                <th>Physician</th>
                                <th>Ordered</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="pendingPhySign" role="tabpanel" aria-labelledby="pendingPhySign-tab">
                <div class="bg-grey py-3">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">All</label>
                                <input type="text" name="" id="" class="form-control" placeholder="" value="0">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">> 7 Days</label>
                                <input type="text" name="" id="" class="form-control" placeholder="" value="0">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <p class="mb-2">Pending By Days</p>
                                <div class="bg-white p-3 border rounded">
                                    <ul class="order-by-time-period list-unstyled d-flex gap-2">
                                        <li class="bg-red rounded-pill p-2 px-3">0 - 7</li>
                                        <li class="bg-red rounded-pill p-2 px-3">8 - 14</li>
                                        <li class="bg-red rounded-pill p-2 px-3">15 - 30</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section-header my-3 mt-5">
                    <h2>Golden Creek Enterprises LLC, 0 - 7</h2>
                </div>
                <div class="bg-grey d-flex justify-content-between pt-3 align-items-center">
                    <p>No items selected, <a href="">Select all items across all pages.</a></p>
                    <p><a href="">Export all data</a></p>
                </div>
                <div class="section-table">
                    <table id="table_id" class="display w-100">
                        <thead class="bg-red">
                            <tr>
                                <th></th>
                                <th>Order#</th>
                                <th>Patient</th>
                                <th>Orders</th>
                                <th>Physician</th>
                                <th>Ordered</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="orderReceived" role="tabpanel" aria-labelledby="orderReceived-tab">
                <div class="bg-grey py-3">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="" class="form-label">Start Date*</label>
                                <input type="date" name="" id="" class="form-control" placeholder="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">End Date*</label>
                                <input type="date" name="" id="" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex h-100 align-items-end p-3"><button type="button" class="btn btn-blue">Run
                                    Report</button></div>
                        </div>
                    </div>
                </div>
                <div class="section-header my-3 mt-5">
                    <h2>Golden Creek Enterprises LLC, 09/23/2022 - 09/23/2022</h2>
                </div>
                <div class="bg-grey d-flex justify-content-between pt-3 align-items-center">
                    <p>No items selected, <a href="">Select all items across all pages.</a></p>
                    <p><a href="">Export all data</a></p>
                </div>
                <div class="section-table">
                    <table id="table_id" class="display w-100">
                        <thead class="bg-red">
                            <tr>
                                <th></th>
                                <th>Order#</th>
                                <th>Patient</th>
                                <th>Orders</th>
                                <th>Physician</th>
                                <th>Ordered</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td>043317007</td>
                                <td>Cannon, Jimmy</td>
                                <td>Physician Order</td>
                                <td>-</td>
                                <td>06/07/2022</td>
                                <td>
                                    <a href="#">Delete</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="orderToolsReports" role="tabpanel" aria-labelledby="orderToolsReports-tab">
                <div class="bg-grey py-3">
                    <div class="bg-white p-3">
                        <div class="row">
                            <div class="col-md-4">
                                <ul class="list-unstyled d-flex gap-3 flex-column">
                                    <li><a href="#">Print Orders Batch</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('./__components/footer.php') ?>