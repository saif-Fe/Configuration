<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>User Profile</h1>
            <p>Firstname, Lastname</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            
        <div class="section-header py-3">
            <h2>Login Password</h2>
        </div>
        <div class="bg-white p-3">
            <p>Passwords must be at least 8 characters in length and contain at least three of the following: upper case letters, lower case letters, numbers, and special characters (e.g., % ^ * $ @ #).</p>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                      <label for="" class="form-label">Current Password</label>
                      <input type="password" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">New Password</label>
                      <input type="password" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Confirm New Password</label>
                      <input type="password" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
            </div>
        </div>
        <div class="section-header py-3">
            <h2>Electronic Signature</h2>
        </div>
        <div class="bg-white p-3">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                      <label for="" class="form-label">Current Signature</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">New Signature</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Confirm New Signature</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
            </div>
        </div>
        <div class="section-header py-3">
            <h2>My Address</h2>
        </div>
        <div class="bg-white p-3">
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-3">
                      <label for="" class="form-label">Address One*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Address Two*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                      <label for="" class="form-label">ZIP code*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                      <label for="" class="form-label">City*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                      <label for="" class="form-label">State*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                      <label for="" class="form-label">Phone*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Phone 2</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Email</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
            </div>
        </div>
        <div class="section-header py-3">
            <h2>Security</h2>
        </div>
        <div class="bg-white p-3">
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-3">
                      <label for="" class="form-label">Question 1*</label>
                      <select class="form-control" name="" id="">
                        <option>What was your dream job as a child?</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Answer 1*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Question 2*</label>
                      <select class="form-control" name="" id="">
                        <option>What is the name of your first pet?</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Answer 2*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Question 3*</label>
                      <select class="form-control" name="" id="">
                        <option>What school did you attend for sixth grade?</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Answer 3*</label>
                      <input type="text" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <button type="submit" class="btn btn-grey">Update User</button>
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>