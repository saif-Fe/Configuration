<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Infection Log</h1>
            <a href="" class="btn-blue">Log New Patient Infection</a>
        </div>
    </div>
    <div class="py-3 bg-grey">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Patient Information</h2>
            </div>
            <div class="p-3 bg-white">
                <p>All fields in this section is required</p>
                <form>
                    <div class="mb-3 row flex-wrap">
                        <div class="col-md-6">
                            <div class="mb-3 row">
                                <label for="new-infection-patient" class="col-md-4 form-label">Patient:</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="" id="new-infection-patient">
                                        <option>Select:</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3 row">
                                <label for="new-infection-reported-by" class="col-md-4 form-label">Infection Reported
                                    By:</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="" id="new-infection-reported-by">
                                        <option>Admin</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3 row">
                                <label for="new-infection-primary-physician" class="col-md-4 form-label">Primary
                                    Physician:</label>
                                <div class="col-md-6">
                                    <select class="form-control " name="" id="new-infection-primary-physician">
                                        <option>Select:</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3 row">
                                <label for="new-infection-date-reported" class="col-md-4 form-label">Date
                                    Reported:</label>
                                <div class="col-md-6">
                                    <input type="date" name="new-infection-date" id="">
                                    <input type="time" name="new-infection-time" id="">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3 row">
                                <label for="new-infection-case-manager" class="col-md-4 form-label">Case
                                    Manager:</label>
                                <div class="col-md-6">
                                    <select class="form-control " name="" id="new-infection-case-manager">
                                        <option>Select:</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3 row">
                                <label for="new-infection-reported-to" class="col-md-4 form-label">Infection Reported
                                    To:</label>
                                <div class="col-md-6">
                                    <select class="form-control " name="" id="new-infection-reported-to">
                                        <option>Select:</option>
                                        <option>-</option>
                                        <option>-</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="bg-white p-3 mt-3">
                <div class="accordion" id="infectionAccordian">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="w-100 btn-blue" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Infection Information
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <form action="">
                                            <p>Status</p>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="new-infection-info-status" id="" value="{3:option1}">
                                                <label class="form-check-label" for="">Investigating</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="new-infection-info-status" id="" value="option2">
                                                <label class="form-check-label" for="">Portable</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio"
                                                    name="new-infection-info-status" id="" value="option3">
                                                <label class="form-check-label" for="">Confirmed</label>
                                            </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="my-3">
                                            <label for="new-infection-date-onset" class="form-label me-3">Date of
                                                Onset</label>
                                            <input type="date" name="" id="new-infection-date-onset">
                                        </div>
                                        <div class="mb-3">
                                            <label for="new-infection-present-admission">Present Upon Admission</label>
                                            <input type="checkbox" name="" id="new-infection-present-admission">
                                        </div>
                                        <div class="mb-3">
                                            <label for="new-infection-type" class="form-label">Infection Type:</label>
                                            <select class="form-control" name="new-infection-type"
                                                id="new-infection-type">
                                                <option>Select</option>
                                                <option>-</option>
                                                <option>-</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="new-infection-type" class="form-label">Infection Type:</label>
                                            <select class="form-control" name="new-infection-type"
                                                id="new-infection-type">
                                                <option>Select</option>
                                                <option>-</option>
                                                <option>-</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="new-infection-type" class="form-label">Infection Type:</label>
                                            <select class="form-control" name="new-infection-type"
                                                id="new-infection-type">
                                                <option>Select</option>
                                                <option>-</option>
                                                <option>-</option>
                                            </select>
                                        </div>
                                        <p>Communicable</p>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio"
                                                name="new-infection-communicable" id="new-infection-communicable-yes">
                                            <label class="form-check-label" for="new-infection-communicable-yes">
                                                Yes
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio"
                                                name="new-infection-communicable" id="new-infection-communicable-no">
                                            <label class="form-check-label" for="new-infection-communicable-no">
                                                No
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="new-infection-description" class="form-label">Infection
                                                Description</label>
                                            <textarea class="h-100 form-control" name="new-infection-description"
                                                id="new-infection-description" rows="10"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="my-3">
                                            <label for="new-infection-symptoms" class="form-label">signs and
                                                symptoms</label>
                                            <textarea class="form-control" name="new-infection-symptoms"
                                                id="new-infection-symptoms" rows="10"></textarea>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="w-100 btn-blue" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Infection Actions Taken and Communication
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="row">
                                    <div class="col-md-5">
                                        <p>Physician Notified?</p>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-physician-notified" id="physician-notified-yes" value="{3:option1}">
                                            <label class="form-check-label" for="physician-notified-yes">Yes</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-physician-notified" id="physician-notified-no" value="no">
                                            <label class="form-check-label" for="physician-notified-no">No</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-physician-notified" id="physician-notified-none" value="N/A" >
                                            <label class="form-check-label" for="physician-notified-none">N/a</label>
                                          </div>
                                    </div>
                                    <div class="col-md-7 d-flex">
                                        <div class="mb-3">
                                          <label for="new-infection-physician-sel" class="form-label">Physician:</label>
                                          <select class="form-control" name="new-infection-physician-sel" id="new-infection-physician-sel">
                                            <option>Select</option>
                                            <option>-</option>
                                            <option>-</option>
                                          </select>
                                        </div>
                                        <div class="mb-3 ms-3">
                                          <label for="" class="form-label w-100">Date Notified:</label>
                                          <input type="date" name="new-infection-date-notified" id="">
                                          <input type="time" name="new-infection-time-notified" id="">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <p>Labs Ordered?</p>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-lab-ordered" id="lab-ordered-yes" value="{3:option1}">
                                            <label class="form-check-label" for="physician-notified-yes">Yes</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-lab-ordered" id="lab-ordered-no" value="no">
                                            <label class="form-check-label" for="physician-notified-no">No</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-lab-ordered" id="lab-ordered-none" value="N/A" >
                                            <label class="form-check-label" for="physician-notified-none">N/a</label>
                                          </div>
                                    </div>
                                    <div class="col-md-7 d-flex">
                                        <div class="mb-3">
                                          <label for="" class="form-label w-100">Date Notified:</label>
                                          <input type="date" name="new-infection-date-notified" id="">
                                          <input type="time" name="new-infection-time-notified" id="">
                                        </div>
                                        <div class="mb-3">
                                          <label for="new-infection-lab-ordered-notes" class="form-label">Notes</label>
                                          <input type="text" class="form-control" name="new-infection-lab-ordered-notes" id="new-infection-lab-ordered-notes" placeholder="">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <p>Patient Hospitalize?</p>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-patient-hospitalized" id="patient-hospitalized-yes" value="{3:option1}">
                                            <label class="form-check-label" for="physician-notified-yes">Yes</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-patient-hospitalized" id="patient-hospitalized-no" value="no">
                                            <label class="form-check-label" for="physician-notified-no">No</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-patient-hospitalized" id="patient-hospitalized-none" value="N/A" >
                                            <label class="form-check-label" for="physician-notified-none">N/a</label>
                                          </div>
                                    </div>
                                    <div class="col-md-7 d-flex">
                                        <div class="mb-3">
                                          <label for="" class="form-label w-100">Date Notified:</label>
                                          <input type="date" name="new-infection-date-notified" id="">
                                          <input type="time" name="new-infection-time-notified" id="">
                                        </div>
                                        <div class="mb-3">
                                          <label for="new-infection-lab-ordered-notes" class="form-label">Notes</label>
                                          <input type="text" class="form-control" name="new-infection-lab-ordered-notes" id="new-infection-lab-ordered-notes" placeholder="">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <p>Cultured Taken?</p>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-cultured-taken" id="cultured-taken-yes" value="{3:option1}">
                                            <label class="form-check-label" for="physician-notified-yes">Yes</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-cultured-taken" id="cultured-taken-no" value="no">
                                            <label class="form-check-label" for="physician-notified-no">No</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="new-infection-cultured-taken" id="cultured-taken-none" value="N/A" >
                                            <label class="form-check-label" for="physician-notified-none">N/a</label>
                                          </div>
                                    </div>
                                    <div class="col-md-7 d-flex">
                                        <div class="mb-3">
                                          <label for="" class="form-label w-100">Date Notified:</label>
                                          <input type="date" name="new-infection-date-notified" id="">
                                          <input type="time" name="new-infection-time-notified" id="">
                                        </div>
                                        <div class="mb-3">
                                          <label for="new-infection-lab-ordered-notes" class="form-label">Notes</label>
                                          <input type="text" class="form-control" name="new-infection-lab-ordered-notes" id="new-infection-lab-ordered-notes" placeholder="">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                          <label for="new-infection-treatment-notes" class="form-label">Treatment Notes</label>
                                          <textarea class="form-control" name="new-infection-treatment-notes" id="new-infection-treatment-notes" rows="10"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-4 d-flex align-items-end">
                    <div class="">
                      <label for="" class="form-label w-100">Infection Follow-up date</label>
                      <input type="date" name="infection-follow-up" id="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="">
                      <label for="new-infection-follow-up-required-by" class="form-label">Follow-up Required by</label>
                      <select class="form-control" name="new-infection-follow-up-required-by" id="new-infection-follow-up-required-by">
                        <option>Select</option>
                        <option>-</option>
                        <option>-</option>
                      </select>
                    </div>
                </div>
                <div class="col-md-4 d-flex align-items-end justify-content-end">
                    <input type="submit" value="Save Infection Log" class="btn-blue btn">
                    <input type="submit" value="Cancel" class="btn">
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>