<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Beravement Assesment</h1>
            <div class="col-3">
                <div class="mb-3 row">
                    <div class="col-3 d-flex align-items-center"><label for="" class="form-label">Clinician:</label>
                    </div>
                    <div class="col-9"><input type="text" name="" id="" class="form-control" placeholder=""></div>
                </div>
            </div>
        </div>
        <div class="bg-grey py-3">
            <div class="container container__custom">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Patient Name (Last Name, First Name) & MRN:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-3">
                            <label for="" class="form-label">Mileage:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <p>Gender</p>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="" value="Male">
                            <label class="form-check-label" for="">M</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="" value="Female">
                            <label class="form-check-label" for="">F</label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-3">
                            <label for="" class="form-label">Agency Name/ Branch:</label>
                            <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="" class="form-label">Date:</label>
                            <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-3">
                            <label for="" class="form-label">Time In:</label>
                            <input type="time" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-3">
                            <label for="" class="form-label">Time Out:</label>
                            <input type="time" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="" class="form-label">DOB:</label>
                            <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                </div>
                <div class="bg-white p-3">
                    <div class="section-header py-3 d-flex justify-content-between">
                        <h2>Bereaved Person</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="" class="form-label">First Name</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">First Name</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">First Name</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <p class="w-100">Gender</p>
                            <div class="form-check form-check-inline mb-3">
                                <input class="form-check-input" type="checkbox" id="male" value="male">
                                <label class="form-check-label" for="male">Male</label>
                            </div>
                            <div class="form-check form-check-inline mb-3">
                                <input class="form-check-input" type="checkbox" id="female" value="female">
                                <label class="form-check-label" for="female">Female</label>
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="" class="form-label">Email Address</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">Address 1</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">Address 2</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">Zip</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">City</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                            <div class="mb-3">
                                <label for="" class="form-label">State</label>
                                <input type="text" class="form-control" name="" id="">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row g-0 mt-3">
                                <hr>
                                <div class="col-md-4">
                                    <p>Children Under 14 at Home</p>
                                </div>
                                <div class="col-md-8 mb-3">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="0" value="0">
                                        <label class="form-check-label" for="0">0</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="1" value="1">
                                        <label class="form-check-label" for="1">1</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="2" value="2">
                                        <label class="form-check-label" for="2">2</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="3" value="3">
                                        <label class="form-check-label" for="3">3</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="4" value="4">
                                        <label class="form-check-label" for="4">4</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="5" value="5">
                                        <label class="form-check-label" for="5">5 </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id=">5" value=">5">
                                        <label class="form-check-label" for=">5">More than 5 </label>
                                    </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Anticipated Employment of Key Person</p>
                                </div>
                                <div class="col-md-8 mb-3">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="1">
                                        <label class="form-check-label" for="">Professional/ Executive (1)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="2">
                                        <label class="form-check-label" for="">Semiprofessional (2)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="3">
                                        <label class="form-check-label" for="">Office/ Clerical (3)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Skilled Manuel (4)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Semi-Skilled Manuel</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Unskilled Manuel(4)</label>
                                      </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Anticipated Employment of key Person</p>
                                </div>
                                <div class="col-md-8 mb-3">
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="1">
                                        <label class="form-check-label" for="">Works Full time (1)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="2">
                                        <label class="form-check-label" for="">Works Part time (2)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="3">
                                        <label class="form-check-label" for="">Retired (3)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Homemaker (4)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="5">
                                        <label class="form-check-label" for="">Unemployed (5)</label>
                                      </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Clinging or Pining</p>
                                </div>
                                <div class="col-md-6 mb-3">
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="1">
                                        <label class="form-check-label" for="">Never (1)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="2">
                                        <label class="form-check-label" for="">Seldom (2)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="3">
                                        <label class="form-check-label" for="">Moderate (3)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Frequent (4)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="5">
                                        <label class="form-check-label" for="">Constant (5)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="5">
                                        <label class="form-check-label" for="">Constant, Intense (5)</label>
                                      </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Anger</p>
                                </div>
                                <div class="col-md-8 mb-3">
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="1">
                                        <label class="form-check-label" for="">None (1)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="2">
                                        <label class="form-check-label" for="">Mild Irritation (2)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="3">
                                        <label class="form-check-label" for="">Moderate, Occasional Outburst (3)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Severe, Spoils Relationship (4)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="5">
                                        <label class="form-check-label" for="">Extreme, Bitter (5)</label>
                                      </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Guilt</p>
                                </div>
                                <div class="col-md-8 mb-3">
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="1">
                                        <label class="form-check-label" for="">None (1)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="2">
                                        <label class="form-check-label" for="">Mild Irritation (2)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="3">
                                        <label class="form-check-label" for="">Moderate (3)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Severe (4)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="5">
                                        <label class="form-check-label" for="">Extreme, Major Problems (5)</label>
                                      </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Family/ Support System</p>
                                </div>
                                <div class="col-md-8 mb-3">
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="1">
                                        <label class="form-check-label" for="">Warm/ Supportive (1)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="2">
                                        <label class="form-check-label" for="">Supportive/ Lives Outside Area (2)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="3">
                                        <label class="form-check-label" for="">Occasionally Supportive (3)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Rarely Supportive (4)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="5">
                                        <label class="form-check-label" for="">No Family/ Support System (5)</label>
                                      </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Coping Expectation</p>
                                </div>
                                <div class="col-md-8 mb-3">
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="1">
                                        <label class="form-check-label" for="">Well, Normal Grief (1)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="2">
                                        <label class="form-check-label" for="">Fair, May Need Special Help (2)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="3">
                                        <label class="form-check-label" for="">Doubtful, May Need Special Help (3)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="4">
                                        <label class="form-check-label" for="">Badly, Require Special Help (4)</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="" value="5">
                                        <label class="form-check-label" for="">Very Bad, Required Urgent Help (5)</label>
                                      </div>
                                </div>
                                <hr>
                                <div class="col-md-4">
                                    <p>Total Score</p>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" name="totalScore" id="">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="highRisk" value="highRisk">
                                        <label class="form-check-label" for="highRisk">High Risk</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="medRisk" value="medRisk">
                                        <label class="form-check-label" for="medRisk">Medium Risk</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="lowRisk" value="lowRisk">
                                        <label class="form-check-label" for="lowRisk">Low Risk</label>
                                      </div>
                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="noRisk" value="noRisk">
                                        <label class="form-check-label" for="lowRisk">No Risk</label>
                                      </div>
                                </div>
                                <div class="col-md-12 my-3">
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="">
                                      <label class="form-check-label" for="">
                                        IDG has discussed risk with the bereaved party
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="" >
                                      <label class="form-check-label" for="">
                                        Family member and caregiver refuse bereavement services
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="" id="" >
                                      <label class="form-check-label" for="">
                                        Family and caregiver whose needs are assessed to be beyond the scope of the hospice bereavemnt program are referred to appropriate community agencies and/or practitioners
                                      </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-white p-3 mt-3">
                    <div class="mb-3">
                      <label for="" class="form-label">Summary/ Comments</label>
                      <textarea class="form-control" name="" id="" rows="3"></textarea>
                    </div>
                </div>
                <div class="bg-white p-3 mt-3">
                    <div class="row">
                        <div class="col-md-8">
                            <p>Signature & Title</p>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                              <label for="" class="form-label">Date</label>
                              <input type="date" class="form-control" name="" id="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('./__components/footer.php') ?>