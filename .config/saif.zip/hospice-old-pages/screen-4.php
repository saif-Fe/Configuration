<?php include('./__components/header.php') ?>
<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>QA Manager</h1>
        </div>
        <div class="bg-grey">
            <div class="row">
                <div class="col-md-6">
                    <form class="d-flex">
                        <div class="col">
                            <div class="mb-3">
                                <label for="visitType" class="form-label">Visit Type</label>
                                <input type="text" name="visitType" id="visitType" class="form-control"
                                    placeholder="All" aria-describedby="visitType">
                            </div>
                        </div>
                    </form>
                    <div class="col-md-6"></div>
                </div>
            </div>
        </div>
            <div class="section-header">
                <h2>Golden Creek Enterprises LLC, all visit types, all Case Managers, from 07/19/2022 to 08/19/2022</h2>
            </div>
            <div class="section-table">
                <table id="table_id" class="display w-100">
                    <thead class="bg-red">
                        <tr>
                            <th></th>
                            <th>Form</th>
                            <th>Subject</th>
                            <th>Patient</th>
                            <th>Date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="checkbox" name="" id=""></td>
                            <td>WellSky</td>
                            <td>Roles have been added/Removed from your account</td>
                            <td></td>
                            <td>Date</td>
                            <td>
                                <a href="#">Delete</a>
                            </td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="" id=""></td>
                            <td>WellSky</td>
                            <td>Roles have been added/Removed from your account</td>
                            <td></td>
                            <td>Date</td>
                            <td>
                                <a href="#">Delete</a>
                            </td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="" id=""></td>
                            <td>WellSky</td>
                            <td>Roles have been added/Removed from your account</td>
                            <td></td>
                            <td>Date</td>
                            <td>
                                <a href="#">Delete</a>
                            </td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="" id=""></td>
                            <td>WellSky</td>
                            <td>Roles have been added/Removed from your account</td>
                            <td></td>
                            <td>Date</td>
                            <td>
                                <a href="#">Delete</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
</section>

<?php include('./__components/footer.php') ?>