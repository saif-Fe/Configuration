<?php include('./__components/header.php') ?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Message </h1>
            <p>Manage Recipient Groups</p>
        </div>
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Group Name</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>
