<?php include('./__components/header.php') ?>
<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>IDG Meeting</h1>
            <a href="" class="btn-red text-center d-flex align-items-center justify-content-center">Reset filter</a>
        </div>
        <div class="bg-grey d-flex justify-content-between pt-3 align-items-center">

            <div class="d-flex">
                <div class="mb-3 d-flex align-items-center">
                    <label for="" class="form-label flex-grow-1 flex-shrink-0 me-3">Visit Type</label>
                    <select class="form-control" name="" id="">
                        <option>Golden Creek Enterprises LLC</option>
                        <option>Golden Creek Enterprises LLC</option>
                        <option>Golden Creek Enterprises LLC</option>
                    </select>
                </div>
                <div class="mb-3 d-flex align-items-center">
                    <label for="" class="form-label flex-grow-1 flex-shrink-0 me-3">IDG Team</label>
                    <select class="form-control" name="" id="">
                        <option>All Patients</option>
                        <option>All Patients</option>
                        <option>All Patients</option>
                    </select>
                </div>

            </div>
        </div>
        <div class="section-header my-3 mt-5 d-flex justify-content-between">
            <h2>Patient List</h2>
            <a href="">Show Removed Patients</a>
        </div>
        <div class="bg-grey d-flex justify-content-between pt-3 align-items-center">
            <p>No items selected, <a href="">Select all items across all pages.</a></p>
            <p><a href="">Export all data</a></p>
        </div>
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th></th>
                        <th>Patient Name</th>
                        <th>Day Since IDG</th>
                        <th>Admission Date</th>
                        <th>Current Benefit Period</th>
                        <th>Current LOC</th>
                        <th>IDG Team</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="checkbox" name="" id=""></td>
                        <td><a href="./plan-of-care.php">Bond, James</a></td>
                        <td>70</td>
                        <td>06/07/2022</td>
                        <td>1</td>
                        <td></td>
                        <td>N/A</td>
                        <td>
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
</section>
<section class="main__section">
    <div class="container container__custom">
        <div class="section-header my-3 mt-5">

            <h2>Summary / Comments </h2>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="mb-3">
                <label for="" class="form-label">Use Template</label>
                <select class="form-control" name="" id="">
                    <option>-</option>
                    <option>-</option>
                    <option>-</option>
                </select>
            </div>
            <div class="mb-3">
                <textarea class="form-control" name="" id="" rows="10"></textarea>
            </div>
        </div>
    </div>
</section>

<section class="main__section">
    <div class="container container__custom">
        <div class="section-header my-3 mt-5">

            <h2> Attendees </h2>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <form>
                <div class="mb-3 row">
                    <label for="input-Rn" class="col-md-2 col-2 col-form-label">RN</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-Rn" id="input-Rn" placeholder="Enter">
                    </div>
                    <label for="input-rn" class="col-md-1 col-1 col-form-label">Other</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="input-Rn" class="col-md-2 col-2 col-form-label">MSW</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-Rn" id="input-Rn" placeholder="Enter">
                    </div>
                    <label for="input-rn" class="col-md-1 col-1 col-form-label">Other</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="input-Rn" class="col-md-2 col-2 col-form-label">Physician</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-Rn" id="input-Rn" placeholder="Enter">
                    </div>
                    <label for="input-rn" class="col-md-1 col-1 col-form-label">Other</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="input-Rn" class="col-md-2 col-2 col-form-label">Chaplian/ Counselar</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-Rn" id="input-Rn" placeholder="Enter">
                    </div>
                    <label for="input-rn" class="col-md-1 col-1 col-form-label">Other</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="input-Rn" class="col-md-2 col-2 col-form-label">Volunteer</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-Rn" id="input-Rn" placeholder="Enter">
                    </div>
                    <label for="input-rn" class="col-md-1 col-1 col-form-label">Other</label>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                    <div class="col-3">
                        <input type="text" class="form-control" name="input-rn" id="input-rn" placeholder="enter">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Electronic Signature</label>
                        <input type="password" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="" class="form-label">Signature Date</label>
                        <input type="date" name="" id="" class="form-control" placeholder="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom">
            <div class="row">
                <div class="col-md-6">
                    <p>
                        To sign a document electronically, you must first create an electronic signature.
                    </p>
                    <a href="">Click Here to Create Electronic Signature</a>
                </div>
                <div class="col-md-6 text-end">
                    <button type="submit" class="btn btn-grey">Submit</button>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include('./__components/footer.php') ?>