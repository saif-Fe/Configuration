<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Insurance</h1>
            <p>Add new Insurance/ Payer</p>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Payer Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Payer Type</label>
                          <select class="form-control" name="" id="">
                            <option>Medicaid</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Invoice Type</label>
                          <select class="form-control" name="" id="">
                            <option>UB04</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Charge Grouping</label>
                          <select class="form-control" name="" id="">
                            <option>-</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Insurance Name</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Insurance Abbreviation</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Address One</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Address Two</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Zip Code</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">City</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">State</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <p>
                        Display Allowed Amount on Claim (instead of charge)?
                        </p>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="" id="">
                          <label class="form-check-label" for="">
                            Yes
                          </label>
                        </div>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="" id="">
                          <label class="form-check-label" for="">
                            No
                          </label>
                        </div>
                        <p>
                        Visit Authorization Required
                        </p>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="" id="">
                          <label class="form-check-label" for="">
                            Yes
                          </label>
                        </div>
                        <div class="form-check mb-3">
                          <input class="form-check-input" type="radio" name="" id="">
                          <label class="form-check-label" for="">
                            No
                          </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>EDI</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                          <label for="" class="form-label">Clearinghouse</label>
                          <select class="form-control" name="" id="">
                            <option>-</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Interchange Receiver ID</label>
                          <select class="form-control" name="" id="">
                            <option>Carrier Identification Number as assigned by Health care Financing Administration (HCFA) (27)</option>
                            <option>-</option>
                            <option>-</option>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Payer ID</label>
                          <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Contact Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="mb-3">
                  <label for="" class="form-label">Phone</label>
                  <input type="text" name="" id="" class="form-control" placeholder="">
                </div>
                <div class="mb-3">
                  <label for="" class="form-label">Fax</label>
                  <input type="text" name="" id="" class="form-control" placeholder="">
                </div>
                <div class="mb-3">
                  <label for="" class="form-label">Current Balance</label>
                  <input type="text" name="" id="" class="form-control" placeholder="">
                </div>
                <div class="mb-3">
                  <label for="" class="form-label">Work Week Begins</label>
                  <select class="form-control" name="" id="">
                    <option>Sunday</option>
                    <option>-</option>
                    <option>-</option>
                  </select>
                </div>
            </div>
            <input type="submit" value="Add Insurance" class="btn btn-blue mt-3">
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>
