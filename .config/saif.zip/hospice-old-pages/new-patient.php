<?php include('./__components/header.php') ?>

<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3 d-flex justify-content-between">
            <h1>Create New Patient</h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Patient Demographic Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="new-patient-demo-first" class="form-label">First Name*</label>
                            <input type="text" name="new-patient-demo-first" id="new-patient-demo-first"
                                class="form-control" placeholder="" aria-describedby="helpId">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-middle" class="form-label">Middle Name</label>
                            <input type="text" name="new-patient-demo-middle" id="new-patient-demo-middle"
                                class="form-control" placeholder="" aria-describedby="helpId">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-last" class="form-label">Last Name*</label>
                            <input type="text" name="new-patient-demo-last" id="new-patient-demo-last"
                                class="form-control" placeholder="" aria-describedby="helpId">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-suffix" class="form-label">Suffix</label>
                            <input type="text" name="new-patient-demo-last" id="new-patient-demo-last"
                                class="form-control" placeholder="" aria-describedby="helpId">
                        </div>
                        <div class="mb-3 d-flex align-items-start">
                            <div class="col-auto me-3">
                                <label for="new-patient-demo-dob" class="form-label">Date of Birth*</label>
                                <input type="date" name="new-patient-demo-dob" id="new-patient-demo-dob"
                                    class="form-control">
                            </div>

                            <div class="col-auto">
                                <label for="new-patient-demo-age" class="form-label">Age</label>
                                <input type="text" name="new-patient-demo-age" id="new-patient-demo-age"
                                    class="form-control " placeholder="" aria-describedby="helpId">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-gender" class="form-label">Gender</label>
                            <select class="form-control" name="new-patient-demo-gender" id="new-patient-demo-gender">
                                <option>Male</option>
                                <option>Female</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-social-sec" class="form-label">Social Security Number</label>
                            <input type="text" name="new-patient-demo-social-sec" id="new-patient-demo-social-sec"
                                class="form-control" placeholder="">
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value=""
                                id="new-patient-demo-not-applicable">
                            <label class="form-check-label" for="new-patient-demo-not-applicable">
                                Not Applicable
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="new-patient-demo-res-type" class="form-label">Residence Type*</label>
                            <select class="form-control" name="new-patient-demo-res-type"
                                id="new-patient-demo-res-type">
                                <option>Select</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-res-name" class="form-label">Residence Name</label>
                            <select class="form-control" name="new-patient-demo-res-name"
                                id="new-patient-demo-res-name">
                                <option>Select</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-address-1" class="form-label">Address 1*</label>
                            <input type="text" name="new-patient-demo-address-1" id="new-patient-demo-address-1"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-apt" class="form-label">Apt/Room</label>
                            <input type="text" name="new-patient-demo-apt" id="new-patient-demo-apt"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-zip" class="form-label">Zip code*</label>
                            <input type="text" name="new-patient-demo-zip" id="new-patient-demo-zip"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-city" class="form-label">City*</label>
                            <input type="text" name="new-patient-demo-city" id="new-patient-demo-city"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-state" class="form-label">State*</label>
                            <input type="text" name="new-patient-demo-state" id="new-patient-demo-state"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-phone" class="form-label">Phone*</label>
                            <input type="text" name="new-patient-demo-phone" id="new-patient-demo-phone"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-other-phone" class="form-label">Other Phone</label>
                            <input type="text" name="new-patient-demo-other-phone" id="new-patient-demo-other-phone"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-demo-email" class="form-label">Email Address*</label>
                            <input type="text" name="new-patient-demo-email" id="new-patient-demo-email"
                                class="form-control" placeholder="">
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="new-patient-demo-opt-out">
                            <label class="form-check-label" for="new-patient-demo-opt-out">
                                Patient Opts Out of CAHPS Surveys
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Additional Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="new-patient-add-info-mrn" class="form-label">Medical Record Number</label>
                            <input type="text" name="new-patient-add-info-mrn" id="new-patient-add-info-mrn"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-add-info-pri-lang" class="form-label">Primary Language</label>
                            <input type="text" name="new-patient-add-info-pri-lang" id="new-patient-add-info-pri-lang"
                                class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-add-info-pri-reg" class="form-label">Primary Religion</label>
                            <input type="text" name="new-patient-add-info-pri-reg" id="new-patient-add-info-pri-reg"
                                class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p>(Select all that apply)</p>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="new-patient-add-info-amer-ind">
                            <label class="form-check-label" for="new-patient-add-info-amer-ind">
                                American Indian or Alaskan Native
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="new-patient-add-info-asian">
                            <label class="form-check-label" for="new-patient-add-info-asian">
                                Asian
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="new-patient-add-info-black">
                            <label class="form-check-label" for="new-patient-add-info-black">
                                Black or African American
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="new-patient-add-info-hispanic">
                            <label class="form-check-label" for="new-patient-add-info-hispanic">
                                Hispanic or Latino
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="new-patient-add-info-hawaiian">
                            <label class="form-check-label" for="new-patient-add-info-hawaiian">
                                Native Hawaiian or Pacific Islander
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="new-patient-add-info-white">
                            <label class="form-check-label" for="new-patient-add-info-white">
                                white
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Referral Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="new-patient-ref-date" class="form-label">Referral Date</label>
                            <input type="date" name="new-patient-ref-date" id="new-patient-ref-date"
                                class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-ref-source" class="form-label">Source*</label>
                            <select class="form-control" name="new-patient-ref-source" id="new-patient-ref-source">
                                <option>Non-health care facility</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-ref-ext-ref" class="form-label">External referral</label>
                            <select class="form-control" name="new-patient-ref-ext-ref" id="new-patient-ref-ext-ref">
                                <option>select</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-ref-ind" class="form-label">Referring Individual</label>
                            <select class="form-control" name="new-patient-ref-ind" id="new-patient-ref-ind">
                                <option>select</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-ref-int-ref" class="form-label">Internal Referral</label>
                            <select class="form-control" name="new-patient-ref-int-ref" id="new-patient-ref-int-ref">
                                <option>select</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="new-patient-ref-phy-name" class="form-label">Referrring Physician Name</label>
                            <select class="form-control" name="new-patient-ref-phy-name" id="new-patient-ref-phy-name">
                                <option>admin</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                        <p>Is the Referring Physician the Attending Physician*</p>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="attending-phy-equal-referring-phy"
                                id="new-patient-ref-attending-phy">
                            <label class="form-check-label" for="new-patient-ref-attending-phy">
                                yes
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="attending-phy-equal-referring-phy"
                                id="new-patient-ref-referrring-phy">
                            <label class="form-check-label" for="new-patient-ref-referrring-phy">
                                No
                            </label>
                        </div>
                        <div class="mb-3">
                            <label for="new-patient-ref-attending-phy-name" class="form-label">Attending Physician
                                Name</label>
                            <select class="form-control" name="new-patient-ref-attending-phy-name"
                                id="new-patient-ref-attending-phy-name">
                                <option>select</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Emergency Contact information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                No Emergency Contact
                            </label>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">First Name*</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Last Name*</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Relationship</label>
                            <select class="form-control" name="" id="">
                                <option>-</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="" class="form-label">Address One*</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Address Two</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Zip Code*</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">City*</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">State*</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Phone*</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Other Phone</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Email Address</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                        <p>Power of Attorney</p>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Financial
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="">
                            <label class="form-check-label" for="">
                                Medical
                            </label>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-blue">Add</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Advance Directive Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-7">
                        <p>Signed Advance Directive on File *</p>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="advance-directive" id="">
                            <label class="form-check-label" for="">
                                Yes - Full code / Advance Cardiac Life Support (ACLS)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="advance-directive" id="">
                            <label class="form-check-label" for="">
                                Yes - Do Not Resuscitate (DNR)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="advance-directive" id="">
                            <label class="form-check-label" for="">
                                Living Will
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="advance-directive" id="">
                            <label class="form-check-label" for="">
                                No
                            </label>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Advance Directive Date Issued</label>
                            <input type="date" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-5">
                        <p>Signed POLST on File</p>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="signed-polst" id="">
                            <label class="form-check-label" for="">
                                Yes
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="signed-polst" id="">
                            <label class="form-check-label" for="">
                                No
                            </label>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">POLST Date Issue</label>
                            <input type="text" name="" id="" class="form-control" placeholder="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Funeral Home Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Name</label>
                            <select class="form-control" name="" id="">
                                <option>-</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Pharmacy Information</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Name</label>
                            <select class="form-control" name="" id="">
                                <option>-</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Name</label>
                            <select class="form-control" name="" id="">
                                <option>-</option>
                                <option>-</option>
                                <option>-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Patient Flags</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Comments</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                          <textarea class="form-control" name="" id="" rows="3"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Attachments</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-12">
                        <p class="p-3 bg-grey">You must save the form before you can upload attachments</p>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Choose file</label>
                          <input type="file" class="form-control" name="" id="" placeholder="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-3 d-flex justify-content-between">
                <button type="submit" class="btn btn-blue">Save</button>
                <button type="submit" class="btn btn-blue" onclick="location.href = './new-patient-additional.php';">Save and Continue</button>
            </div>
        </div>
    </div>
</div>
<?php include('./__components/footer.php') ?>