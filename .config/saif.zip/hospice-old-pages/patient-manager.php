<?php include('./__components/header.php') ?>
<section class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Patient Manager</h1>
            <p>Patients by Last Name (S)</p>
        </div>
    </div>
    <div class="bg-red d-flex py-3">
        <div class="container container__custom">
            <div class="d-flex justify-content-between align-items-center">
                <p class="m-0">Create Patient Roster</p>
                <p class="m-0">show/hide Inactive</p>
            </div>
        </div>
    </div>
    <div class="container container__custom">
        <div class="d-flex py-3 justify-content-between">
            <a href="" class="text-secondary text-decoration-none">#123</a>
            <a href="" class="text-secondary text-decoration-none">A</a>
            <a href="" class="text-secondary text-decoration-none">B</a>
            <a href="" class="text-secondary text-decoration-none">C</a>
            <a href="" class="text-secondary text-decoration-none">D</a>
            <a href="" class="text-secondary text-decoration-none">E</a>
            <a href="" class="text-secondary text-decoration-none">F</a>
            <a href="" class="text-secondary text-decoration-none">G</a>
            <a href="" class="text-secondary text-decoration-none">H</a>
            <a href="" class="text-secondary text-decoration-none">I</a>
            <a href="" class="text-secondary text-decoration-none">J</a>
            <a href="" class="text-secondary text-decoration-none">K</a>
            <a href="" class="text-secondary text-decoration-none">L</a>
            <a href="" class="text-secondary text-decoration-none">M</a>
            <a href="" class="text-secondary text-decoration-none">N</a>
            <a href="" class="text-secondary text-decoration-none">O</a>
            <a href="" class="text-secondary text-decoration-none">P</a>
            <a href="" class="text-secondary text-decoration-none">Q</a>
            <a href="" class="text-secondary text-decoration-none">R</a>
            <a href="" class="text-secondary text-decoration-none">S</a>
            <a href="" class="text-secondary text-decoration-none">T</a>
            <a href="" class="text-secondary text-decoration-none">U</a>
            <a href="" class="text-secondary text-decoration-none">V</a>
            <a href="" class="text-secondary text-decoration-none">W</a>
            <a href="" class="text-secondary text-decoration-none">X</a>
            <a href="" class="text-secondary text-decoration-none">Y</a>
            <a href="" class="text-secondary text-decoration-none">Z</a>

        </div>
        <div class="section-table">
            <table id="table_id" class="display w-100">
                <thead class="bg-red">
                    <tr>
                        <th>Patient</th>
                        <th>MR #</th>
                        <th>Benefit Period</th>
                        <th>Insurance</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><a href="./individual-patient.php">Bond, James</a></td>
                        <td>BND-007</td>
                        <td>06/15/22-09/12/22</td>
                        <td>MI6</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>

<?php include('./__components/footer.php') ?>