<?php include('./__components/header.php')?>
<div class="main__section">
    <div class="container container__custom">
        <div class="section-header py-3">
            <h1>Edit Benefit Periods: <span class="benefit-period-no">(1)</span></h1>
        </div>
    </div>
    <div class="bg-grey py-3">
        <div class="container container__custom">
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Admission and Benefit Period Information</h2>
            </div>
            <div class="bg-white p-3"> 
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                          <label for="" class="form-label">Benefit Period Beginning Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Benefit Period Ending Date</label>
                          <input type="date" class="form-control" name="" id="">
                        </div>
                        <div class="mb-3">
                          <label for="" class="form-label">Triage/ Risk Code</label>
                          <input type="text" class="form-control" name="" id="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Case Manager*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Move to Admission*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>10/14/2022 - 01/12/2023</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Interdisciplinary Group Assignment</h2>
            </div>
            <div class="bg-white p-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Physician*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Registered Name*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Social Worker*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Aide (HHA)*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="" class="form-label">Chaplain/ Counselor*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Volunteer Coordination*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">IDG Team*</label>
                            <select class="form-select w-100" name="" id="">
                                <option selected>Abdalla Elkhalifa</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Inactivate Benefit Period</h2>
            </div>
            <div class="bg-white p-3">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="">
                  <label class="form-check-label" for="">
                    Inactivate Benefit Period
                  </label>
                </div>
            </div>
            <div class="section-header py-3 d-flex justify-content-between">
                <h2>Comment</h2>
            </div>
            <div class="bg-white p-3">
                <div class="mb-3">
                  <label for="" class="form-label" hidden>Comment</label>
                  <textarea class="form-control" name="" id="" rows="3" ></textarea>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-blue py-3">
        <div class="container container__custom d-flex">
            <a href="./add-new-insurance.php" class="btn btn-grey ms-auto">Save and Submit</a>
        </div>
    </div>
</div>
<?php include('./__components/footer.php')?>