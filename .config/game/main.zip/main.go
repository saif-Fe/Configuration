package main

import (
	"fmt"
	"log"
	"net/http"
	"sync"

	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

// Game state
type GameState struct {
	Board         [3][3]string `json:"board"`
	CurrentPlayer string       `json:"currentPlayer"`
	Winner        string       `json:"winner"`
	GameOver      bool         `json:"gameOver"`
	mu            sync.Mutex
}

var game = &GameState{
	Board:         [3][3]string{{"", "", ""}, {"", "", ""}, {"", "", ""}},
	CurrentPlayer: "X",
	Winner:        "",
	GameOver:      false,
}

type Message struct {
	Type string `json:"type"`
	Row  int    `json:"row"`
	Col  int    `json:"col"`
}

type Response struct {
	Type          string       `json:"type"`
	Board         [3][3]string `json:"board"`
	CurrentPlayer string       `json:"currentPlayer"`
	Winner        string       `json:"winner"`
	GameOver      bool         `json:"gameOver"`
	Success       bool         `json:"success"`
	Message       string       `json:"message"`
	YourRole      string       `json:"yourRole"`
}

func (g *GameState) makeMove(row, col int) (bool, string) {
	g.mu.Lock()
	defer g.mu.Unlock()

	if g.GameOver {
		return false, "Game is over"
	}

	if row < 0 || row > 2 || col < 0 || col > 2 {
		return false, "Invalid position"
	}

	if g.Board[row][col] != "" {
		return false, "Cell already occupied"
	}

	g.Board[row][col] = g.CurrentPlayer
	g.checkWinner()

	if !g.GameOver {
		if g.CurrentPlayer == "X" {
			g.CurrentPlayer = "O"
		} else {
			g.CurrentPlayer = "X"
		}
	}

	return true, "Move successful"
}

func (g *GameState) checkWinner() {
	// Check rows
	for i := 0; i < 3; i++ {
		if g.Board[i][0] != "" && g.Board[i][0] == g.Board[i][1] && g.Board[i][1] == g.Board[i][2] {
			g.Winner = g.Board[i][0]
			g.GameOver = true
			return
		}
	}

	// Check columns
	for i := 0; i < 3; i++ {
		if g.Board[0][i] != "" && g.Board[0][i] == g.Board[1][i] && g.Board[1][i] == g.Board[2][i] {
			g.Winner = g.Board[0][i]
			g.GameOver = true
			return
		}
	}

	// Check diagonals
	if g.Board[0][0] != "" && g.Board[0][0] == g.Board[1][1] && g.Board[1][1] == g.Board[2][2] {
		g.Winner = g.Board[0][0]
		g.GameOver = true
		return
	}

	if g.Board[0][2] != "" && g.Board[0][2] == g.Board[1][1] && g.Board[1][1] == g.Board[2][0] {
		g.Winner = g.Board[0][2]
		g.GameOver = true
		return
	}

	// Check for draw
	full := true
	for i := 0; i < 3; i++ {
		for j := 0; j < 3; j++ {
			if g.Board[i][j] == "" {
				full = false
				break
			}
		}
	}

	if full {
		g.Winner = "Draw"
		g.GameOver = true
	}
}

func (g *GameState) reset() {
	g.mu.Lock()
	defer g.mu.Unlock()

	if(g.CurrentPlayer == "X") {
		g.CurrentPlayer = "O"
	} else {
		g.CurrentPlayer = "X"
	}
	g.Board = [3][3]string{{"", "", ""}, {"", "", ""}, {"", "", ""}}
	g.Winner = ""
	g.GameOver = false
}

func (g *GameState) getState() Response {
	g.mu.Lock()
	defer g.mu.Unlock()

	return Response{
		Type:          "state",
		Board:         g.Board,
		CurrentPlayer: g.CurrentPlayer,
		Winner:        g.Winner,
		GameOver:      g.GameOver,
		Success:       true,
		Message:       "",
	}
}

type ClientInfo struct {
	conn *websocket.Conn
	role string
}

var clientsArray []*ClientInfo
var clientsMu sync.Mutex

func assignRoles() {
	// First two clients are players, rest are spectators
	for i, client := range clientsArray {
		if i == 0 {
			client.role = "X"
		} else if i == 1 {
			client.role = "O"
		} else {
			client.role = "spectator"
		}
	}
}

func broadcastState() {
	clientsMu.Lock()
	defer clientsMu.Unlock()

	state := game.getState()
	for _, info := range clientsArray {
		state.YourRole = info.role
		err := info.conn.WriteJSON(state)
		if err != nil {
			log.Printf("Error broadcasting to client: %v\n", err)
			info.conn.Close()
		}
	}
}

func removeClient(conn *websocket.Conn) {
	clientsMu.Lock()
	defer clientsMu.Unlock()

	for i, client := range clientsArray {
		if client.conn == conn {
			clientsArray = append(clientsArray[:i], clientsArray[i+1:]...)
			assignRoles()
			break
		}
	}
}

func findClientByConn(conn *websocket.Conn) *ClientInfo {
	for _, client := range clientsArray {
		if client.conn == conn {
			return client
		}
	}
	return nil
}

func handleSpectate(conn *websocket.Conn) {
	clientsMu.Lock()
	defer clientsMu.Unlock()

	client := findClientByConn(conn)
	if client == nil {
		return
	}

	oldRole := client.role

	// Find this client's index
	var clientIndex int
	for i, c := range clientsArray {
		if c.conn == conn {
			clientIndex = i
			break
		}
	}

	// If client was a player (index 0 or 1), move them to the end
	if clientIndex == 0 || clientIndex == 1 {
		// Remove from current position
		clientsArray = append(clientsArray[:clientIndex], clientsArray[clientIndex+1:]...)
		// Add to end
		clientsArray = append(clientsArray, client)
		// Reassign all roles
		assignRoles()

		log.Printf("Player %s moved to spectator. Roles reassigned.\n", oldRole)
	}
}

func handleWebSocket(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println("Upgrade error:", err)
		return
	}
	defer conn.Close()

	clientAddr := conn.RemoteAddr().String()
	log.Printf("New WebSocket connection from %s\n", clientAddr)

	// Add client to array
	clientsMu.Lock()
	clientInfo := &ClientInfo{conn: conn, role: "spectator"}
	clientsArray = append(clientsArray, clientInfo)
	assignRoles()
	role := clientInfo.role
	clientsMu.Unlock()

	log.Printf("Client %s assigned role: %s\n", clientAddr, role)

	// Send current game state to new client
	state := game.getState()
	state.YourRole = role
	conn.WriteJSON(state)

	// Broadcast updated state to all clients
	broadcastState()

	for {
		var msg Message
		err := conn.ReadJSON(&msg)
		if err != nil {
			log.Printf("Client %s disconnected: %v\n", clientAddr, err)
			removeClient(conn)
			broadcastState()
			return
		}

		log.Printf("Received from %s: %+v\n", clientAddr, msg)

		var response Response

		switch msg.Type {
		case "move":
			success, message := game.makeMove(msg.Row, msg.Col)
			if success {
				broadcastState()
			} else {
				response = game.getState()
				clientsMu.Lock()
				client := findClientByConn(conn)
				if client != nil {
					response.YourRole = client.role
				}
				clientsMu.Unlock()
				response.Success = false
				response.Message = message
				conn.WriteJSON(response)
			}

		case "reset":
			game.reset()
			broadcastState()

		case "getState":
			clientsMu.Lock()
			response = game.getState()
			client := findClientByConn(conn)
			if client != nil {
				response.YourRole = client.role
			}
			clientsMu.Unlock()
			conn.WriteJSON(response)

		case "spectate":
			handleSpectate(conn)
			broadcastState()
		}
	}
}

func main() {
	http.HandleFunc("/ws", handleWebSocket)
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		http.ServeFile(w, r, "client.html")
	})

	fmt.Println("Tic-Tac-Toe server listening on port 8100...")
	fmt.Println("Open http://localhost:8100 in your browser")
	fmt.Println("WebSocket endpoint: ws://localhost:8100/ws")

	err := http.ListenAndServe("[::]:8100", nil)
	if err != nil {
		log.Fatal("Server error:", err)
	}
}
